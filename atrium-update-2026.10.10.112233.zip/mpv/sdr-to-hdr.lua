-- sdr-to-hdr.lua
-- Real HDR video (HDR10, HDR10+, HLG, Dolby Vision): passed straight through,
--   so the monitor does the brightness mapping with the film's own HDR data.
-- Standard (SDR) video: expanded to HDR on an HDR screen.
--
-- Hotkey: Alt+Shift+H turns the SDR expansion on / off.

local utils = require 'mp.utils'

local state_path = mp.command_native({ "expand-path", "~~exe_dir/mpv/sdr-to-hdr.json" })
local enabled = true

local function load_state()
    local f = io.open(state_path, "r")
    if not f then return end
    local data = utils.parse_json(f:read("*a") or "")
    f:close()
    if type(data) == "table" and type(data.enabled) == "boolean" then
        enabled = data.enabled
    end
end

local function save_state()
    local f = io.open(state_path, "w")
    if not f then return end
    f:write(utils.format_json({ enabled = enabled }))
    f:close()
end

local function source_is_hdr()
    local gamma = mp.get_property("video-params/gamma")
    return gamma == "pq" or gamma == "hlg"
end

local function apply()
    if source_is_hdr() then
        -- Passthrough: send the film's HDR signal untouched to the monitor.
        mp.set_property("target-colorspace-hint-mode", "source")
        mp.set_property("inverse-tone-mapping", "no")
        mp.set_property("tone-mapping", "auto")
    elseif enabled then
        -- SDR video: expand it to the screen's HDR range.
        mp.set_property("target-colorspace-hint-mode", "target")
        mp.set_property("tone-mapping", "bt.2446a")
        mp.set_property("inverse-tone-mapping", "yes")
    else
        mp.set_property("target-colorspace-hint-mode", "target")
        mp.set_property("inverse-tone-mapping", "no")
        mp.set_property("tone-mapping", "auto")
    end
end

mp.add_key_binding("Alt+H", "sdr-to-hdr-toggle", function()
    enabled = not enabled
    save_state()
    apply()
    local msg = "SDR to HDR: " .. (enabled and "on" or "off")
    if source_is_hdr() then msg = msg .. " (this video is real HDR: passed through)" end
    mp.osd_message(msg, 2.5)
end)

mp.observe_property("video-params/gamma", "string", apply)

load_state()
apply()
