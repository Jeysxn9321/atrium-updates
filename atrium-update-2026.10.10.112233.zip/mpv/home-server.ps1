# home-server.ps1
# Small local server behind the Atrium home screen (home.html). It only listens on this PC
# (localhost) and does these things for the page:
#   - reads your Stremio library (with the sign-in key in stremio-key.txt, which never
#     leaves this script)
#   - reads the player's resume.json for the "Continue watching" row
#   - asks your Torrentio add-on for the streams of a film or episode
#   - starts mpv on the stream you picked, and brings Atrium back in front when mpv closes
#   - downloads a movie or an episode into your Videos\Atrium folder when you press Download,
#     and plays it from there
# The first time it runs it also draws the Atrium icon and puts a "Atrium" shortcut on the desktop.
# Started by Home.vbs. To stop it: close it from Task Manager (Windows PowerShell).

param([int]$Port = 18731, [string]$Dir = '', [string]$Mpv = '', [switch]$Wait, [string]$Save = '', [string]$Curl = '')

$ErrorActionPreference = 'Stop'
$self = $MyInvocation.MyCommand.Path
if (-not $Dir) { $Dir = Split-Path -Parent $self }
if (-not $Mpv) { $Mpv = Join-Path (Split-Path -Parent $Dir) 'mpv.exe' }
if (-not $Save) { $Save = Join-Path ([Environment]::GetFolderPath('MyVideos')) 'Atrium' }
if (-not $Curl) { $Curl = Join-Path $env:SystemRoot 'System32\curl.exe' }
try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 } catch {}

$token = [guid]::NewGuid().ToString('N')
# -Wait: started by a restart, so the old server may need a moment to let go of the port.
$listener = $null
$tries = 1
if ($Wait) { $tries = 40 }
for ($i = 0; $i -lt $tries; $i++) {
    $listener = New-Object System.Net.HttpListener
    $listener.Prefixes.Add("http://localhost:$Port/")
    try { $listener.Start(); break } catch { $listener = $null; Start-Sleep -Milliseconds 250 }
}
if (-not $listener) { exit 0 }   # already running

$utf8 = New-Object System.Text.UTF8Encoding($false)
$traceLog = New-Object System.Collections.ArrayList
$endedAt = $null           # when the player last said a video had played to its end
$streamCache = [hashtable]::Synchronized(@{})   # also filled by the second worker
$torrentio = $null
$player = $null         # the mpv this server started last
$playerFront = $false   # whether it was the window in front when last looked at
$log = Join-Path $Dir 'home-server.log'

function Write-Log([string]$text) {
    try { Add-Content -LiteralPath $log -Value ((Get-Date -Format s) + ' ' + $text) } catch {}
}

function Read-Text([string]$name) {
    $p = Join-Path $Dir $name
    if (-not (Test-Path -LiteralPath $p)) { return $null }
    return [IO.File]::ReadAllText($p, $utf8)
}

function Get-Key {
    $k = Read-Text 'stremio-key.txt'
    if (-not $k) { return $null }
    $k = $k.Trim()
    if ($k -notmatch '^[A-Za-z0-9+/=_\-]+$') { return $null }
    return $k
}

function Http-Get([string]$url) {
    $wc = New-Object System.Net.WebClient
    $wc.Encoding = $utf8
    $wc.Headers.Add('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) home-screen')
    try { return $wc.DownloadString($url) } finally { $wc.Dispose() }
}

function Http-Post([string]$url, [string]$body) {
    $wc = New-Object System.Net.WebClient
    $wc.Encoding = $utf8
    $wc.Headers.Add('Content-Type', 'application/json')
    try { return $wc.UploadString($url, $body) } finally { $wc.Dispose() }
}

function Get-Library {
    $k = Get-Key
    if (-not $k) { return '{"result":[],"nokey":true}' }
    return Http-Post 'https://api.strem.io/api/datastoreGet' ('{"authKey":"' + $k + '","collection":"libraryItem","ids":[],"all":true}')
}

# Address of your own Torrentio add-on (the one set up with TorBox), read from your
# Stremio account. Kept in memory only.
function Get-Torrentio {
    if ($script:torrentio) { return $script:torrentio }
    $k = Get-Key
    if (-not $k) { return $null }
    $json = Http-Post 'https://api.strem.io/api/addonCollectionGet' ('{"authKey":"' + $k + '","update":true}')
    $found = [regex]::Matches($json, '"transportUrl"\s*:\s*"(https:[^"]*torrentio[^"]*)/manifest\.json"')
    $pick = $null
    foreach ($m in $found) {
        $u = $m.Groups[1].Value.Replace('\/', '/')
        if ($u -match 'torbox') { $pick = $u; break }
        if (-not $pick) { $pick = $u }
    }
    $script:torrentio = $pick
    return $pick
}

function Get-Streams([string]$type, [string]$id) {
    if ($type -notmatch '^(movie|series|anime)$' -or $id -notmatch '^[A-Za-z0-9:_\-]+$') { return '{"streams":[],"error":"bad id"}' }
    $base = Get-Torrentio
    if (-not $base) { return '{"streams":[],"error":"no add-on"}' }
    $json = Http-Get ($base + '/stream/' + $type + '/' + $id + '.json')
    $urls = New-Object System.Collections.ArrayList
    # The page gets the list without the addresses (they contain your TorBox key);
    # it plays a stream by its position in the list.
    $clean = [regex]::Replace($json, '"url"\s*:\s*"((?:[^"\\]|\\.)*)"', {
        param($m)
        $n = $urls.Add($m.Groups[1].Value.Replace('\/', '/'))
        return '"n":' + $n
    })
    $streamCache[$type + '/' + $id] = $urls
    return $clean
}

# ----- windows -----
# Finding the Atrium window and putting a window in front needs a few Windows calls.
$winSource = @'
using System;
using System.Text;
using System.Runtime.InteropServices;
namespace HomeScreen {
    public static class Win {
        public delegate bool EnumProc(IntPtr h, IntPtr l);
        [DllImport("user32.dll")] static extern bool EnumWindows(EnumProc f, IntPtr l);
        [DllImport("user32.dll")] static extern bool IsWindowVisible(IntPtr h);
        [DllImport("user32.dll")] static extern bool IsIconic(IntPtr h);
        [DllImport("user32.dll")] static extern bool ShowWindow(IntPtr h, int c);
        [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern int GetWindowText(IntPtr h, StringBuilder s, int n);
        [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern int GetClassName(IntPtr h, StringBuilder s, int n);
        [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
        [DllImport("user32.dll")] static extern bool SetForegroundWindow(IntPtr h);
        [DllImport("user32.dll")] static extern bool BringWindowToTop(IntPtr h);
        [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr h, out uint pid);
        [DllImport("user32.dll")] static extern bool AttachThreadInput(uint a, uint b, bool on);
        [DllImport("kernel32.dll")] static extern uint GetCurrentThreadId();
        [DllImport("user32.dll")] static extern void keybd_event(byte k, byte s, uint f, UIntPtr e);

        // The home screen: a browser app window whose title is exactly the page title.
        // Only a window of Brave, Edge or Chrome counts: other programs are built the same way
        // and can show a page called Atrium too (Claude's own app, for one).
        static bool IsHome(IntPtr h, string title) {
            if (h == IntPtr.Zero || !IsWindowVisible(h)) return false;
            StringBuilder c = new StringBuilder(80);
            GetClassName(h, c, 80);
            if (!c.ToString().StartsWith("Chrome_WidgetWin")) return false;
            StringBuilder t = new StringBuilder(260);
            GetWindowText(h, t, 260);
            if (t.ToString() != title) return false;
            uint pid = 0;
            GetWindowThreadProcessId(h, out pid);
            try {
                string n = System.Diagnostics.Process.GetProcessById((int)pid).ProcessName.ToLowerInvariant();
                return n == "brave" || n == "msedge" || n == "chrome";
            } catch { return false; }
        }
        public static string ClassOf(IntPtr h) {
            StringBuilder c = new StringBuilder(80);
            GetClassName(h, c, 80);
            return c.ToString();
        }
        public static IntPtr Find(string title) {
            // the window you are using comes first (with two Atrium windows open, the one you clicked in)
            IntPtr fg = GetForegroundWindow();
            if (IsHome(fg, title)) return fg;
            IntPtr found = IntPtr.Zero;
            EnumWindows(delegate(IntPtr h, IntPtr l) {
                if (!IsHome(h, title)) return true;
                found = h;
                return false;
            }, IntPtr.Zero);
            return found;
        }

        // Puts a window in front. Windows only lets the program that has the keyboard do
        // that, so this joins the front window's input for a moment. No keys are sent.
        public static bool Front(IntPtr h) {
            if (h == IntPtr.Zero) return false;
            if (IsIconic(h)) ShowWindow(h, 9);
            IntPtr fg = GetForegroundWindow();
            if (fg == h) return true;
            uint pid = 0, other = 0;
            if (fg != IntPtr.Zero) other = GetWindowThreadProcessId(fg, out pid);
            uint me = GetCurrentThreadId();
            bool joined = other != 0 && other != me && AttachThreadInput(me, other, true);
            BringWindowToTop(h);
            SetForegroundWindow(h);
            if (joined) AttachThreadInput(me, other, false);
            return GetForegroundWindow() == h;
        }

        // Second try, for the player only: a tap on Alt makes Windows allow it.
        public static bool FrontWithAlt(IntPtr h) {
            keybd_event(0x12, 0, 0, UIntPtr.Zero);
            SetForegroundWindow(h);
            keybd_event(0x12, 0, 2, UIntPtr.Zero);
            return GetForegroundWindow() == h;
        }
    }
}
'@

function Load-Win {
    if ('HomeScreen.Win' -as [type]) { return $true }
    try { Add-Type -TypeDefinition $winSource -ErrorAction Stop; return $true }
    catch { Write-Log ('windows calls: ' + $_.Exception.Message); return $false }
}

# Brings the Atrium window to the front. True when there is one.
function Show-Home {
    if (-not (Load-Win)) { return $false }
    try {
        $h = [HomeScreen.Win]::Find('Atrium')
        if ($h -eq [IntPtr]::Zero) { return $false }
        [void][HomeScreen.Win]::Front($h)
        return $true
    } catch { Write-Log ('show: ' + $_.Exception.Message); return $false }
}

# Starts mpv on a stream address or on a downloaded file, and puts it in front.
# The screen the Atrium window is on (its Windows name, like \\.\DISPLAY2), so that the player
# opens on that same screen; '' when Atrium's window is not found.
function Atrium-Screen {
    try {
        if (-not (Load-Win)) { return '' }
        $h = [HomeScreen.Win]::Find('Atrium')
        if ($h -eq [IntPtr]::Zero) { return '' }
        Add-Type -AssemblyName System.Windows.Forms
        $name = ([string][System.Windows.Forms.Screen]::FromHandle($h).DeviceName).Split([char]0)[0]
        if ($name -match '^\\\\\.\\DISPLAY\d{1,3}$') { return $name }
    } catch { Write-Log ('screen: ' + $_.Exception.Message) }
    return ''
}

# Its place in Windows' list of screens, which is how the player is told (it does not go by
# the name); -1 when unknown.
function Screen-Number([string]$name) {
    if (-not $name) { return -1 }
    try {
        $i = 0
        foreach ($s in [System.Windows.Forms.Screen]::AllScreens) {
            if (([string]$s.DeviceName).Split([char]0)[0] -eq $name) { return $i }
            $i++
        }
    } catch {}
    return -1
}

function Launch-Player([string]$target, [string]$at) {
    if (-not (Test-Path -LiteralPath $Mpv)) { return '{"ok":false,"error":"mpv not found"}' }
    $list = @('--fs', '--force-window=immediate')
    # Where to start from, for something left unfinished on another device.
    if ($at -match '^\d{1,6}$' -and [int]$at -gt 5) { $list += ('--start=' + $at) }
    $screen = Atrium-Screen
    $number = Screen-Number $screen
    if ($number -ge 0) { $list += ('--screen=' + $number); $list += ('--fs-screen=' + $number) }
    $list += ('"' + $target + '"')
    $p = Start-Process -FilePath $Mpv -ArgumentList $list -PassThru
    $script:player = $p
    $script:playerFront = $true
    # Windows does not let a hidden program put a window in front, so ask for it explicitly.
    try {
        for ($i = 0; $i -lt 40; $i++) {
            Start-Sleep -Milliseconds 150
            $p.Refresh()
            if ($p.HasExited -or $p.MainWindowHandle -ne [IntPtr]::Zero) { break }
        }
        if (-not $p.HasExited -and $p.MainWindowHandle -ne [IntPtr]::Zero -and (Load-Win)) {
            if (-not [HomeScreen.Win]::Front($p.MainWindowHandle)) { [void][HomeScreen.Win]::FrontWithAlt($p.MainWindowHandle) }
        }
    } catch { Write-Log ('focus: ' + $_.Exception.Message) }
    return '{"ok":true,"screen":"' + $screen.Replace('\', '\\') + '","number":' + $number + '}'
}

# Whether what you just clicked is on the same screen as the player (it then goes into picture
# in picture by itself; something done on the other screen leaves it as it is). The window that
# now has the keyboard says where; the desktop and the taskbar cover every screen, so for them
# it is where the mouse is.
function Player-Focus {
    try {
        if (-not (Load-Win)) { return '{"known":false}' }
        Add-Type -AssemblyName System.Windows.Forms
        $mine = [IntPtr]::Zero
        foreach ($m in @(Get-Process -Name mpv -ErrorAction SilentlyContinue)) { if ($m.MainWindowHandle -ne [IntPtr]::Zero) { $mine = $m.MainWindowHandle; break } }
        if ($mine -eq [IntPtr]::Zero) { return '{"known":false}' }
        $fg = [HomeScreen.Win]::GetForegroundWindow()
        $there = $null
        if ($fg -ne [IntPtr]::Zero -and [HomeScreen.Win]::ClassOf($fg) -notmatch '^(Progman|WorkerW|Shell_TrayWnd|Shell_SecondaryTrayWnd|NotifyIconOverflowWindow)$') { $there = [System.Windows.Forms.Screen]::FromHandle($fg) }
        else { $there = [System.Windows.Forms.Screen]::FromPoint([System.Windows.Forms.Cursor]::Position) }
        $same = ([string]$there.DeviceName) -eq ([string][System.Windows.Forms.Screen]::FromHandle($mine).DeviceName)
        return '{"known":true,"same":' + ([string]$same).ToLowerInvariant() + '}'
    } catch { return '{"known":false}' }
}

# What is about to play, written down for the player's own scripts (the name in its top bar, the
# paused screen). Only the title's id and its name; never an address.
function Note-Playing([string]$type, [string]$id, [string]$name, [string]$sub) {
    try {
        if ($type -notmatch '^(movie|series|anime)$' -or $id -notmatch '^[A-Za-z0-9:_\-]+$') { return }
        $at = [int64](([datetime]::UtcNow - (New-Object datetime 1970, 1, 1)).TotalSeconds)
        $o = @{ at = $at; type = $type; id = $id; name = (Clip $name 200); sub = (Clip $sub 200) }
        [IO.File]::WriteAllText((Join-Path $Dir 'now-playing.json'), (ConvertTo-Json -InputObject $o -Compress), $utf8)
    } catch { Write-Log ('note: ' + $_.Exception.Message) }
}

# The name and the line under it that the page sends with a request to play.
function Body-Names([string]$body) {
    $name = ''
    $sub = ''
    try { $j = ConvertFrom-Json $body; $name = [string]$j.name; $sub = [string]$j.sub } catch {}
    return @($name, $sub)
}

function Start-Player([string]$type, [string]$id, [int]$n, [string]$at) {
    $urls = $streamCache[$type + '/' + $id]
    if (-not $urls -or $n -lt 0 -or $n -ge $urls.Count) { return '{"ok":false,"error":"unknown stream"}' }
    $url = [string]$urls[$n]
    if ($url -notmatch '^https://[A-Za-z0-9\.\-]+/' -or $url -match '["\s]') { return '{"ok":false,"error":"bad address"}' }
    return (Launch-Player $url $at)
}

# Closes the player this server started, as its own close button would.
function Stop-Player([string]$id) {
    $p = $script:player
    # one particular player, by its process number (used when testing)
    if ($id -match '^\d{1,7}$') {
        try { $p = Get-Process -Id ([int]$id) -ErrorAction Stop; if ($p.ProcessName -ne 'mpv') { $p = $null } } catch { $p = $null }
    }
    try { if ($p -and -not $p.HasExited) { [void]$p.CloseMainWindow(); return '{"ok":true}' } } catch {}
    return '{"ok":false}'
}

# Looked at a few times a second while nothing else is going on. When the player this
# server started has closed, Atrium comes back to the front - but only if the player was the
# window you were looking at, and no other mpv is still open (the next episode, say).
function Watch-Player {
    $p = $script:player
    if (-not $p) { return }
    try {
        if (-not $p.HasExited) {
            $p.Refresh()
            if ($p.MainWindowHandle -ne [IntPtr]::Zero -and (Load-Win)) {
                $script:playerFront = ([HomeScreen.Win]::GetForegroundWindow() -eq $p.MainWindowHandle)
            }
            return
        }
        $script:player = $null
        if ($script:playerFront -and -not (Get-Process -Name mpv -ErrorAction SilentlyContinue)) { [void](Show-Home) }
    } catch { $script:player = $null; Write-Log ('watch: ' + $_.Exception.Message) }
}

function Read-Body($req) {
    $sr = New-Object IO.StreamReader($req.InputStream, $utf8)
    try { return $sr.ReadToEnd() } finally { $sr.Dispose() }
}

# Adds a title to your Stremio library or takes it out (the page sends the item).
function Put-Library([string]$item) {
    $k = Get-Key
    if (-not $k) { return '{"error":"no sign-in key"}' }
    $item = $item.Trim()
    if ($item.Length -gt 20000 -or $item -notmatch '^\{.*\}$' -or $item -notmatch '"_id":"(tt\d+|kitsu:\d+)"') { return '{"error":"bad item"}' }
    return Http-Post 'https://api.strem.io/api/datastorePut' ('{"authKey":"' + $k + '","collection":"libraryItem","changes":[' + $item + ']}')
}

# Length and fingerprint of one of the script or page files in this folder, to check that
# an update was saved whole. Names only; nothing with the sign-in key can be asked for.
function Get-Sha([string]$name) {
    if ($name -notmatch '^[A-Za-z0-9_\-]+\.(lua|conf|ps1|vbs|html)$') { return '{"error":"bad name"}' }
    $text = Read-Text $name
    if ($null -eq $text) { return '{"error":"missing"}' }
    $text = $text.Replace("`r`n", "`n")
    $sha = [Security.Cryptography.SHA256]::Create()
    try { $hash = $sha.ComputeHash($utf8.GetBytes($text)) } finally { $sha.Dispose() }
    $hex = ($hash | ForEach-Object { $_.ToString('x2') }) -join ''
    return '{"len":' + $text.Length + ',"sha":"' + $hex + '"}'
}

# ----- downloads -----
# A download is done by Windows' own curl, started hidden, so it carries on while this
# script answers the page. What was downloaded is remembered in downloads.json: titles,
# file names and sizes, no addresses.
$downloads = New-Object System.Collections.ArrayList
$dlProcs = @{}      # the curl of each running download
$dlUrls = @{}       # its address, kept in memory only, to go on after a cut
$dlFile = Join-Path $Dir 'downloads.json'

function Save-Downloads {
    try {
        $text = '[]'
        if ($downloads.Count -gt 0) {
            $keep = New-Object System.Collections.ArrayList
            foreach ($e in $downloads) {
                [void]$keep.Add(@{ key = $e.key; type = $e.type; id = $e.id; title = $e.title; sub = $e.sub; q = $e.q
                    file = $e.file; total = $e.total; at = $e.at; state = $e.state; pid = $e.pid })
            }
            $text = ConvertTo-Json -InputObject @($keep.ToArray()) -Depth 3 -Compress
        }
        [IO.File]::WriteAllText($dlFile, $text, $utf8)
    } catch { Write-Log ('downloads list: ' + $_.Exception.Message) }
}

function Load-Downloads {
    try {
        if (-not [IO.File]::Exists($dlFile)) { return }
        $raw = ConvertFrom-Json ([IO.File]::ReadAllText($dlFile, $utf8))
        foreach ($o in @($raw)) {
            if (-not $o -or -not $o.key -or -not $o.file) { continue }
            $file = [string]$o.file
            # listed under the folder's old name
            $was = (Join-Path (Split-Path -Parent $Save) 'Jey') + [IO.Path]::DirectorySeparatorChar
            if ($file.StartsWith($was, [StringComparison]::OrdinalIgnoreCase)) { $file = Join-Path $Save $file.Substring($was.Length) }
            # only files in the downloads folder are ever played or deleted
            if (-not $file.StartsWith($Save, [StringComparison]::OrdinalIgnoreCase) -or $file.Contains('..')) { continue }
            [void]$downloads.Add(@{ key = [string]$o.key; type = [string]$o.type; id = [string]$o.id; title = [string]$o.title
                sub = [string]$o.sub; q = [string]$o.q; file = $file; total = [int64]$o.total; at = [int64]$o.at
                state = [string]$o.state; pid = [int]$o.pid; tries = 0; seen = [int64]0; wait = $null })
        }
    } catch { Write-Log ('downloads list: ' + $_.Exception.Message) }
}

function Find-Download([string]$key) {
    foreach ($e in $downloads) { if ($e.key -eq $key) { return $e } }
    return $null
}

function File-Size([string]$path) {
    try { if ([IO.File]::Exists($path)) { return (New-Object IO.FileInfo $path).Length } } catch {}
    return [int64]0
}

function Clip([string]$s, [int]$n) {
    if ($s.Length -gt $n) { return $s.Substring(0, $n) }
    return $s
}

# A title as a file name: plain letters only, nothing Windows refuses.
function Safe-Name([string]$s) {
    if (-not $s) { return '' }
    $s = $s.Normalize([Text.NormalizationForm]::FormD)
    $s = [regex]::Replace($s, '\p{Mn}', '')
    $s = [regex]::Replace($s, '[^\x20-\x7e]', '')
    $s = [regex]::Replace($s, '[\\/:*?"<>|]', ' ')
    $s = [regex]::Replace($s, '\s+', ' ').Trim()
    if ($s.Length -gt 110) { $s = $s.Substring(0, 110) }
    $s = $s.Trim().TrimEnd('.').Trim()
    if ($s -match '^(con|prn|aux|nul|com\d|lpt\d)$') { $s = $s + '_' }
    return $s
}

# Size of the file behind an address, read from a request for its first byte only.
function Get-RemoteSize([string]$url) {
    $r = $null
    $resp = $null
    try {
        $r = [Net.HttpWebRequest]::Create($url)
        $r.Method = 'GET'
        $r.AddRange(0, 0)
        $r.Timeout = 25000
        $r.UserAgent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) home-screen'
        $resp = $r.GetResponse()
        $range = [string]$resp.Headers['Content-Range']
        if ($range -match '/(\d+)\s*$') { return [int64]$Matches[1] }
        return [int64]$resp.ContentLength
    } catch { return [int64]0 }
    finally {
        try { if ($r) { $r.Abort() } } catch {}
        try { if ($resp) { $resp.Close() } } catch {}
    }
}

# One run of curl. "-C -" makes it go on from what is already in the file; it gives up
# by itself when nothing has come for 45 seconds.
function Run-Curl([string]$url, [string]$part) {
    $list = @('-g', '-L', '-s', '--fail', '--connect-timeout', '30', '--speed-limit', '2000', '--speed-time', '45',
        '-C', '-', '-o', ('"' + $part + '"'), ('"' + $url + '"'))
    $opt = @{ FilePath = $Curl; ArgumentList = $list; PassThru = $true }
    if ($env:OS -eq 'Windows_NT') { $opt.WindowStyle = 'Hidden' }
    return (Start-Process @opt)
}

# The page sends which stream (by its place in the list) and what to call the file.
function Start-Download([string]$body) {
    try { $j = ConvertFrom-Json $body } catch { return '{"ok":false,"error":"bad request"}' }
    $type = [string]$j.type
    $id = [string]$j.id
    $n = -1
    try { $n = [int]$j.n } catch {}
    $urls = $streamCache[$type + '/' + $id]
    if (-not $urls -or $n -lt 0 -or $n -ge $urls.Count) { return '{"ok":false,"error":"unknown stream"}' }
    $url = [string]$urls[$n]
    if ($url -notmatch '^https://[A-Za-z0-9\.\-]+/' -or $url -match '["\s]') { return '{"ok":false,"error":"bad address"}' }
    if (-not (Get-Command $Curl -ErrorAction SilentlyContinue)) { return '{"ok":false,"error":"curl not found"}' }
    $old = Find-Download $id
    if ($old -and $old.state -eq 'downloading') { return '{"ok":true,"already":true}' }
    $total = Get-RemoteSize $url
    if ($total -lt 20MB) { return '{"ok":false,"error":"this version is not ready to download"}' }

    if ($old) { $file = $old.file }      # a second try goes on with the same file
    else {
        $ext = 'mkv'
        if ($url -match '\.(mkv|mp4|m4v|avi|webm|mov)(?:$|[?#])') { $ext = $Matches[1].ToLower() }
        $name = Safe-Name ([string]$j.name)
        if (-not $name) { $name = 'video' }
        $folder = $Save
        $sub = Safe-Name ([string]$j.folder)
        if ($sub) { $folder = Join-Path $Save $sub }
        $file = Join-Path $folder ($name + '.' + $ext)
    }
    try { [void][IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($file)) }
    catch { return '{"ok":false,"error":"could not make the downloads folder"}' }
    try {
        $drive = New-Object IO.DriveInfo ([IO.Path]::GetPathRoot($file))
        if ($drive.AvailableFreeSpace -lt ($total + 2GB)) { return '{"ok":false,"error":"not enough free space on the disk"}' }
    } catch {}

    # What is already there is kept only when it is part of this very file.
    $part = $file + '.part'
    $have = File-Size $part
    if (-not ($old -and $old.total -eq $total -and $have -gt 0 -and $have -lt $total)) {
        try { if ([IO.File]::Exists($part)) { [IO.File]::Delete($part) } } catch {}
    }
    try { $p = Run-Curl $url $part } catch { return '{"ok":false,"error":"could not start the download"}' }

    if ($old) { [void]$downloads.Remove($old) }
    $title = [string]$j.title
    $subtitle = [string]$j.sub
    if ($old -and -not $title) { $title = $old.title; $subtitle = $old.sub }
    $e = @{ key = $id; type = $type; id = $id; title = (Clip $title 200); sub = (Clip $subtitle 200); q = (Clip ([string]$j.q) 80)
        file = $file; total = $total; at = [int64](([DateTime]::UtcNow - [DateTime]'1970-01-01').TotalSeconds)
        state = 'downloading'; pid = $p.Id; tries = 0; seen = [int64]0; wait = $null }
    [void]$downloads.Add($e)
    $dlProcs[$id] = $p
    $dlUrls[$id] = $url
    Save-Downloads
    return '{"ok":true}'
}

# Looked at in the quiet moments, and whenever the page asks for the list. A download whose
# curl has gone is finished when the whole file is there. Otherwise the connection was cut:
# it is started again a few seconds later, up to eight times in a row without any progress.
function Watch-Downloads {
    $changed = $false
    foreach ($e in @($downloads.ToArray())) {
        if ($e.state -ne 'downloading') { continue }
        if ($e.wait) {
            if ((Get-Date) -lt $e.wait) { continue }
            $e.wait = $null
            try {
                $p = Run-Curl $dlUrls[$e.key] ($e.file + '.part')
                $dlProcs[$e.key] = $p
                $e.pid = $p.Id
            } catch { $e.state = 'failed'; $e.pid = 0 }
            $changed = $true
            continue
        }
        $alive = $false
        try {
            $p = $dlProcs[$e.key]
            if ($p) { $alive = -not $p.HasExited }
            elseif ($e.pid) {
                # started by an earlier run of this server
                $q = Get-Process -Id $e.pid -ErrorAction SilentlyContinue
                if ($q -and $q.ProcessName -like 'curl*') { $alive = $true }
            }
        } catch {}
        if ($alive) { continue }
        $part = $e.file + '.part'
        $have = File-Size $part
        $e.pid = 0
        $dlProcs.Remove($e.key)
        $changed = $true
        if ($e.total -gt 0 -and $have -ge $e.total) {
            $e.state = 'failed'
            try {
                if ([IO.File]::Exists($e.file)) { [IO.File]::Delete($e.file) }
                [IO.File]::Move($part, $e.file)
                $e.state = 'done'
            } catch { Write-Log ('download: ' + $_.Exception.Message) }
            $dlUrls.Remove($e.key)
            continue
        }
        if ($have -gt $e.seen) { $e.tries = 0 }
        $e.seen = $have
        if ($dlUrls[$e.key] -and $e.tries -lt 8) {
            $e.tries = $e.tries + 1
            $e.wait = (Get-Date).AddSeconds(4)
        } else { $e.state = 'failed'; $dlUrls.Remove($e.key) }
    }
    if ($changed) { Save-Downloads }
}

function Get-Downloads {
    Watch-Downloads
    $items = New-Object System.Collections.ArrayList
    $gone = $false
    foreach ($e in @($downloads.ToArray())) {
        $have = $e.total
        if ($e.state -eq 'done') {
            # deleted by hand in the folder: forget it
            if (-not [IO.File]::Exists($e.file)) { [void]$downloads.Remove($e); $gone = $true; continue }
        } else { $have = File-Size ($e.file + '.part') }
        [void]$items.Add(@{ key = $e.key; type = $e.type; id = $e.id; title = $e.title; sub = $e.sub; q = $e.q
            total = $e.total; have = $have; state = $e.state; at = $e.at })
    }
    if ($gone) { Save-Downloads }
    return (ConvertTo-Json -InputObject @{ folder = $Save; items = $items.ToArray() } -Depth 4 -Compress)
}

# Cancels a download, or deletes a finished one from the disk.
function Remove-Download([string]$key) {
    $e = Find-Download $key
    if (-not $e) { return '{"ok":true}' }
    try {
        $p = $dlProcs[$key]
        if ($p) { if (-not $p.HasExited) { $p.Kill(); [void]$p.WaitForExit(3000) } }
        elseif ($e.pid) {
            $q = Get-Process -Id $e.pid -ErrorAction SilentlyContinue
            if ($q -and $q.ProcessName -like 'curl*') { Stop-Process -Id $e.pid -Force; Start-Sleep -Milliseconds 500 }
        }
    } catch {}
    foreach ($f in @(($e.file + '.part'), $e.file)) {
        try { if ([IO.File]::Exists($f)) { [IO.File]::Delete($f) } } catch { Write-Log ('delete: ' + $_.Exception.Message) }
    }
    $dlProcs.Remove($key)
    $dlUrls.Remove($key)
    [void]$downloads.Remove($e)
    Save-Downloads
    return '{"ok":true}'
}

function Play-Download([string]$key, [string]$at) {
    $e = Find-Download $key
    if (-not $e -or $e.state -ne 'done' -or -not [IO.File]::Exists($e.file)) { return '{"ok":false,"error":"the file is not there any more"}' }
    Note-Playing ([string]$e.type) ([string]$e.id) ([string]$e.title) ([string]$e.sub)
    return (Launch-Player $e.file $at)
}

# ----- TMDB -----
# The Movie Database is asked with your own key, kept in tmdb-key.txt next to this script.
# The key is only ever sent to api.themoviedb.org.
$tmdbBase = 'https://api.themoviedb.org/3/'
$tmdbCache = @{}       # the answers; those about one title are also kept in tmdb-cache.json
$tmdbIds = @{}         # TMDB number -> IMDb id, remembered in tmdb-ids.json
$tmdbIdsFile = Join-Path $Dir 'tmdb-ids.json'
$tmdbCacheFile = Join-Path $Dir 'tmdb-cache.json'

function Get-TmdbKey {
    $k = Read-Text 'tmdb-key.txt'
    if (-not $k) { return $null }
    $k = $k.Trim()
    if ($k -notmatch '^[A-Za-z0-9._\-]{20,}$') { return $null }
    return $k
}

function Tmdb-Get([string]$path, [string]$query) {
    $k = Get-TmdbKey
    $url = $tmdbBase + $path + '?' + $query
    $wc = New-Object System.Net.WebClient
    $wc.Encoding = $utf8
    # a long key is TMDB's "read access token", a short one its "API key"
    if ($k.Length -gt 60) { $wc.Headers.Add('Authorization', 'Bearer ' + $k) } else { $url += '&api_key=' + $k }
    try { return ConvertFrom-Json ($wc.DownloadString($url)) } finally { $wc.Dispose() }
}

function Load-TmdbIds {
    try {
        if (-not [IO.File]::Exists($tmdbIdsFile)) { return }
        $o = ConvertFrom-Json ([IO.File]::ReadAllText($tmdbIdsFile, $utf8))
        # a title without an IMDb id yet is asked again (new titles get one after a while)
        foreach ($p in $o.PSObject.Properties) { if ([string]$p.Value) { $tmdbIds[$p.Name] = [string]$p.Value } }
    } catch {}
}

function Save-TmdbIds {
    $known = @{}
    foreach ($k in @($tmdbIds.Keys)) { if ($tmdbIds[$k]) { $known[$k] = $tmdbIds[$k] } }
    try { [IO.File]::WriteAllText($tmdbIdsFile, (ConvertTo-Json -InputObject $known -Compress), $utf8) } catch {}
}

# ----- TMDB: trailers, new seasons, and titles the catalogue does not know -----
function Tmdb-Img([string]$size, $path) {
    if ($path) { return 'https://image.tmdb.org/t/p/' + $size + $path }
    return ''
}

function Tmdb-Year($day) {
    $d = [string]$day
    if ($d.Length -ge 4) { return $d.Substring(0, 4) }
    return ''
}

# The IMDb id of a TMDB title ('' when it has none), remembered in tmdb-ids.json.
function Get-ImdbOf([string]$kind, $number) {
    $key = $kind + '/' + $number
    $imdb = $tmdbIds[$key]
    if ($null -ne $imdb) { return $imdb }
    $imdb = ''
    try {
        $x = Tmdb-Get ($key + '/external_ids') 'language=en-CA'
        if ([string]$x.imdb_id -match '^tt\d+$') { $imdb = [string]$x.imdb_id }
    } catch {}
    $tmdbIds[$key] = $imdb
    $script:tmdbDirty = $true
    return $imdb
}

# 'tv/123' or 'movie/123' for an IMDb id ('' when TMDB does not know it).
function Get-TmdbRef([string]$imdb, [string]$type) {
    foreach ($k in @($tmdbIds.Keys)) {
        if ($tmdbIds[$k] -eq $imdb -and $k -match '^(tv|movie)/\d+$') { return $k }
    }
    $slot = 'ref/' + $imdb
    if ($tmdbCache.ContainsKey($slot)) { return $tmdbCache[$slot] }
    $ref = ''
    $j = Tmdb-Get ('find/' + $imdb) 'external_source=imdb_id'
    $tv = @($j.tv_results | Where-Object { $_ })
    $mv = @($j.movie_results | Where-Object { $_ })
    if ($type -eq 'movie' -and $mv.Count) { $ref = 'movie/' + $mv[0].id }
    elseif ($tv.Count) { $ref = 'tv/' + $tv[0].id }
    elseif ($mv.Count) { $ref = 'movie/' + $mv[0].id }
    if ($ref) { $tmdbIds[$ref] = $imdb; Save-TmdbIds }
    $tmdbCache[$slot] = $ref
    return $ref
}

# The trailers to show, best first: a real trailer before a teaser, in English before French, the
# official one, one that carries the title's own name.
function Pick-Trailers($videos, [string]$title) {
    $want = ($title.ToLowerInvariant() -replace '[^a-z0-9]', '')
    $rows = New-Object System.Collections.ArrayList
    $i = 0
    foreach ($v in @($videos)) {
        $i++
        if (-not $v -or $v.site -ne 'YouTube' -or [string]$v.key -notmatch '^[A-Za-z0-9_\-]{6,20}$') { continue }
        $s = 0
        if ($v.type -eq 'Trailer') { $s = 100 } elseif ($v.type -eq 'Teaser') { $s = 40 } else { continue }
        if ($v.official) { $s += 20 }
        if ($v.iso_639_1 -eq 'en') { $s += 30 } elseif ($v.iso_639_1 -eq 'fr') { $s += 10 }
        $name = ([string]$v.name).ToLowerInvariant() -replace '[^a-z0-9]', ''
        if ($want.Length -ge 4 -and $name.Contains($want)) { $s += 8 }
        if ([int]$v.size -ge 1080) { $s += 2 }
        [void]$rows.Add(@{ key = [string]$v.key; name = [string]$v.name; lang = [string]$v.iso_639_1; score = ($s * 1000 - $i) })
    }
    $out = New-Object System.Collections.ArrayList
    foreach ($r in ($rows | Sort-Object { $_.score } -Descending)) { if ($out.Count -lt 5) { [void]$out.Add(@{ key = $r.key; name = $r.name; lang = $r.lang }) } }
    return $out
}

# The episodes of one season, as the home screen lists them. Episodes without a date are left out.
function Tmdb-Episodes([string]$imdb, $season) {
    $list = New-Object System.Collections.ArrayList
    foreach ($e in @($season.episodes)) {
        if (-not $e -or -not $e.air_date) { continue }
        $sn = [int]$e.season_number
        $en = [int]$e.episode_number
        [void]$list.Add(@{ id = $imdb + ':' + $sn + ':' + $en; season = $sn; episode = $en; name = [string]$e.name
            released = ([string]$e.air_date) + 'T00:00:00.000Z'; thumbnail = (Tmdb-Img 'w300' $e.still_path); overview = [string]$e.overview })
    }
    return $list
}

# What TMDB knows about one title: its trailers, its seasons, and enough to show it when the
# catalogue does not have it (full = with every episode). An answer is good for six hours; an
# older one is still given at once, and brought up to date right after (see Answer-Slow).
function Get-TmdbInfo([string]$type, [string]$id, [string]$full) {
    if ($id -notmatch '^tt\d{5,10}$' -or $type -notmatch '^(movie|series)$') { return '{"ok":false,"error":"bad request"}' }
    if (-not (Get-TmdbKey)) { return '{"ok":false,"error":"no key"}' }
    $slot = 'info/' + $id + '/' + [bool]$full
    $c = $tmdbCache[$slot]
    if ($c -and -not $global:tmdbForce) {
        $age = ((Get-Date) - $c.at).TotalHours
        if ($age -lt 6) { return $c.json }
        if ($age -lt 720) { $global:tmdbStale = @{ type = $type; id = $id; full = $full }; return $c.json }
    }
    try {
        $ref = Get-TmdbRef $id $type
        if (-not $ref) { return '{"ok":false,"error":"not at TMDB"}' }
        $kind = $ref.Split('/')[0]
        $d = Tmdb-Get $ref 'language=en-CA&append_to_response=videos,credits&include_video_language=en,fr,null'
        $about = [string]$d.overview
        if (-not $about) { try { $about = [string](Tmdb-Get $ref 'language=fr-CA').overview } catch {} }

        $name = $d.title
        $year = Tmdb-Year $d.release_date
        $run = ''
        if ($d.runtime) { $run = ([string]$d.runtime) + ' min' }
        $seasons = New-Object System.Collections.ArrayList
        $people = New-Object System.Collections.ArrayList
        $makers = New-Object System.Collections.ArrayList
        if ($kind -eq 'tv') {
            $name = $d.name
            $year = Tmdb-Year $d.first_air_date
            if ($year) {
                if ($d.status -eq 'Ended' -or $d.status -eq 'Canceled') { $year += '-' + (Tmdb-Year $d.last_air_date) } else { $year += '-' }
            }
            $run = ''
            $times = @($d.episode_run_time | Where-Object { $_ })
            if ($times.Count) { $run = ([string]$times[0]) + ' min' }
            foreach ($s in @($d.seasons)) {
                if ($s -and [int]$s.season_number -ge 1 -and [int]$s.episode_count -gt 0) {
                    [void]$seasons.Add(@{ n = [int]$s.season_number; count = [int]$s.episode_count; date = [string]$s.air_date })
                }
            }
            foreach ($p in @($d.created_by)) { if ($p -and $p.name -and $makers.Count -lt 3) { [void]$makers.Add([string]$p.name) } }
        } else {
            foreach ($p in @($d.credits.crew)) { if ($p -and $p.job -eq 'Director' -and $makers.Count -lt 3) { [void]$makers.Add([string]$p.name) } }
        }
        foreach ($p in @($d.credits.cast)) { if ($p -and $p.name -and $people.Count -lt 5) { [void]$people.Add([string]$p.name) } }
        $genres = New-Object System.Collections.ArrayList
        foreach ($g in @($d.genres)) { if ($g -and $g.name) { [void]$genres.Add([string]$g.name) } }
        $rate = ''
        if ([int]$d.vote_count -gt 0) { $rate = ([double]$d.vote_average).ToString('0.0', [Globalization.CultureInfo]::InvariantCulture) }

        $meta = @{ name = [string]$name; description = $about; releaseInfo = $year; runtime = $run; imdbRating = $rate
            poster = (Tmdb-Img 'w342' $d.poster_path); background = (Tmdb-Img 'w1280' $d.backdrop_path)
            genres = $genres.ToArray(); cast = $people.ToArray() }
        if ($kind -eq 'tv') { $meta.writer = $makers.ToArray() } else { $meta.director = $makers.ToArray() }

        if ($full -and $kind -eq 'tv') {
            # every episode, twenty seasons to a request
            $videos = New-Object System.Collections.ArrayList
            $numbers = @($seasons | ForEach-Object { $_.n })
            for ($i = 0; $i -lt $numbers.Count; $i += 20) {
                $last = [Math]::Min($i + 19, $numbers.Count - 1)
                $part = @($numbers[$i..$last] | ForEach-Object { 'season/' + $_ })
                $r = Tmdb-Get $ref ('language=en-CA&append_to_response=' + ($part -join ','))
                foreach ($k in $part) { foreach ($e in (Tmdb-Episodes $id $r.$k)) { [void]$videos.Add($e) } }
            }
            $meta.videos = $videos.ToArray()
        }

        $json = ConvertTo-Json -InputObject @{ ok = $true; kind = $kind; trailers = @(Pick-Trailers $d.videos.results ([string]$name))
            seasons = $seasons.ToArray(); meta = $meta } -Depth 6 -Compress
        $tmdbCache[$slot] = @{ at = (Get-Date); json = $json }
        if (-not $full) { $global:tmdbCacheDirty = $true }
        return $json
    } catch {
        Write-Log ('tmdb: ' + $_.Exception.Message)
        return '{"ok":false,"error":"TMDB did not answer"}'
    }
}

# One season of a series, for the seasons the catalogue does not list yet.
function Get-TmdbSeason([string]$id, [string]$n) {
    if ($id -notmatch '^tt\d{5,10}$' -or $n -notmatch '^\d{1,3}$') { return '{"videos":[],"error":"bad request"}' }
    if (-not (Get-TmdbKey)) { return '{"videos":[],"error":"no key"}' }
    $slot = 'season/' + $id + '/' + $n
    $c = $tmdbCache[$slot]
    if ($c -and ((Get-Date) - $c.at).TotalMinutes -lt 30) { return $c.json }
    try {
        $ref = Get-TmdbRef $id 'series'
        if ($ref -notlike 'tv/*') { return '{"videos":[],"error":"not at TMDB"}' }
        $s = Tmdb-Get ($ref + '/season/' + $n) 'language=en-CA'
        $json = ConvertTo-Json -InputObject @{ videos = @(Tmdb-Episodes $id $s) } -Depth 4 -Compress
        $tmdbCache[$slot] = @{ at = (Get-Date); json = $json }
        return $json
    } catch {
        Write-Log ('tmdb season: ' + $_.Exception.Message)
        return '{"videos":[],"error":"TMDB did not answer"}'
    }
}

# Search at TMDB, which also knows titles the catalogue does not (Quebec shows, for one).
function Get-TmdbSearch([string]$text) {
    $text = ([string]$text).Trim()
    if ($text.Length -lt 2 -or $text.Length -gt 80) { return '{"metas":[]}' }
    if (-not (Get-TmdbKey)) { return '{"metas":[],"error":"no key"}' }
    $slot = 'search/' + $text.ToLowerInvariant()
    $c = $tmdbCache[$slot]
    if ($c -and ((Get-Date) - $c.at).TotalMinutes -lt 30) { return $c.json }
    try {
        $j = Tmdb-Get 'search/multi' ('include_adult=false&language=en-CA&query=' + [uri]::EscapeDataString($text))
        $metas = New-Object System.Collections.ArrayList
        $seen = 0
        foreach ($r in @($j.results)) {
            if (-not $r -or ($r.media_type -ne 'tv' -and $r.media_type -ne 'movie')) { continue }
            $seen++
            if ($seen -gt 10) { break }
            $imdb = Get-ImdbOf ([string]$r.media_type) $r.id
            if (-not $imdb) { continue }
            $name = $r.title
            $day = $r.release_date
            $type = 'movie'
            if ($r.media_type -eq 'tv') { $name = $r.name; $day = $r.first_air_date; $type = 'series' }
            [void]$metas.Add(@{ id = $imdb; type = $type; name = [string]$name; poster = (Tmdb-Img 'w342' $r.poster_path)
                background = (Tmdb-Img 'w780' $r.backdrop_path); description = [string]$r.overview; releaseInfo = (Tmdb-Year $day) })
        }
        if ($script:tmdbDirty) { Save-TmdbIds; $script:tmdbDirty = $false }
        $json = ConvertTo-Json -InputObject @{ metas = $metas.ToArray() } -Depth 4 -Compress
        $tmdbCache[$slot] = @{ at = (Get-Date); json = $json }
        return $json
    } catch {
        Write-Log ('tmdb search: ' + $_.Exception.Message)
        return '{"metas":[],"error":"TMDB did not answer"}'
    }
}

# Everything an actor played in (role 'cast'), or everything a director or creator made (role
# 'crew'), the best known first, for the page that opens from a name on an info page. Talk shows,
# the news and appearances as themselves are left out.
function Get-TmdbPerson([string]$name, [string]$role) {
    $name = ([string]$name).Trim()
    $crew = $role -eq 'crew'
    if ($name.Length -lt 2 -or $name.Length -gt 80) { return '{"metas":[]}' }
    if (-not (Get-TmdbKey)) { return '{"metas":[],"error":"no key"}' }
    $slot = 'person/' + ([string]$crew) + '/' + $name.ToLowerInvariant()
    $c = $tmdbCache[$slot]
    if ($c -and ((Get-Date) - $c.at).TotalHours -lt 12) { return $c.json }
    try {
        $found = Tmdb-Get 'search/person' ('include_adult=false&language=en-CA&query=' + [uri]::EscapeDataString($name))
        $people = @(@($found.results) | Where-Object { $_ })
        # among people of that name, the one known for that kind of work, then the best known
        $dept = 'Acting'
        if ($crew) { $dept = 'Directing|Writing|Creator|Production' }
        $same = @($people | Where-Object { ([string]$_.name).ToLowerInvariant() -eq $name.ToLowerInvariant() } |
            Sort-Object @{ Expression = { [int]([string]$_.known_for_department -match ('^(' + $dept + ')$')) }; Descending = $true }, @{ Expression = { [double]$_.popularity }; Descending = $true })
        $p = $null
        if ($same.Count) { $p = $same[0] } elseif ($people.Count) { $p = $people[0] }
        if (-not $p) { return (ConvertTo-Json -InputObject @{ metas = @(); name = $name } -Compress) }
        $credits = Tmdb-Get ('person/' + $p.id + '/combined_credits') 'language=en-CA'
        $rows = New-Object System.Collections.ArrayList
        $seen = @{}
        $from = @($credits.cast)
        if ($crew) { $from = @($credits.crew | Where-Object { $_ -and [string]$_.job -match '^(Director|Co-Director|Creator|Showrunner|Writer|Screenplay|Teleplay|Story)$' } | Sort-Object { [int]([string]$_.job -notmatch '^(Director|Creator|Showrunner)$') }) }
        foreach ($r in $from) {
            if (-not $r -or ($r.media_type -ne 'tv' -and $r.media_type -ne 'movie') -or -not $r.poster_path) { continue }
            $key = [string]$r.media_type + '/' + $r.id
            if ($seen[$key]) { continue }
            $seen[$key] = $true
            if ($crew) {
                $score = [double]$r.vote_count
                if ([string]$r.job -notmatch '^(Director|Creator|Showrunner)$') { $score = $score / 3 }
                [void]$rows.Add(@{ r = $r; score = $score })
                continue
            }
            if ([string]$r.character -match '(?i)^\s*(self|himself|herself|themselves|host|guest|narrator \(voice\))\b') { continue }
            $g = @($r.genre_ids)
            if ($g -contains 10767 -or $g -contains 10763 -or $g -contains 10764) { continue }
            $score = [double]$r.vote_count
            if ($r.media_type -eq 'tv' -and [int]$r.episode_count -le 2) { $score = $score / 6 }
            [void]$rows.Add(@{ r = $r; score = $score })
        }
        $metas = New-Object System.Collections.ArrayList
        foreach ($x in @($rows | Sort-Object { $_.score } -Descending | Select-Object -First 36)) {
            $r = $x.r
            $imdb = Get-ImdbOf ([string]$r.media_type) $r.id
            if (-not $imdb) { continue }
            $title = $r.title
            $day = $r.release_date
            $type = 'movie'
            if ($r.media_type -eq 'tv') { $title = $r.name; $day = $r.first_air_date; $type = 'series' }
            [void]$metas.Add(@{ id = $imdb; type = $type; name = [string]$title; poster = (Tmdb-Img 'w342' $r.poster_path)
                background = (Tmdb-Img 'w780' $r.backdrop_path); description = [string]$r.overview; releaseInfo = (Tmdb-Year $day); character = [string]$r.character; job = [string]$r.job })
        }
        if ($script:tmdbDirty) { Save-TmdbIds; $script:tmdbDirty = $false }
        $json = ConvertTo-Json -InputObject @{ name = [string]$p.name; picture = (Tmdb-Img 'w185' $p.profile_path); metas = $metas.ToArray() } -Depth 4 -Compress
        $tmdbCache[$slot] = @{ at = (Get-Date); json = $json }
        return $json
    } catch {
        Write-Log ('tmdb person: ' + $_.Exception.Message)
        return '{"metas":[],"error":"TMDB did not answer"}'
    }
}

# The episodes that came out after a given one (season, episode, day), for the episode list in
# the player, which reads the catalogue itself.
function Get-TmdbAfter([string]$id, [string]$s, [string]$e, [string]$day) {
    if ($id -notmatch '^tt\d{5,10}$' -or $s -notmatch '^\d{1,3}$' -or $e -notmatch '^\d{1,4}$' -or $day -notmatch '^(\d{4}-\d\d-\d\d)?$') { return '{"videos":[],"error":"bad request"}' }
    $info = ConvertFrom-Json (Get-TmdbInfo 'series' $id '')
    if (-not $info.ok) { return '{"videos":[]}' }
    $sn = [int]$s
    $en = [int]$e
    $list = New-Object System.Collections.ArrayList
    $asked = 0
    foreach ($x in @($info.seasons)) {
        if (-not $x -or $asked -ge 4) { continue }
        if ([int]$x.n -gt $sn -or ([int]$x.n -eq $sn -and [int]$x.count -gt $en)) {
            $asked++
            $j = ConvertFrom-Json (Get-TmdbSeason $id ([string]$x.n))
            foreach ($v in @($j.videos)) {
                if (-not $v) { continue }
                $out = ''
                if ($v.released -is [datetime]) { $out = $v.released.ToUniversalTime().ToString('yyyy-MM-dd') } elseif (([string]$v.released).Length -ge 10) { $out = ([string]$v.released).Substring(0, 10) }
                if (-not $out) { continue }
                if ([int]$v.season -gt $sn -or ([int]$v.episode -gt $en -and $out -gt $day)) {
                    [void]$list.Add(@{ id = [string]$v.id; season = [int]$v.season; episode = [int]$v.episode; name = [string]$v.name
                        released = $out + 'T00:00:00.000Z'; thumbnail = [string]$v.thumbnail; overview = [string]$v.overview })
                }
            }
        }
    }
    return (ConvertTo-Json -InputObject @{ videos = $list.ToArray() } -Depth 4 -Compress)
}

# The answers about single titles are kept from one session to the next, so that a trailer is
# known at once after a restart.
function Load-TmdbCache {
    try {
        if (-not [IO.File]::Exists($tmdbCacheFile)) { return }
        $o = ConvertFrom-Json ([IO.File]::ReadAllText($tmdbCacheFile, $utf8))
        foreach ($p in $o.PSObject.Properties) {
            $at = $p.Value.at
            if ($at -isnot [datetime]) { $at = [datetime]::Parse([string]$at, [Globalization.CultureInfo]::InvariantCulture, [Globalization.DateTimeStyles]::RoundtripKind) }
            $at = $at.ToLocalTime()
            if ($p.Name -like 'info/*' -and $p.Value.json) { $tmdbCache[$p.Name] = @{ at = $at; json = [string]$p.Value.json } }
        }
    } catch {}
}

function Save-TmdbCache {
    try {
        $rows = New-Object System.Collections.ArrayList
        foreach ($k in @($tmdbCache.Keys)) {
            if ($k -like 'info/*/False') { [void]$rows.Add(@{ k = $k; at = $tmdbCache[$k].at; json = $tmdbCache[$k].json }) }
        }
        $keep = @{}
        $n = 0
        foreach ($r in ($rows | Sort-Object { $_.at } -Descending)) {
            $n++
            if ($n -gt 600) { break }
            $keep[$r.k] = @{ at = $r.at.ToString('o', [Globalization.CultureInfo]::InvariantCulture); json = $r.json }
        }
        [IO.File]::WriteAllText($tmdbCacheFile, (ConvertTo-Json -InputObject $keep -Depth 3 -Compress), $utf8)
    } catch {}
}

# ----- casting: what there is to cast to -----
# Looks on your own network for a few seconds: televisions and boxes that take a video by DLNA,
# Chromecast (and Google TV) devices, and Roku players. Nothing leaves the house.
function Xml-Field([string]$xml, [string]$tag) {
    $m = [regex]::Match($xml, '<' + $tag + '>\s*([^<]*?)\s*</' + $tag + '>', 'IgnoreCase')
    if ($m.Success) { return [Net.WebUtility]::HtmlDecode($m.Groups[1].Value) }
    return ''
}

function Http-Quick([string]$url) {
    $req = [Net.HttpWebRequest]::Create($url)
    $req.Timeout = 2500
    $req.ReadWriteTimeout = 2500
    $resp = $req.GetResponse()
    try {
        $sr = New-Object IO.StreamReader($resp.GetResponseStream(), $utf8)
        try { return $sr.ReadToEnd() } finally { $sr.Dispose() }
    } finally { $resp.Close() }
}

function Port-Open([string]$ip, [int]$port) {
    $c = New-Object Net.Sockets.TcpClient
    try {
        $r = $c.BeginConnect($ip, $port, $null, $null)
        if (-not $r.AsyncWaitHandle.WaitOne(500)) { return $false }
        $c.EndConnect($r)
        return $true
    } catch { return $false } finally { $c.Close() }
}

# One answer to the search: its headers, by name in small letters.
function Read-Ssdp([string]$text) {
    $h = @{}
    foreach ($line in $text -split "`r?`n") {
        $i = $line.IndexOf(':')
        if ($i -gt 0) { $h[$line.Substring(0, $i).Trim().ToLowerInvariant()] = $line.Substring($i + 1).Trim() }
    }
    return $h
}

function Find-CastDevices {
    if ($global:castFound -and ((Get-Date) - $global:castFoundAt).TotalSeconds -lt 120) { return $global:castFound }
    $spots = @{}      # address of a description -> what answered there
    $casts = @{}      # ip -> name, for the Chromecasts that answered by name
    $socks = New-Object System.Collections.ArrayList
    $ssdp = New-Object Net.IPEndPoint -ArgumentList ([Net.IPAddress]::Parse('239.255.255.250')), 1900
    $mdns = New-Object Net.IPEndPoint -ArgumentList ([Net.IPAddress]::Parse('224.0.0.251')), 5353
    # "who is a _googlecast._tcp.local?", answers wanted straight back
    $ask = [byte[]](0,0,0,0,0,1,0,0,0,0,0,0) + [byte[]](11) + [Text.Encoding]::ASCII.GetBytes('_googlecast') + [byte[]](4) +
        [Text.Encoding]::ASCII.GetBytes('_tcp') + [byte[]](5) + [Text.Encoding]::ASCII.GetBytes('local') + [byte[]](0,0,12,128,1)
    $note = ''
    try {
        foreach ($ip in [Net.Dns]::GetHostAddresses([Net.Dns]::GetHostName())) {
            if ([string]$ip.AddressFamily -ne 'InterNetwork' -or [Net.IPAddress]::IsLoopback($ip)) { continue }
            try {
                $u = New-Object Net.Sockets.UdpClient -ArgumentList (New-Object Net.IPEndPoint -ArgumentList $ip, 0)
                [void]$socks.Add($u)
                foreach ($st in @('urn:schemas-upnp-org:device:MediaRenderer:1', 'urn:dial-multiscreen-org:service:dial:1', 'roku:ecp')) {
                    $b = [Text.Encoding]::ASCII.GetBytes("M-SEARCH * HTTP/1.1`r`nHOST: 239.255.255.250:1900`r`nMAN: `"ssdp:discover`"`r`nMX: 2`r`nST: $st`r`n`r`n")
                    [void]$u.Send($b, $b.Length, $ssdp)
                    [void]$u.Send($b, $b.Length, $ssdp)
                }
                [void]$u.Send($ask, $ask.Length, $mdns)
            } catch { $note = 'could not search from ' + $ip }
        }
        $until = (Get-Date).AddSeconds(3.5)
        while ((Get-Date) -lt $until) {
            foreach ($u in $socks) {
                while ($u.Available -gt 0) {
                    $from = New-Object Net.IPEndPoint -ArgumentList ([Net.IPAddress]::Any), 0
                    $bytes = $u.Receive([ref]$from)
                    $text = [Text.Encoding]::ASCII.GetString($bytes)
                    if ($text -like 'HTTP/*') {
                        $h = Read-Ssdp $text
                        $loc = [string]$h['location']
                        if ($loc -match '^https?://') {
                            if (-not $spots.ContainsKey($loc)) { $spots[$loc] = @{ st = ''; server = [string]$h['server'] } }
                            $spots[$loc].st += ' ' + [string]$h['st']
                        }
                    } elseif ($text -match '_googlecast') {
                        $name = ''
                        $m = [regex]::Match($text, 'fn=([\x20-\x7e]+?)(?=[\x00-\x1f]|$)')
                        if ($m.Success) { $name = $m.Groups[1].Value }
                        $casts[$from.Address.ToString()] = $name
                    }
                }
            }
            Start-Sleep -Milliseconds 80
        }
    } finally { foreach ($u in $socks) { try { $u.Close() } catch {} } }

    $byIp = @{}
    foreach ($loc in @($spots.Keys)) {
        try {
            $ip = ([uri]$loc).Host
            $xml = ''
            try { $xml = Http-Quick $loc } catch {}
            $d = $byIp[$ip]
            if (-not $d) { $d = @{ ip = $ip; name = ''; maker = ''; model = ''; dlna = $false; cast = $false; roku = $false; control = '' }; $byIp[$ip] = $d }
            $name = Xml-Field $xml 'friendlyName'
            if ($name -and (-not $d.name -or $xml -match 'MediaRenderer')) { $d.name = $name }
            if (-not $d.maker) { $d.maker = Xml-Field $xml 'manufacturer' }
            if (-not $d.model) { $d.model = Xml-Field $xml 'modelName' }
            if ($spots[$loc].st -match 'roku:ecp' -or $d.maker -match 'Roku') { $d.roku = $true }
            # where a DLNA television is told what to play
            $m = [regex]::Match($xml, '<service>(?:(?!</service>).)*?AVTransport(?:(?!</service>).)*?<controlURL>\s*([^<\s]+)\s*</controlURL>', 'Singleline,IgnoreCase')
            if ($m.Success) {
                $d.dlna = $true
                $d.control = (New-Object uri -ArgumentList ([uri]$loc), $m.Groups[1].Value).AbsoluteUri
            }
        } catch {}
    }
    foreach ($ip in @($casts.Keys)) {
        if (-not $byIp[$ip]) { $byIp[$ip] = @{ ip = $ip; name = $casts[$ip]; maker = ''; model = ''; dlna = $false; cast = $false; roku = $false; control = '' } }
        elseif ($casts[$ip] -and -not $byIp[$ip].name) { $byIp[$ip].name = $casts[$ip] }
    }
    $list = New-Object System.Collections.ArrayList
    foreach ($ip in @($byIp.Keys)) {
        $d = $byIp[$ip]
        $d.cast = (Port-Open $ip 8009)
        # a television, not a speaker: it describes itself as a device with a maker and a model
        $d.tv = [bool](($d.cast -and ($d.maker -or $d.model)) -or $d.roku)
        if (-not $d.name) { $d.name = $ip }
        [void]$list.Add($d)
    }
    $json = ConvertTo-Json -InputObject @{ devices = $list.ToArray(); note = $note } -Depth 4 -Compress
    if ($list.Count) { $global:castFound = $json; $global:castFoundAt = Get-Date }
    return $json
}

# ----- casting: Chromecast and televisions with Chromecast built in -----
# The television is spoken to directly, on your own network (port 8009). It is told the address
# of the video and fetches it itself; this PC is then only the remote control.
function Cast-Varint([int]$n) {
    $out = New-Object System.Collections.ArrayList
    do {
        $b = $n -band 0x7F
        $n = $n -shr 7
        if ($n -gt 0) { $b = $b -bor 0x80 }
        [void]$out.Add([byte]$b)
    } while ($n -gt 0)
    return ,([byte[]]$out.ToArray())
}

function Cast-Field([int]$tag, [string]$text) {
    $bytes = [Text.Encoding]::UTF8.GetBytes($text)
    return ,([byte[]](@([byte]$tag) + (Cast-Varint $bytes.Length) + $bytes))
}

function Cast-Open([string]$ip, [int]$patience = 5000) {
    $tcp = New-Object Net.Sockets.TcpClient
    $r = $tcp.BeginConnect($ip, 8009, $null, $null)
    if (-not $r.AsyncWaitHandle.WaitOne(3000)) { $tcp.Close(); throw 'the television did not answer' }
    $tcp.EndConnect($r)
    $tcp.ReceiveTimeout = $patience      # a television that is waking up takes its time
    $tcp.SendTimeout = 4000
    # the television signs its own certificate; it is a device on your network, not a web site
    $ssl = New-Object Net.Security.SslStream -ArgumentList $tcp.GetStream(), $false, ([Net.Security.RemoteCertificateValidationCallback] { $true })
    $ssl.AuthenticateAsClient($ip, $null, [Security.Authentication.SslProtocols]::Tls12, $false)
    return @{ tcp = $tcp; ssl = $ssl; n = 0 }
}

function Cast-Close($c) {
    try { $c.ssl.Close() } catch {}
    try { $c.tcp.Close() } catch {}
}

function Cast-Say($c, [string]$to, [string]$space, [string]$json) {
    $body = [byte[]](@([byte]0x08, [byte]0x00) + (Cast-Field 0x12 'sender-0') + (Cast-Field 0x1A $to) + (Cast-Field 0x22 $space) +
        @([byte]0x28, [byte]0x00) + (Cast-Field 0x32 $json))
    $len = [BitConverter]::GetBytes([int]$body.Length)
    [Array]::Reverse($len)
    $c.ssl.Write($len, 0, 4)
    $c.ssl.Write($body, 0, $body.Length)
    $c.ssl.Flush()
}

function Cast-ReadBytes($c, [int]$count) {
    $buf = New-Object byte[] $count
    $got = 0
    while ($got -lt $count) {
        $n = $c.ssl.Read($buf, $got, $count - $got)
        if ($n -le 0) { throw 'the television closed the connection' }
        $got += $n
    }
    return ,$buf
}

# The next message: its kind of talk (namespace) and what it says, read as JSON.
function Cast-Hear($c) {
    $head = Cast-ReadBytes $c 4
    [Array]::Reverse($head)
    $len = [BitConverter]::ToInt32($head, 0)
    if ($len -le 0 -or $len -gt 1048576) { throw 'unreadable answer' }
    $b = Cast-ReadBytes $c $len
    $i = 0
    $space = ''
    $text = ''
    while ($i -lt $b.Length) {
        $key = $b[$i]; $i++
        $kind = $key -band 7
        $val = 0; $shift = 0
        do { $x = $b[$i]; $i++; $val = $val -bor (($x -band 0x7F) -shl $shift); $shift += 7 } while (($x -band 0x80) -ne 0 -and $i -lt $b.Length)
        if ($kind -eq 2) {
            $s = [Text.Encoding]::UTF8.GetString($b, $i, $val)
            $i += $val
            if (($key -shr 3) -eq 4) { $space = $s } elseif (($key -shr 3) -eq 6) { $text = $s }
        }
    }
    $data = $null
    if ($text) { try { $data = ConvertFrom-Json $text } catch {} }
    return @{ space = $space; data = $data }
}

# Listens until an answer of the wanted kind comes (the television also sends news of its own).
function Cast-Wait($c, [string[]]$kinds, [int]$seconds) {
    $until = (Get-Date).AddSeconds($seconds)
    while ((Get-Date) -lt $until) {
        $m = Cast-Hear $c
        if ($m.data -and $m.data.type -eq 'PING') { Cast-Say $c 'receiver-0' 'urn:x-cast:com.google.cast.tp.heartbeat' '{"type":"PONG"}'; continue }
        if ($m.data -and ($kinds -contains [string]$m.data.type)) { return $m.data }
    }
    throw 'the television did not answer in time'
}

$castSpaceLink = 'urn:x-cast:com.google.cast.tp.connection'
$castSpaceBox = 'urn:x-cast:com.google.cast.receiver'
$castSpaceMedia = 'urn:x-cast:com.google.cast.media'
$castPlayer = 'CC1AD845'      # the plain video player every Chromecast has

# The player's own address on the television, once it runs (it is started when asked for).
function Cast-Player($c, [bool]$start) {
    Cast-Say $c 'receiver-0' $castSpaceLink '{"type":"CONNECT"}'
    Cast-Say $c 'receiver-0' $castSpaceBox '{"type":"GET_STATUS","requestId":1}'
    $st = Cast-Wait $c @('RECEIVER_STATUS') 5
    $global:castApps = (@($st.status.applications) | Where-Object { $_ } | ForEach-Object { [string]$_.displayName }) -join ', '
    $app = @($st.status.applications) | Where-Object { $_ -and $_.appId -eq $castPlayer } | Select-Object -First 1
    if (-not $app -and $start) {
        Cast-Say $c 'receiver-0' $castSpaceBox ('{"type":"LAUNCH","appId":"' + $castPlayer + '","requestId":2}')
        $until = (Get-Date).AddSeconds(25)
        while (-not $app -and (Get-Date) -lt $until) {
            $st = Cast-Wait $c @('RECEIVER_STATUS', 'LAUNCH_ERROR') 25
            if ($st.type -eq 'LAUNCH_ERROR') { throw 'the television would not start its player' }
            $app = @($st.status.applications) | Where-Object { $_ -and $_.appId -eq $castPlayer } | Select-Object -First 1
        }
    }
    if (-not $app) { return $null }
    $to = [string]$app.transportId
    Cast-Say $c $to $castSpaceLink '{"type":"CONNECT"}'
    return $to
}

function Cast-Ip([string]$ip) { return ($ip -match '^(10|192\.168|172\.(1[6-9]|2\d|3[01]))\.\d{1,3}\.\d{1,3}(\.\d{1,3})?$' -and $ip -match '^\d{1,3}(\.\d{1,3}){3}$') }

# ----- casting: Roku -----
# A Roku is spoken to on your network (port 8060), in plain web requests. Its built-in
# "Play on Roku" player is told the address of the video and fetches it itself.
function Roku-Ask([string]$ip, [string]$path, [string]$method = 'GET', [int]$wait = 4000) {
    $r = [Net.HttpWebRequest]::Create('http://' + $ip + ':8060/' + $path)
    $r.Method = $method
    $r.Timeout = $wait
    $r.ReadWriteTimeout = $wait
    $r.Proxy = $null
    if ($method -eq 'POST') { $r.ContentLength = 0 }
    $res = $r.GetResponse()
    try {
        $sr = New-Object IO.StreamReader -ArgumentList $res.GetResponseStream(), $utf8
        try { return $sr.ReadToEnd() } finally { $sr.Dispose() }
    } finally { $res.Close() }
}

# Whether a device is a Roku (and not a Chromecast); remembered while the server runs.
function Is-Roku([string]$ip) {
    if (-not $global:rokuSeen) { $global:rokuSeen = @{} }
    if ($global:rokuSeen.ContainsKey($ip)) { return $global:rokuSeen[$ip] }
    if (-not (Cast-Ip $ip)) { return $false }
    $yes = $false
    if (-not (Port-Open $ip 8009) -and (Port-Open $ip 8060)) {
        try { $yes = [bool]((Roku-Ask $ip 'query/device-info' 'GET' 2000) -match '<device-info') } catch {}
    }
    $global:rokuSeen[$ip] = $yes
    return $yes
}

# What the Roku is playing: playing, paused, buffering or idle, where it is and how long it is.
function Roku-State([string]$ip) {
    $x = Roku-Ask $ip 'query/media-player'
    $out = @{ ok = $true; state = 'idle'; pos = 0; dur = 0; title = ''; failed = $false }
    $m = [regex]::Match($x, '<player[^>]*\bstate="([a-z]+)"')
    if ($m.Success) {
        $st = $m.Groups[1].Value
        if ($st -eq 'play') { $out.state = 'playing' } elseif ($st -eq 'pause') { $out.state = 'paused' } elseif ($st -match '^(buffer|startup|open)$') { $out.state = 'buffering' }
    }
    if ($x -match '<player[^>]*\berror="true"') { $out.failed = $true }
    $m = [regex]::Match($x, '<position>\s*(\d+)\s*ms')
    if ($m.Success) { $out.pos = [int]([double]$m.Groups[1].Value / 1000) }
    $m = [regex]::Match($x, '<duration>\s*(\d+)\s*ms')
    if ($m.Success) { $out.dur = [int]([double]$m.Groups[1].Value / 1000) }
    return $out
}

function Roku-Load([string]$ip, [string]$url, [string]$title, [string]$image) {
    if (-not (Cast-Ip $ip)) { return '{"ok":false,"error":"not a device on your network"}' }
    if ($url -notmatch '^https?://[A-Za-z0-9\.\-:]+/' -or $url -match '["\s]') { return '{"ok":false,"error":"bad address"}' }
    try {
        $fmt = 'mp4'
        if ($url -match '\.mkv(\?|$)') { $fmt = 'mkv' } elseif ($url -match '\.m3u8(\?|$)') { $fmt = 'hls' }
        $q = 't=v&u=' + [uri]::EscapeDataString($url) + '&videoName=' + [uri]::EscapeDataString($title) + '&videoFormat=' + $fmt
        if ($image -match '^https://') { $q += '&k=' + [uri]::EscapeDataString($image) }
        [void](Roku-Ask $ip ('input/15985?' + $q) 'POST' 8000)
        # it first opens its player, then fetches the video: wait until it plays, or gives up
        $start = Get-Date
        $until = $start.AddSeconds(25)
        $began = $false
        while ((Get-Date) -lt $until) {
            Start-Sleep -Milliseconds 1200
            $s = $null
            try { $s = Roku-State $ip } catch { continue }
            if ($s.state -eq 'playing' -or $s.state -eq 'paused') { return '{"ok":true}' }
            if ($s.state -eq 'buffering') { $began = $true }
            elseif ($began -or ($s.failed -and (Get-Date) -gt $start.AddSeconds(8))) { return '{"ok":false,"error":"the television could not play this version"}' }
        }
        return '{"ok":true}'
    } catch {
        Write-Log ('roku: ' + $_.Exception.Message)
        return (ConvertTo-Json -InputObject @{ ok = $false; error = [string]$_.Exception.Message } -Compress)
    }
}

# The remote control of a Roku. It has no "go to this minute": going back jumps back a few
# seconds (its Instant Replay); it cannot jump forward from here.
function Roku-Remote([string]$ip, [string]$do, [string]$at) {
    try {
        if ($do -eq 'mute' -or $do -eq 'unmute') {
            [void](Roku-Ask $ip 'keypress/VolumeMute' 'POST')
            return (ConvertTo-Json -InputObject @{ ok = $true; muted = ($do -eq 'mute') } -Compress)
        }
        $s = Roku-State $ip
        if ($do -eq 'stop') {
            if ($s.state -ne 'idle') { [void](Roku-Ask $ip 'keypress/Home' 'POST') }
            return '{"ok":true,"state":"idle"}'
        }
        $press = ''
        if (($do -eq 'pause' -and $s.state -eq 'playing') -or ($do -eq 'play' -and $s.state -eq 'paused')) { $press = 'Play' }
        elseif ($do -eq 'seek' -and $at -match '^\d{1,6}$' -and [int]$at -lt $s.pos) { $press = 'InstantReplay' }
        if ($press) {
            [void](Roku-Ask $ip ('keypress/' + $press) 'POST')
            Start-Sleep -Milliseconds 500
            $s = Roku-State $ip
        }
        $s.Remove('failed')
        $s.roku = $true
        return (ConvertTo-Json -InputObject $s -Compress)
    } catch {
        Write-Log ('roku: ' + $_.Exception.Message)
        return (ConvertTo-Json -InputObject @{ ok = $false; error = [string]$_.Exception.Message } -Compress)
    }
}

# Sends one video to the television.
function Cast-Load([string]$ip, [string]$url, [string]$title, [string]$sub, [string]$image, [string]$at) {
    if (-not (Cast-Ip $ip)) { return '{"ok":false,"error":"not a device on your network"}' }
    if ($url -notmatch '^https?://[A-Za-z0-9\.\-:]+/' -or $url -match '["\s]') { return '{"ok":false,"error":"bad address"}' }
    $c = $null
    try {
        $c = Cast-Open $ip 30000
        $to = Cast-Player $c $true
        if (-not $to) { return '{"ok":false,"error":"the television would not start its player"}' }
        $kind = 'video/mp4'
        if ($url -match '\.mkv(\?|$)') { $kind = 'video/x-matroska' } elseif ($url -match '\.webm(\?|$)') { $kind = 'video/webm' }
        $meta = @{ metadataType = 0; title = $title; subtitle = $sub }
        if ($image -match '^https://') { $meta.images = @(@{ url = $image }) }
        $load = @{ type = 'LOAD'; requestId = 3; autoplay = $true; media = @{ contentId = $url; contentType = $kind; streamType = 'BUFFERED'; metadata = $meta } }
        if ($at -match '^\d{1,6}$' -and [int]$at -gt 5) { $load.currentTime = [int]$at }
        Cast-Say $c $to $castSpaceMedia (ConvertTo-Json -InputObject $load -Depth 6 -Compress)
        # the first answer only says it is fetching the video: wait until it plays, or gives up
        $until = (Get-Date).AddSeconds(25)
        while ((Get-Date) -lt $until) {
            $r = Cast-Wait $c @('MEDIA_STATUS', 'LOAD_FAILED', 'LOAD_CANCELLED', 'INVALID_REQUEST', 'ERROR') 25
            if ($r.type -ne 'MEDIA_STATUS') { return '{"ok":false,"error":"the television could not play this version"}' }
            $s = @($r.status) | Where-Object { $_ } | Select-Object -First 1
            if (-not $s) { continue }
            if ($s.playerState -eq 'PLAYING' -or $s.playerState -eq 'PAUSED') { return '{"ok":true}' }
            if ($s.playerState -eq 'IDLE' -and $s.idleReason -and $s.idleReason -ne 'INTERRUPTED') { return '{"ok":false,"error":"the television could not play this version"}' }
        }
        return '{"ok":true}'
    } catch {
        Write-Log ('cast: ' + $_.Exception.Message)
        return (ConvertTo-Json -InputObject @{ ok = $false; error = [string]$_.Exception.Message } -Compress)
    } finally { if ($c) { Cast-Close $c } }
}

# Where the television is in the video, and the remote control: pause, play, seek, stop.
function Cast-Remote([string]$ip, [string]$do, [string]$at) {
    if (-not (Cast-Ip $ip)) { return '{"ok":false,"error":"not a device on your network"}' }
    if ($do -notmatch '^(status|pause|play|seek|stop|mute|unmute)$') { return '{"ok":false,"error":"bad request"}' }
    if (Is-Roku $ip) { return (Roku-Remote $ip $do $at) }
    $c = $null
    try {
        $c = Cast-Open $ip
        if ($do -eq 'mute' -or $do -eq 'unmute') {
            # the television's own sound, whatever it is showing
            Cast-Say $c 'receiver-0' $castSpaceLink '{"type":"CONNECT"}'
            Cast-Say $c 'receiver-0' $castSpaceBox '{"type":"GET_STATUS","requestId":7}'
            $was = Cast-Wait $c @('RECEIVER_STATUS') 5
            $on = 'false'
            if ($do -eq 'mute') { $on = 'true' }
            Cast-Say $c 'receiver-0' $castSpaceBox ('{"type":"SET_VOLUME","volume":{"muted":' + $on + '},"requestId":8}')
            $now = Cast-Wait $c @('RECEIVER_STATUS') 5
            return (ConvertTo-Json -InputObject @{ ok = $true; was = [bool]$was.status.volume.muted; muted = [bool]$now.status.volume.muted; level = [double]$now.status.volume.level } -Compress)
        }
        $to = Cast-Player $c $false
        if (-not $to) { return (ConvertTo-Json -InputObject @{ ok = $true; state = 'idle'; showing = [string]$global:castApps } -Compress) }
        Cast-Say $c $to $castSpaceMedia '{"type":"GET_STATUS","requestId":4}'
        $m = Cast-Wait $c @('MEDIA_STATUS') 5
        $s = @($m.status) | Where-Object { $_ } | Select-Object -First 1
        if (-not $s) {
            if ($do -eq 'stop') { Cast-Say $c 'receiver-0' $castSpaceBox '{"type":"STOP","requestId":6}' }
            return '{"ok":true,"state":"idle"}'
        }
        $id = [int]$s.mediaSessionId
        if ($do -eq 'stop') {
            Cast-Say $c 'receiver-0' $castSpaceBox '{"type":"STOP","requestId":6}'
            Start-Sleep -Milliseconds 300
            return '{"ok":true,"state":"idle"}'
        }
        if ($do -ne 'status') {
            $say = @{ type = $do.ToUpperInvariant(); requestId = 5; mediaSessionId = $id }
            if ($do -eq 'seek') {
                if ($at -notmatch '^\d{1,6}$') { return '{"ok":false,"error":"bad request"}' }
                $say.currentTime = [int]$at
            }
            Cast-Say $c $to $castSpaceMedia (ConvertTo-Json -InputObject $say -Compress)
            $m = Cast-Wait $c @('MEDIA_STATUS') 6
            $n = @($m.status) | Where-Object { $_ } | Select-Object -First 1
            if ($n) { $s = $n }
        }
        $state = ([string]$s.playerState).ToLowerInvariant()
        $out = @{ ok = $true; state = $state; pos = [int][double]$s.currentTime; dur = 0; title = '' }
        if ($s.media) {
            if ($s.media.duration) { $out.dur = [int][double]$s.media.duration }
            if ($s.media.metadata) { $out.title = [string]$s.media.metadata.title }
        }
        return (ConvertTo-Json -InputObject $out -Compress)
    } catch {
        Write-Log ('cast: ' + $_.Exception.Message)
        return (ConvertTo-Json -InputObject @{ ok = $false; error = [string]$_.Exception.Message } -Compress)
    } finally { if ($c) { Cast-Close $c } }
}

# How well a television is likely to play a version: a plain MP4 with H.264 picture and AAC sound
# is what every one of them plays; the heavy disc copies and their sound formats are not.
function Cast-Score([string]$name, [string]$title) {
    $t = ($name + ' ' + $title).ToLowerInvariant()
    if ($name -notmatch '\[TB\+\]|instant') { return -1000 }
    $n = 0
    if ($t -match '\.mp4\b') { $n += 60 }
    if ($t -match '\b(x264|h\.?264|avc)\b') { $n += 40 }
    if ($t -match '\b(x265|h\.?265|hevc)\b') { $n += 15 }
    if ($t -match '\baac\b') { $n += 30 }
    if ($t -match '\b(ddp?|e?ac-?3|dd\+?5)') { $n += 12 }
    if ($t -match 'remux|dts|truehd|atmos|\bav1\b|\bdv\b|dolby.?vision') { $n -= 120 }
    if ($t -match '1080p') { $n += 25 } elseif ($t -match '720p') { $n += 15 } elseif ($t -match '2160p|4k') { $n += 5 }
    if ($t -match 'web') { $n += 10 }
    if ($t -match '\b(multi|dual)\b') { $n -= 10 }
    $m = [regex]::Match($title, '([\d\.]+)\s*GB')
    if ($m.Success -and [double]::Parse($m.Groups[1].Value, [Globalization.CultureInfo]::InvariantCulture) -gt 25) { $n -= 40 }
    return $n
}

# Sends a title to the television in the version it is most likely to play; when the television
# gives up on one, the next is tried.
function Cast-Title([string]$type, [string]$id, [string]$ip, [string]$at, [string]$body) {
    $name = ''
    $sub = ''
    $image = ''
    try { $j = ConvertFrom-Json $body; $name = [string]$j.name; $sub = [string]$j.sub; $image = [string]$j.image } catch {}
    $list = $null
    try { $list = ConvertFrom-Json (Get-Streams $type $id) } catch { return '{"ok":false,"error":"could not look for versions"}' }
    if ($list.error) { return (ConvertTo-Json -InputObject @{ ok = $false; error = [string]$list.error } -Compress) }
    $urls = $streamCache[$type + '/' + $id]
    $rows = New-Object System.Collections.ArrayList
    foreach ($s in @($list.streams)) {
        if (-not $s -or $null -eq $s.n -or -not $urls -or [int]$s.n -ge $urls.Count) { continue }
        $score = Cast-Score ([string]$s.name) ([string]$s.title)
        if ($score -gt -500) { [void]$rows.Add(@{ n = [int]$s.n; score = $score; q = (([string]$s.name) -replace '^\[[^\]]*\]\s*', '' -replace '(?i)torrentio\s*', '' -replace '\s+', ' ').Trim() }) }
    }
    if (-not $rows.Count) { return '{"ok":false,"error":"no version ready to play was found"}' }
    $tried = 0
    $last = '{"ok":false,"error":"the television could not play this one"}'
    $roku = Is-Roku $ip
    foreach ($r in ($rows | Sort-Object { $_.score } -Descending)) {
        $tried++
        if ($tried -gt 3) { break }
        if ($roku) { $last = Roku-Load $ip ([string]$urls[$r.n]) (($name + ' ' + $sub).Trim()) $image }
        else { $last = Cast-Load $ip ([string]$urls[$r.n]) $name $sub $image $at }
        if ($last -like '*"ok":true*') { return (ConvertTo-Json -InputObject @{ ok = $true; q = $r.q; tried = $tried } -Compress) }
        if ($last -notlike '*could not play this version*') { break }
    }
    return $last
}

# Sends a stream the page chose (by its place in the list, as for the player) to the television.
function Cast-Play([string]$type, [string]$id, [string]$n, [string]$ip, [string]$at, [string]$body) {
    $urls = $streamCache[$type + '/' + $id]
    if (-not $urls -or $n -notmatch '^\d{1,4}$' -or [int]$n -ge $urls.Count) { return '{"ok":false,"error":"unknown stream"}' }
    $name = ''
    $sub = ''
    $image = ''
    try { $j = ConvertFrom-Json $body; $name = [string]$j.name; $sub = [string]$j.sub; $image = [string]$j.image } catch {}
    if (Is-Roku $ip) { return (Roku-Load $ip ([string]$urls[[int]$n]) (($name + ' ' + $sub).Trim()) $image) }
    return (Cast-Load $ip ([string]$urls[[int]$n]) $name $sub $image $at)
}

# One value of the address's query, read as UTF-8 (accents in a search).
function Raw-Query($req, [string]$name) {
    foreach ($part in ([string]$req.Url.Query).TrimStart('?').Split('&')) {
        $kv = $part.Split('=', 2)
        if ($kv.Count -eq 2 -and $kv[0] -eq $name) { return [uri]::UnescapeDataString($kv[1].Replace('+', ' ')) }
    }
    return ''
}
Load-TmdbIds

# ----- the graphics card, and the sharpest picture this PC plays smoothly -----
# A 4K video needs a graphics card that decodes HEVC (and AV1) itself; without one it stutters.
# The cards are read once; the answer (2160 or 1080 lines) is kept in device.json, which the page
# and the player read, and is worked out again only when the cards change.
function Can-4K([string]$gpu) {
    $g = ' ' + $gpu + ' '
    if ($g -match '(?i)nvidia|geforce|quadro') {
        if ($g -match '(?i)\bRTX\b|GTX\s*(16|10)\d\d|GTX\s*9[56]0\b|GT\s*1030|MX\s*[1-5]\d0|\b(T|A)\d{3,4}\b|Tesla|TITAN\s*(X|V|RTX)') { return $true }
        return $false
    }
    if ($g -match '(?i)\bAMD\b|Radeon|ATI\b') {
        if ($g -match '(?i)RX\s*\d{4}|RX\s*[45]\d0\b|Vega|Radeon\(TM\)\s*Graphics|Radeon\s*Graphics|Radeon\s*\d{3}M\b|Radeon\s*Pro\s*W?\d{4}|Radeon\s*VII') { return $true }
        return $false
    }
    if ($g -match '(?i)intel') {
        if ($g -match '(?i)\bArc\b|Iris\(R\)\s*Xe|Iris\s*Xe|Iris\(R\)\s*Plus|Iris\s*Plus|UHD\s*Graphics\s*6[2-9]\d|UHD\s*Graphics\s*7\d\d|UHD\s*Graphics\s*$|UHD\s*Graphics\s+$|HD\s*Graphics\s*6[1-3]\d') { return $true }
        if ($g -match '(?i)UHD\s*Graphics(\(TM\))?\s*$') { return $true }
        return $false
    }
    if ($g -match '(?i)Apple|Qualcomm|Adreno|Snapdragon') { return $true }
    return $false
}

function Get-Device([bool]$fresh = $false) {
    $file = Join-Path $Dir 'device.json'
    $gpus = @()
    try { $gpus = @(Get-CimInstance -ClassName Win32_VideoController -ErrorAction Stop | ForEach-Object { ([string]$_.Name).Trim() } | Where-Object { $_ -and $_ -notmatch '(?i)basic display|remote|virtual|parsec|meta|idd' }) } catch {}
    $names = ($gpus | Sort-Object) -join ' | '
    if (-not $fresh -and [IO.File]::Exists($file)) {
        try {
            $old = ConvertFrom-Json ([IO.File]::ReadAllText($file, $utf8))
            if ($old.fixed -or ([string]$old.gpus -eq $names -and $names)) { return [IO.File]::ReadAllText($file, $utf8) }
        } catch {}
    }
    $max = 1080
    $why = 'no graphics card known to play 4K smoothly'
    foreach ($g in $gpus) { if (Can-4K $g) { $max = 2160; $why = $g + ' plays 4K'; break } }
    if (-not $gpus.Count) { $max = 2160; $why = 'the graphics card could not be read: no limit' }
    $json = ConvertTo-Json -InputObject @{ gpus = $names; max = $max; why = $why; fixed = $false } -Compress
    try { [IO.File]::WriteAllText($file, $json, $utf8) } catch {}
    Write-Log ('device: ' + $names + ' -> ' + $max)
    return $json
}
try { $deviceJson = Get-Device } catch { $deviceJson = '{"max":2160,"gpus":"","why":"not read"}' }

# ----- the opening sound -----
# The page asks for it when its opening starts; Windows plays intro.wav at once (a browser would
# only let the page make sound after a click). Loaded beforehand, so it starts without delay.
$introPlayer = $null
try {
    $introWav = Join-Path $Dir 'intro.wav'
    if ([IO.File]::Exists($introWav)) { $introPlayer = New-Object System.Media.SoundPlayer $introWav; $introPlayer.Load() }
} catch { $introPlayer = $null }
function Play-Intro {
    if (-not $script:introPlayer) { return '{"ok":false}' }
    try { $script:introPlayer.Play(); return '{"ok":true}' } catch { return '{"ok":false}' }
}

# Whether the icon and the desktop shortcut are in place.
function Get-About {
    $icon = 'false'
    $lnk = 'false'
    try {
        if (Test-Path -LiteralPath (Join-Path $Dir 'atrium.ico')) { $icon = 'true' }
        if (Test-Path -LiteralPath (Join-Path ([Environment]::GetFolderPath('Desktop')) 'Atrium.lnk')) { $lnk = 'true' }
    } catch {}
    $where = ''
    try {
        Add-Type -AssemblyName System.Windows.Forms
        $all = @([System.Windows.Forms.Screen]::AllScreens | ForEach-Object { ([string]$_.DeviceName).Split([char]0)[0] + ' ' + $_.Bounds.Width + 'x' + $_.Bounds.Height + '@' + $_.Bounds.X + ',' + $_.Bounds.Y })
        $where = (Atrium-Screen) + ' | ' + ($all -join ' ; ')
        foreach ($m in @(Get-Process -Name mpv -ErrorAction SilentlyContinue)) {
            if ($m.MainWindowHandle -ne [IntPtr]::Zero) {
                $where += ' | player ' + $m.Id + ' since ' + $m.StartTime.ToString('HH:mm:ss') + ' on ' + ([string][System.Windows.Forms.Screen]::FromHandle($m.MainWindowHandle).DeviceName).Split([char]0)[0]
            } else { $where += ' | player without a window' }
        }
    } catch {}
    return '{"icon":' + $icon + ',"shortcut":' + $lnk + ',"screens":"' + $where.Replace('\', '/') + '"}'
}

# ----- a copy to give away -----
# Builds "Atrium-portable" next to the player's folder: the player, its scripts, the controls,
# the thumbnails script, the fonts and Atrium itself, in one folder that works from anywhere on
# any Windows PC. Nothing personal goes into it: no keys, no watch positions, no lists, no logs.
# The settings file of the copy names everything from the player's own folder (~~exe_dir).
function Copy-Tree([string]$from, [string]$to) {
    [void](New-Item -ItemType Directory -Force -Path $to)
    foreach ($item in @(Get-ChildItem -LiteralPath $from -Force)) {
        if ($item.Name -eq '.git') { continue }
        if ($item.PSIsContainer) { Copy-Tree $item.FullName (Join-Path $to $item.Name) }
        else { Copy-Item -LiteralPath $item.FullName -Destination (Join-Path $to $item.Name) -Force }
    }
}

# $carry: the key files that were put into the last portable copy by hand are taken over into the new one.
# $into: another folder to make it in (for an update package); $trial: the trial run of its player.
function Make-Portable([bool]$carry, [string]$into = '', [bool]$trial = $true) {
    $notes = New-Object System.Collections.ArrayList
    try {
        $src = Split-Path -Parent $Dir
        $earlier = @(Get-ChildItem -LiteralPath (Split-Path -Parent $src) -Directory -Filter 'Atrium-portable*' | Sort-Object LastWriteTime -Descending)
        $out = Join-Path (Split-Path -Parent $src) 'Atrium-portable'
        if (Test-Path -LiteralPath $out) { $out = $out + '-' + (Get-Date).ToString('yyyyMMdd-HHmmss') }
        if ($into) { $out = $into; $carry = $false }
        $root = Join-Path $out 'Atrium'
        $cfg = Join-Path $root 'mpv'
        [void](New-Item -ItemType Directory -Force -Path $cfg)

        # the player: everything next to mpv.exe, except its settings folder
        foreach ($item in @(Get-ChildItem -LiteralPath $src -Force)) {
            if ($item.PSIsContainer) { if ($item.Name -ne 'mpv') { Copy-Tree $item.FullName (Join-Path $root $item.Name) } }
            else { Copy-Item -LiteralPath $item.FullName -Destination (Join-Path $root $item.Name) -Force }
        }
        if (-not (Test-Path -LiteralPath (Join-Path $root 'mpv.exe'))) { [void]$notes.Add('mpv.exe was not found next to the settings folder') }

        # Atrium and the player's scripts; nothing personal
        $keep = @('input.conf', 'fonts.conf', 'home.html', 'home-server.ps1', 'Home.vbs', 'atrium.png', 'atrium.ico', 'tmdb-ids.json', 'intro.wav')
        foreach ($f in @(Get-ChildItem -LiteralPath $Dir -File -Force)) {
            $isScript = $f.Extension -eq '.lua' -and $f.Name -notlike 'atrium-test*'
            if ($isScript -or ($keep -contains $f.Name)) { Copy-Item -LiteralPath $f.FullName -Destination (Join-Path $cfg $f.Name) -Force }
        }

        # what the settings file points at elsewhere on this computer comes along
        $conf = [IO.File]::ReadAllText((Join-Path $Dir 'mpv.conf'), $utf8)
        $m = [regex]::Match($conf, '([A-Za-z]:[^;\r\n"]*?)/scripts/uosc(?=[;\r\n]|$)')
        if ($m.Success) {
            $uosc = $m.Groups[1].Value
            if (Test-Path -LiteralPath $uosc) {
                Copy-Tree $uosc (Join-Path $root 'uosc')
                $conf = $conf.Replace($uosc, '~~exe_dir/uosc')
            } else { [void]$notes.Add('the controls folder was not found: ' + $uosc) }
        }
        $m = [regex]::Match($conf, '[A-Za-z]:[^;\r\n"]*?/thumbfast\.lua')
        if ($m.Success) {
            $thumb = $m.Value
            if (Test-Path -LiteralPath $thumb) {
                [void](New-Item -ItemType Directory -Force -Path (Join-Path $root 'thumbfast'))
                Copy-Item -LiteralPath $thumb -Destination (Join-Path $root 'thumbfast\thumbfast.lua') -Force
                $conf = $conf.Replace($thumb, '~~exe_dir/thumbfast/thumbfast.lua')
            } else { [void]$notes.Add('the thumbnails script was not found: ' + $thumb) }
        }
        $m = [regex]::Match($conf, '(?m)^osd-fonts-dir=([A-Za-z]:[^\r\n]*)$')
        if ($m.Success) {
            $fonts = $m.Groups[1].Value.Trim()
            if (Test-Path -LiteralPath $fonts) {
                Copy-Tree $fonts (Join-Path $root 'fonts')
                $conf = $conf.Replace('osd-fonts-dir=' + $fonts, 'osd-fonts-dir=~~exe_dir/fonts')
            } else { [void]$notes.Add('the fonts folder was not found: ' + $fonts) }
        }
        if ($conf -match '(?i)[A-Za-z]:[/\\]users[/\\]') { [void]$notes.Add('the settings file still names a folder of this computer') }
        [IO.File]::WriteAllText((Join-Path $cfg 'mpv.conf'), $conf, $utf8)

        # the sharpening filters for animation
        $a4k = Join-Path $cfg 'anime4k.lua'
        if (Test-Path -LiteralPath $a4k) {
            $lua = [IO.File]::ReadAllText($a4k, $utf8)
            $m = [regex]::Match($lua, 'local DIR = "([A-Za-z]:[^"]+)"')
            if ($m.Success) {
                $shaders = $m.Groups[1].Value.TrimEnd('/', '\')
                if (Test-Path -LiteralPath $shaders) {
                    [void](New-Item -ItemType Directory -Force -Path (Join-Path $root 'anime4k'))
                    foreach ($g in @(Get-ChildItem -LiteralPath $shaders -File -Filter '*.glsl')) { Copy-Item -LiteralPath $g.FullName -Destination (Join-Path $root ('anime4k\' + $g.Name)) -Force }
                } else { [void]$notes.Add('the Anime4K folder was not found: ' + $shaders) }
                $lua = $lua.Replace($m.Value, 'local DIR = "~~exe_dir/anime4k/"')
                [IO.File]::WriteAllText($a4k, $lua, $utf8)
            }
        }

        # which version it is, where it looks for updates, and the key that proves an update
        # comes from this PC (only its public half: it can check, not sign)
        if (-not (Read-JsonFile 'version.json')) {
            $now = Get-Date
            [IO.File]::WriteAllText((Join-Path $Dir 'version.json'), (ConvertTo-Json -InputObject @{ version = ($now.ToString('yyyy.M.d.') + [string]([int]$now.ToString('HHmmss'))); date = $now.ToString('yyyy-MM-dd HH:mm') } -Compress), $utf8)
        }
        Copy-Item -LiteralPath (Join-Path $Dir 'version.json') -Destination (Join-Path $cfg 'version.json') -Force
        $source = ''
        $pubInfo = Read-JsonFile 'update-publish.json'
        if ($pubInfo -and [string]$pubInfo.source -match '^https://') { $source = [string]$pubInfo.source }
        [IO.File]::WriteAllText((Join-Path $cfg 'update.json'), (ConvertTo-Json -InputObject @{ source = $source; key = (Get-SigningKey).ToXmlString($false) } -Compress), $utf8)
        if (-not $source) { [void]$notes.Add('no update address yet: this copy cannot update itself') }

        # the keys someone put into the copy before this one, when asked for
        $carried = @()
        if ($carry -and $earlier.Count -gt 0) {
            foreach ($k in @('stremio-key.txt', 'tmdb-key.txt')) {
                $from = Join-Path $earlier[0].FullName ('Atrium\mpv\' + $k)
                if (Test-Path -LiteralPath $from) { Copy-Item -LiteralPath $from -Destination (Join-Path $cfg $k) -Force; $carried += $k }
            }
        }

        # one plain file to start it, at the top
        $q = [string][char]34
        $vbs = "' Start Atrium.vbs - starts Atrium from this folder (it runs Atrium\mpv\Home.vbs)." + "`r`n" +
            'Set sh = CreateObject(' + $q + 'WScript.Shell' + $q + ')' + "`r`n" +
            'Set fso = CreateObject(' + $q + 'Scripting.FileSystemObject' + $q + ')' + "`r`n" +
            'here = fso.GetParentFolderName(WScript.ScriptFullName)' + "`r`n" +
            'target = here & ' + $q + '\Atrium\mpv\Home.vbs' + $q + "`r`n" +
            'If fso.FileExists(target) Then' + "`r`n" +
            '    sh.Run ' + $q + 'wscript.exe ' + $q + $q + $q + ' & target & ' + $q + $q + $q + $q + ', 1, False' + "`r`n" +
            'Else' + "`r`n" +
            '    MsgBox ' + $q + 'The Atrium folder is missing next to this file. Keep Start Atrium and the Atrium folder together.' + $q + ', 48, ' + $q + 'Atrium' + $q + "`r`n" +
            'End If' + "`r`n"
        [IO.File]::WriteAllText((Join-Path $out 'Start Atrium.vbs'), $vbs, [Text.Encoding]::ASCII)

        $nl = "`r`n"
        $text = 'ATRIUM - START HERE' + $nl + $nl +
            '1. Put this whole folder anywhere on a Windows 10 or 11 PC (unzip it first if it came as a zip).' + $nl +
            '2. Put the key file stremio-key.txt into the folder  Atrium\mpv  (it holds the Stremio sign-in key;' + $nl +
            '   the TorBox add-on set up on that Stremio account comes with it). Without it Atrium opens but' + $nl +
            '   has no library and cannot play.' + $nl +
            '3. Optional: put tmdb-key.txt (a key of The Movie Database) into the same folder, for more' + $nl +
            '   trailers and the newest episodes.' + $nl +
            '4. Double-click  Start Atrium  (next to this file). The first time, Atrium also puts an "Atrium"' + $nl +
            '   shortcut on the desktop; use that from then on.' + $nl +
            '   Do not open home.html yourself: Atrium only works when started this way.' + $nl + $nl +
            'Windows may ask whether to run the file, because it came from another computer.' + $nl +
            'Atrium opens in Brave, Edge or Chrome, whichever is installed. It talks only to this PC' + $nl +
            '(localhost:18731); nothing here is reachable from outside.' + $nl + $nl +
            'The key files are passwords: whoever has stremio-key.txt can use that Stremio account.' + $nl +
            'Downloads go to the Videos\Atrium folder. Watch positions are kept on this PC only.' + $nl + $nl +
            'Updates: when a new version of Atrium is ready, an Update button appears at the top of Atrium.' + $nl +
            'Press it: Atrium downloads the new version, checks it, and starts again. Nothing to send around.' + $nl
        [IO.File]::WriteAllText((Join-Path $out 'START-HERE.txt'), $text, $utf8)

        # a trial run of the copy's own player, without a window or sound: what it could not load is noted
        $check = New-Object System.Collections.ArrayList
        $loaded = 0
        if ($trial) { try {
            $before = @(Get-ChildItem -LiteralPath $cfg -File -Force | ForEach-Object { $_.Name })
            $trial = Join-Path $out 'trial.log'
            $list = @('av://lavfi:testsrc=duration=2:size=320x180:rate=10', '--vo=null', '--ao=null', '--idle=no', '--force-window=no', ('--log-file="' + $trial + '"'))
            $p = Start-Process -FilePath (Join-Path $root 'mpv.exe') -ArgumentList $list -PassThru -WindowStyle Hidden
            if (-not $p.WaitForExit(25000)) { try { $p.Kill() } catch {}; [void]$notes.Add('the trial run of the copy did not end by itself') }
            if (Test-Path -LiteralPath $trial) {
                foreach ($line in [IO.File]::ReadAllLines($trial)) {
                    if ($line -match 'Loading lua script') { $loaded++ }
                    if (($line -match '\]\[(e|f)\]\[') -and $check.Count -lt 12) { [void]$check.Add((Clip $line 220)) }
                }
                Remove-Item -LiteralPath $trial -Force
            } else { [void]$notes.Add('the trial run of the copy left no report') }
            # whatever the trial run wrote next to the scripts is taken out again
            foreach ($f in @(Get-ChildItem -LiteralPath $cfg -File -Force)) { if ($before -notcontains $f.Name) { Remove-Item -LiteralPath $f.FullName -Force } }
        } catch { [void]$notes.Add('trial run: ' + $_.Exception.Message) } }

        $files = @(Get-ChildItem -LiteralPath $out -Recurse -File -Force)
        $size = 0
        foreach ($f in $files) { $size += $f.Length }
        Write-Log ('portable copy: ' + $out)
        return (ConvertTo-Json -InputObject @{ ok = $true; folder = $out; files = $files.Count; mb = [math]::Round($size / 1MB, 1); notes = $notes.ToArray(); scripts = $loaded; trial = $check.ToArray(); keys = $carried } -Compress)
    } catch {
        Write-Log ('portable: ' + $_.Exception.Message)
        return (ConvertTo-Json -InputObject @{ ok = $false; error = [string]$_.Exception.Message; notes = $notes.ToArray() } -Compress)
    }
}

# Makes one zip file of the newest portable copy, next to it (Atrium-portable.zip), ready to send.
function Zip-Portable {
    try {
        $base = Split-Path -Parent (Split-Path -Parent $Dir)
        $found = @(Get-ChildItem -LiteralPath $base -Directory -Filter 'Atrium-portable*' | Sort-Object LastWriteTime -Descending)
        if ($found.Count -eq 0) { return '{"ok":false,"error":"no portable copy yet"}' }
        $folder = $found[0].FullName
        $zip = $folder + '.zip'
        if (Test-Path -LiteralPath $zip) { $zip = $folder + '-' + (Get-Date).ToString('yyyyMMdd-HHmmss') + '.zip' }
        Add-Type -AssemblyName System.IO.Compression.FileSystem
        [IO.Compression.ZipFile]::CreateFromDirectory($folder, $zip, [IO.Compression.CompressionLevel]::Optimal, $true)
        $keys = @()
        foreach ($k in @('stremio-key.txt', 'tmdb-key.txt')) { if (Test-Path -LiteralPath (Join-Path $folder ('Atrium\mpv\' + $k))) { $keys += $k } }
        Write-Log ('portable zip: ' + $zip)
        return (ConvertTo-Json -InputObject @{ ok = $true; zip = $zip; mb = [math]::Round((Get-Item -LiteralPath $zip).Length / 1MB, 1); keys = $keys } -Compress)
    } catch {
        Write-Log ('zip: ' + $_.Exception.Message)
        return (ConvertTo-Json -InputObject @{ ok = $false; error = [string]$_.Exception.Message } -Compress)
    }
}

# ----- updates -----
# This PC makes each new version of Atrium into one small package (atrium-update-<version>.zip
# and latest.json, in the Atrium-update folder next to the player's folder), which is put online.
# The copies given away look there; when their Update button is pressed they fetch the package,
# check that it really comes from this PC, and put the new files in place. Only Atrium's own
# files are in it: never a key, a list, a watch position or the player itself. The signature can
# only be made with update-signing-key.txt, which never leaves this PC (it is a password: a
# copy, a backup or the package never takes it along).
function Read-JsonFile([string]$name) {
    $p = Join-Path $Dir $name
    if (-not [IO.File]::Exists($p)) { return $null }
    try { return ConvertFrom-Json ([IO.File]::ReadAllText($p, $utf8)) } catch { return $null }
}

function Atrium-Version {
    $v = Read-JsonFile 'version.json'
    if ($v -and [string]$v.version -match '^\d+(\.\d+){1,3}$') { return [string]$v.version }
    return '0.0'
}

function As-Version([string]$s) {
    try {
        $p = @(([string]$s).Split('.') | ForEach-Object { [int]$_ })
        while ($p.Count -lt 2) { $p += 0 }
        return [version]($p -join '.')
    } catch { return [version]'0.0' }
}

function New-Rsa {
    try { return (New-Object Security.Cryptography.RSACng -ArgumentList 2048) } catch {}
    return [Security.Cryptography.RSA]::Create(2048)
}

# The signing key of this PC, made the first time it is needed.
function Get-SigningKey {
    $p = Join-Path $Dir 'update-signing-key.txt'
    $rsa = New-Rsa
    if ([IO.File]::Exists($p)) { $rsa.FromXmlString([IO.File]::ReadAllText($p, $utf8)); return $rsa }
    [IO.File]::WriteAllText($p, $rsa.ToXmlString($true), $utf8)
    Write-Log 'update: made the signing key'
    return $rsa
}

function Sha256-Hex([string]$path) {
    $sha = [Security.Cryptography.SHA256]::Create()
    $fs = [IO.File]::OpenRead($path)
    try { return (($sha.ComputeHash($fs) | ForEach-Object { $_.ToString('x2') }) -join '') } finally { $fs.Dispose(); $sha.Dispose() }
}

# What the signature covers: the version, the package's name, its fingerprint and its size.
function Update-Message($l) {
    return $utf8.GetBytes('atrium-update|' + [string]$l.version + '|' + [string]$l.file + '|' + [string]$l.sha256 + '|' + [string]$l.size)
}

# Only Atrium's own kinds of files, inside its own folders, may be in a package.
function Update-PathOk([string]$rel) {
    if ($rel -notmatch '^(mpv|uosc|thumbfast)/[A-Za-z0-9 _.()+\-/]+$' -or $rel -match '\.\.|//|/$') { return $false }
    # (lists, watch positions and keys are .json, .txt and .log files: never taken in, apart from these two)
    if ($rel -match '(?i)^mpv/[^/]+\.json$') { return ($rel -match '^mpv/(version|update)\.json$') }
    return ($rel -match '(?i)\.(html|ps1|lua|conf|vbs|png|ico|ttf|otf|json|wav)$')
}

# The newest version online, once its signature has been checked.
function Fetch-Latest($u) {
    if ([string]$u.source -notmatch '^https://[A-Za-z0-9.\-]+/') { throw 'no update address' }
    $source = ([string]$u.source).TrimEnd('/')
    $wc = New-Object System.Net.WebClient
    $wc.Encoding = $utf8
    $wc.Headers.Add('Cache-Control', 'no-cache')
    try { $text = $wc.DownloadString($source + '/latest.json?t=' + [DateTime]::UtcNow.Ticks) } finally { $wc.Dispose() }
    $l = ConvertFrom-Json $text
    if ([string]$l.version -notmatch '^\d+(\.\d+){1,3}$' -or [string]$l.file -notmatch '^atrium-update-[\d.]+\.zip$' -or [string]$l.sha256 -notmatch '^[0-9a-f]{64}$' -or
        [string]$l.size -notmatch '^\d{1,9}$' -or [long]$l.size -gt 80MB) { throw 'the update description is not valid' }
    $rsa = New-Rsa
    $rsa.FromXmlString([string]$u.key)
    $ok = $false
    try { $ok = $rsa.VerifyData((Update-Message $l), [Convert]::FromBase64String([string]$l.sig), [Security.Cryptography.HashAlgorithmName]::SHA256, [Security.Cryptography.RSASignaturePadding]::Pkcs1) } catch {}
    if (-not $ok) { throw 'the update is not signed by the owner of Atrium: it was not installed' }
    return $l
}

# Whether a newer version is online (for the Update button of a copy).
function Check-Update {
    $cur = Atrium-Version
    $u = Read-JsonFile 'update.json'
    if (-not $u -or -not [string]$u.source -or -not [string]$u.key) { return (ConvertTo-Json -InputObject @{ enabled = $false; current = $cur } -Compress) }
    try {
        $l = Fetch-Latest $u
        $newer = (As-Version $l.version) -gt (As-Version $cur)
        return (ConvertTo-Json -InputObject @{ enabled = $true; current = $cur; latest = [string]$l.version; available = $newer; notes = [string]$l.notes; mb = [math]::Round([double]$l.size / 1MB, 1) } -Compress)
    } catch {
        return (ConvertTo-Json -InputObject @{ enabled = $true; current = $cur; available = $false; error = [string]$_.Exception.Message } -Compress)
    }
}

# Fetches the newest version, checks it, keeps what it replaces in update-backup, and puts it in
# place. The server is then started again by the page.
function Install-Update {
    $tmp = Join-Path $env:TEMP ('atrium-update-' + [guid]::NewGuid().ToString('N') + '.zip')
    $zip = $null
    try {
        $u = Read-JsonFile 'update.json'
        if (-not $u -or -not [string]$u.source) { return '{"ok":false,"error":"this copy has no update address"}' }
        $l = Fetch-Latest $u
        $cur = Atrium-Version
        if ((As-Version $l.version) -le (As-Version $cur)) { return '{"ok":false,"error":"Atrium is already up to date"}' }
        $wc = New-Object System.Net.WebClient
        try { $wc.DownloadFile(([string]$u.source).TrimEnd('/') + '/' + [string]$l.file + '?t=' + [DateTime]::UtcNow.Ticks, $tmp) } finally { $wc.Dispose() }
        if ((Get-Item -LiteralPath $tmp).Length -ne [long]$l.size -or (Sha256-Hex $tmp) -ne [string]$l.sha256) { throw 'the download was damaged or is not the signed one; try again in a few minutes' }
        Add-Type -AssemblyName System.IO.Compression, System.IO.Compression.FileSystem
        $zip = [IO.Compression.ZipFile]::OpenRead($tmp)
        $entries = @($zip.Entries | Where-Object { $_.FullName -notmatch '/$' })
        foreach ($e in $entries) { if (-not (Update-PathOk ($e.FullName.Replace('\', '/')))) { throw ('unexpected file in the update: ' + $e.FullName) } }
        if (-not ($entries | Where-Object { $_.FullName -eq 'mpv/home-server.ps1' })) { throw 'the update is incomplete' }
        # the new server must at least be readable, or Atrium would not start any more
        $check = Join-Path $env:TEMP ('atrium-check-' + [guid]::NewGuid().ToString('N') + '.ps1')
        try {
            [IO.Compression.ZipFileExtensions]::ExtractToFile(($entries | Where-Object { $_.FullName -eq 'mpv/home-server.ps1' } | Select-Object -First 1), $check, $true)
            $tok = $null; $errs = $null
            [void][System.Management.Automation.Language.Parser]::ParseFile($check, [ref]$tok, [ref]$errs)
            if ($errs -and $errs.Count) { throw 'the new version has a fault and was not installed' }
        } finally { Remove-Item -LiteralPath $check -Force -ErrorAction SilentlyContinue }
        $root = Split-Path -Parent $Dir
        $back = Join-Path $root 'update-backup'
        if (Test-Path -LiteralPath $back) { Remove-Item -LiteralPath $back -Recurse -Force }
        [void](New-Item -ItemType Directory -Force -Path $back)
        $n = 0
        foreach ($e in $entries) {
            $rel = $e.FullName.Replace('/', '\')
            $dest = Join-Path $root $rel
            if (Test-Path -LiteralPath $dest) {
                $keep = Join-Path $back $rel
                [void](New-Item -ItemType Directory -Force -Path (Split-Path -Parent $keep))
                Copy-Item -LiteralPath $dest -Destination $keep -Force
            }
            [void](New-Item -ItemType Directory -Force -Path (Split-Path -Parent $dest))
            [IO.Compression.ZipFileExtensions]::ExtractToFile($e, $dest, $true)
            $n++
        }
        Write-Log ('update: ' + $cur + ' -> ' + [string]$l.version + ', ' + $n + ' files')
        return (ConvertTo-Json -InputObject @{ ok = $true; from = $cur; version = [string]$l.version; files = $n } -Compress)
    } catch {
        Write-Log ('update: ' + $_.Exception.Message)
        return (ConvertTo-Json -InputObject @{ ok = $false; error = [string]$_.Exception.Message } -Compress)
    } finally {
        if ($zip) { $zip.Dispose() }
        Remove-Item -LiteralPath $tmp -Force -ErrorAction SilentlyContinue
    }
}

# On this PC: makes the package of the current version, signed, into the Atrium-update folder,
# ready to be put online. $notes: one line saying what is new.
function Build-Update([string]$notes) {
    $tmp = Join-Path $env:TEMP ('atrium-build-' + [guid]::NewGuid().ToString('N'))
    try {
        if (Read-JsonFile 'update.json') { return '{"ok":false,"error":"this is a copy: updates are made on the PC that gave it"}' }
        $rsa = Get-SigningKey
        $now = Get-Date
        $version = $now.ToString('yyyy.M.d.') + [string]([int]$now.ToString('HHmmss'))
        [IO.File]::WriteAllText((Join-Path $Dir 'version.json'), (ConvertTo-Json -InputObject @{ version = $version; date = $now.ToString('yyyy-MM-dd HH:mm') } -Compress), $utf8)
        $made = ConvertFrom-Json (Make-Portable $false $tmp $false)
        if (-not $made.ok) { throw ('the copy could not be made: ' + [string]$made.error) }
        $root = Join-Path $tmp 'Atrium'
        $pub = Join-Path (Split-Path -Parent (Split-Path -Parent $Dir)) 'Atrium-update'
        [void](New-Item -ItemType Directory -Force -Path $pub)
        $name = 'atrium-update-' + $version + '.zip'
        $zipPath = Join-Path $pub $name
        if (Test-Path -LiteralPath $zipPath) { Remove-Item -LiteralPath $zipPath -Force }
        Add-Type -AssemblyName System.IO.Compression, System.IO.Compression.FileSystem
        $skipped = New-Object System.Collections.ArrayList
        $count = 0
        $zip = [IO.Compression.ZipFile]::Open($zipPath, [IO.Compression.ZipArchiveMode]::Create)
        try {
            foreach ($part in @('mpv', 'uosc', 'thumbfast')) {
                $base = Join-Path $root $part
                if (-not (Test-Path -LiteralPath $base)) { continue }
                foreach ($f in @(Get-ChildItem -LiteralPath $base -Recurse -File -Force)) {
                    $rel = $part + '/' + $f.FullName.Substring($base.Length + 1).Replace('\', '/')
                    if (-not (Update-PathOk $rel)) { [void]$skipped.Add($rel); continue }
                    [void][IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip, $f.FullName, $rel, [IO.Compression.CompressionLevel]::Optimal)
                    $count++
                }
            }
        } finally { $zip.Dispose() }
        $l = [ordered]@{ version = $version; file = $name; sha256 = (Sha256-Hex $zipPath); size = [string](Get-Item -LiteralPath $zipPath).Length; date = $now.ToString('yyyy-MM-dd HH:mm'); notes = (Clip ([string]$notes) 300) }
        $l.sig = [Convert]::ToBase64String($rsa.SignData((Update-Message ([pscustomobject]$l)), [Security.Cryptography.HashAlgorithmName]::SHA256, [Security.Cryptography.RSASignaturePadding]::Pkcs1))
        [IO.File]::WriteAllText((Join-Path $pub 'latest.json'), (ConvertTo-Json -InputObject $l -Compress), $utf8)
        # the packages of earlier versions are not needed any more
        foreach ($old in @(Get-ChildItem -LiteralPath $pub -File -Filter 'atrium-update-*.zip')) { if ($old.Name -ne $name) { Remove-Item -LiteralPath $old.FullName -Force } }
        Write-Log ('update built: ' + $version + ', ' + $count + ' files')
        return (ConvertTo-Json -InputObject @{ ok = $true; version = $version; folder = $pub; file = $name; files = $count; kb = [math]::Round([double]$l.size / 1KB); skipped = $skipped.ToArray(); notes = $made.notes } -Compress)
    } catch {
        Write-Log ('update build: ' + $_.Exception.Message)
        return (ConvertTo-Json -InputObject @{ ok = $false; error = [string]$_.Exception.Message } -Compress)
    } finally {
        if (Test-Path -LiteralPath $tmp) { Remove-Item -LiteralPath $tmp -Recurse -Force -ErrorAction SilentlyContinue }
    }
}

# On this PC: where the copies look for updates (the folder online that holds latest.json).
function Set-UpdateSource([string]$url) {
    if ($url -notmatch '^https://[A-Za-z0-9.\-]+/[A-Za-z0-9._\-/]*$') { return '{"ok":false,"error":"not an https address"}' }
    [IO.File]::WriteAllText((Join-Path $Dir 'update-publish.json'), (ConvertTo-Json -InputObject @{ source = $url } -Compress), $utf8)
    return (ConvertTo-Json -InputObject @{ ok = $true; source = $url } -Compress)
}

# ----- icon and shortcut -----
# The Atrium icon: a red A on a dark rounded square. Drawn once, kept as atrium.png (the window
# icon) and atrium.ico (the shortcut icon).
function Make-Icon {
    $png = Join-Path $Dir 'atrium.png'
    $ico = Join-Path $Dir 'atrium.ico'
    if ((Test-Path -LiteralPath $png) -and (Test-Path -LiteralPath $ico)) { return }
    Add-Type -AssemblyName System.Drawing
    $bmp = New-Object System.Drawing.Bitmap 256, 256
    $g = [System.Drawing.Graphics]::FromImage($bmp)
    try {
        $g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
        $g.TextRenderingHint = [System.Drawing.Text.TextRenderingHint]::AntiAlias
        $g.Clear([System.Drawing.Color]::Transparent)
        $d = 104
        $path = New-Object System.Drawing.Drawing2D.GraphicsPath
        $path.AddArc(8, 8, $d, $d, 180, 90)
        $path.AddArc(248 - $d, 8, $d, $d, 270, 90)
        $path.AddArc(248 - $d, 248 - $d, $d, $d, 0, 90)
        $path.AddArc(8, 248 - $d, $d, $d, 90, 90)
        $path.CloseFigure()
        $dark = New-Object System.Drawing.SolidBrush ([System.Drawing.Color]::FromArgb(255, 11, 11, 13))
        $red = New-Object System.Drawing.SolidBrush ([System.Drawing.Color]::FromArgb(255, 229, 9, 20))
        $g.FillPath($dark, $path)
        $font = New-Object System.Drawing.Font('Segoe UI Black', 186, [System.Drawing.FontStyle]::Regular, [System.Drawing.GraphicsUnit]::Pixel)
        $fmt = New-Object System.Drawing.StringFormat
        $fmt.Alignment = [System.Drawing.StringAlignment]::Center
        $fmt.LineAlignment = [System.Drawing.StringAlignment]::Center
        $g.DrawString('A', $font, $red, (New-Object System.Drawing.RectangleF 0, 4, 256, 256), $fmt)
    } finally { $g.Dispose() }
    $ms = New-Object IO.MemoryStream
    $bmp.Save($ms, [System.Drawing.Imaging.ImageFormat]::Png)
    $bmp.Dispose()
    $bytes = $ms.ToArray()
    [IO.File]::WriteAllBytes($png, $bytes)
    # An .ico file can simply wrap the PNG: a 6-byte header, one 16-byte entry, the picture.
    $out = New-Object IO.MemoryStream
    $w = New-Object IO.BinaryWriter $out
    $w.Write([uint16]0); $w.Write([uint16]1); $w.Write([uint16]1)
    $w.Write([byte]0); $w.Write([byte]0); $w.Write([byte]0); $w.Write([byte]0)
    $w.Write([uint16]1); $w.Write([uint16]32); $w.Write([uint32]$bytes.Length); $w.Write([uint32]22)
    $w.Write($bytes)
    $w.Flush()
    [IO.File]::WriteAllBytes($ico, $out.ToArray())
}

# An "Atrium" shortcut on the desktop, made once. If you delete it, it stays deleted;
# delete shortcut.done as well to have it made again. A shortcut from when this was
# called "Jey" is renamed and gets the new icon.
function Make-Shortcut {
    $mark = Join-Path $Dir 'shortcut.done'
    $desk = [Environment]::GetFolderPath('Desktop')
    $lnk = Join-Path $desk 'Atrium.lnk'
    $old = Join-Path $desk 'Jey.lnk'
    $renamed = $false
    if ((Test-Path -LiteralPath $old) -and -not (Test-Path -LiteralPath $lnk)) {
        Rename-Item -LiteralPath $old -NewName 'Atrium.lnk'
        $renamed = $true
    }
    $want = '"' + (Join-Path $Dir 'Home.vbs') + '"'
    if ((Test-Path -LiteralPath $mark) -and -not $renamed) {
        # made already. If the player folder has moved or been renamed since, it is pointed here again.
        if (Test-Path -LiteralPath $lnk) {
            $sh = New-Object -ComObject WScript.Shell
            $s = $sh.CreateShortcut($lnk)
            if ($s.Arguments -ne $want) {
                $s.Arguments = $want
                $s.WorkingDirectory = $Dir
                $s.IconLocation = (Join-Path $Dir 'atrium.ico') + ',0'
                $s.Save()
                Write-Log ('shortcut now points to ' + $Dir)
            }
        }
        return
    }
    $sh = New-Object -ComObject WScript.Shell
    $s = $sh.CreateShortcut($lnk)
    $s.TargetPath = Join-Path $env:SystemRoot 'System32\wscript.exe'
    $s.Arguments = $want
    $s.WorkingDirectory = $Dir
    $s.IconLocation = (Join-Path $Dir 'atrium.ico') + ',0'
    $s.Description = 'Atrium home screen'
    $s.Save()
    Set-Content -LiteralPath $mark -Value 'The Atrium desktop shortcut was made. Delete this file to have it made again.'
    Write-Log ('shortcut made: ' + $lnk)
}

function Send-Bytes($ctx, [int]$code, [string]$type, [byte[]]$bytes) {
    $ctx.Response.StatusCode = $code
    $ctx.Response.ContentType = $type
    $ctx.Response.Headers.Add('Cache-Control', 'no-store')
    $ctx.Response.ContentLength64 = $bytes.Length
    $ctx.Response.OutputStream.Write($bytes, 0, $bytes.Length)
    $ctx.Response.OutputStream.Close()
}

function Send($ctx, [int]$code, [string]$type, [string]$text) {
    Send-Bytes $ctx $code $type ($utf8.GetBytes($text))
}

# ----- the last version that worked -----
# The page says so once it is up and running. The page and this script are then copied to the
# "backup" folder (what they replace is kept one step further back, as .old). Only what is really
# in use is copied: the page as it was last sent, this script as it was when it started. A page
# that does not start goes to /good by itself, which is the copy kept here.
function Hash-File([string]$path) {
    if (-not (Test-Path -LiteralPath $path)) { return '' }
    $sha = [Security.Cryptography.SHA256]::Create()
    try { return [Convert]::ToBase64String($sha.ComputeHash([IO.File]::ReadAllBytes($path))) } finally { $sha.Dispose() }
}
$selfHash = Hash-File $self
$servedHash = ''
$goodDir = Join-Path $Dir 'backup'

function Keep-Good {
    try {
        if (-not (Test-Path -LiteralPath $goodDir)) { [void](New-Item -ItemType Directory -Path $goodDir) }
        $pairs = @(@((Join-Path $Dir 'home.html'), $servedHash), @($self, $selfHash))
        foreach ($pair in $pairs) {
            $src = $pair[0]
            $now = Hash-File $src
            if (-not $now -or $now -ne $pair[1]) { continue }      # changed since: not known to work yet
            $good = Join-Path $goodDir (Split-Path -Leaf $src)
            if ((Hash-File $good) -eq $now) { continue }
            if (Test-Path -LiteralPath $good) { Copy-Item -LiteralPath $good -Destination ($good + '.old') -Force }
            Copy-Item -LiteralPath $src -Destination $good -Force
            Write-Log ('kept a copy of ' + (Split-Path -Leaf $src))
        }
    } catch { Write-Log ('backup: ' + $_.Exception.Message) }
    Keep-History
    return '{"ok":true}'
}

# ----- safety copies of everything that makes the player and Atrium -----
# Each time one of the scripts, the settings or the page has changed, a dated copy goes to
# backup\history (the last six of each are kept). Nothing with a key in it is copied.
function Keep-History {
    try {
        $hist = Join-Path $goodDir 'history'
        if (-not (Test-Path -LiteralPath $hist)) { [void](New-Item -ItemType Directory -Path $hist -Force) }
        $kinds = @('.lua', '.conf', '.vbs', '.ps1', '.html')
        foreach ($f in @(Get-ChildItem -LiteralPath $Dir -File)) {
            if ($kinds -notcontains $f.Extension.ToLowerInvariant()) { continue }
            $copies = @(Get-ChildItem -LiteralPath $hist -File | Where-Object { $_.Name.StartsWith($f.Name + '.', [StringComparison]::OrdinalIgnoreCase) } | Sort-Object Name)
            if ($copies.Count -and (Hash-File $copies[$copies.Count - 1].FullName) -eq (Hash-File $f.FullName)) { continue }
            Copy-Item -LiteralPath $f.FullName -Destination (Join-Path $hist ($f.Name + '.' + (Get-Date -Format 'yyyyMMdd-HHmmss'))) -Force
            for ($i = 0; $i -lt $copies.Count - 5; $i++) { Remove-Item -LiteralPath $copies[$i].FullName -Force }
        }
    } catch { Write-Log ('history: ' + $_.Exception.Message) }
}

# ----- a worker of its own for the slow questions -----
# TMDB and the search for streams can take seconds to answer. Those questions are handed to a
# second worker, so that Play, the library and the downloads never wait behind them. If the worker cannot be started, they are answered here as before.
function Answer-Slow($job) {
    $ctx = $job.ctx
    try {
        $q = $ctx.Request.QueryString
        $out = $null
        if ($job.path -eq '/api/cast/devices') { $out = Find-CastDevices }
        elseif ($job.path -eq '/api/cast/remote') {
            if ($ctx.Request.HttpMethod -ne 'POST' -and [string]$q['do'] -ne 'status') { $out = '{"ok":false,"error":"post only"}' }
            else { $out = Cast-Remote ([string]$q['ip']) ([string]$q['do']) ([string]$q['t']) }
        }
        elseif ($job.path -eq '/api/cast/title') {
            if ($ctx.Request.HttpMethod -ne 'POST') { $out = '{"ok":false,"error":"post only"}' }
            else { $out = Cast-Title ([string]$q['type']) ([string]$q['id']) ([string]$q['ip']) ([string]$q['t']) (Read-Body $ctx.Request) }
        }
        elseif ($job.path -eq '/api/cast/play') {
            if ($ctx.Request.HttpMethod -ne 'POST') { $out = '{"ok":false,"error":"post only"}' }
            else { $out = Cast-Play ([string]$q['type']) ([string]$q['id']) ([string]$q['n']) ([string]$q['ip']) ([string]$q['t']) (Read-Body $ctx.Request) }
        }
        elseif ($job.path -eq '/api/streams') { $out = Get-Streams ([string]$q['type']) ([string]$q['id']) }
        elseif ($job.path -eq '/api/tmdb/after') { $out = Get-TmdbAfter ([string]$q['id']) ([string]$q['s']) ([string]$q['e']) ([string]$q['d']) }
        elseif ($job.path -eq '/api/tmdb') { $out = Get-TmdbInfo ([string]$q['type']) ([string]$q['id']) ([string]$q['full']) }
        elseif ($job.path -eq '/api/tmdb/season') { $out = Get-TmdbSeason ([string]$q['id']) ([string]$q['n']) }
        elseif ($job.path -eq '/api/tmdb/search') { $out = Get-TmdbSearch (Raw-Query $ctx.Request 'q') }
        elseif ($job.path -eq '/api/update/check') { $out = Check-Update }
        elseif ($job.path -eq '/api/update/install') {
            if ($ctx.Request.HttpMethod -ne 'POST') { $out = '{"ok":false,"error":"post only"}' } else { $out = Install-Update }
        }
        elseif ($job.path -eq '/api/tmdb/person') { $out = Get-TmdbPerson (Raw-Query $ctx.Request 'name') (Raw-Query $ctx.Request 'role') }
        if (-not $out) { Send $ctx 404 'application/json' '{"error":"not found"}'; return }
        Send $ctx 200 'application/json; charset=utf-8' $out
    } catch {
        Write-Log ('slow: ' + $_.Exception.Message)
        try { Send $ctx 500 'application/json' '{"error":"server error"}' } catch {}
    }
    # an answer that was getting old has been given: bring it up to date now
    $old = $global:tmdbStale
    $global:tmdbStale = $null
    if ($old) {
        $global:tmdbForce = $true
        try { [void](Get-TmdbInfo $old.type $old.id $old.full) } catch {} finally { $global:tmdbForce = $false }
    }
}

$slow = $null
$slowQueue = $null
function Start-Slow {
    $names = @('Write-Log', 'Read-Text', 'Send-Bytes', 'Send', 'Get-Key', 'Http-Get', 'Http-Post', 'Get-Torrentio', 'Get-Streams',
        'Get-TmdbKey', 'Tmdb-Get', 'Load-TmdbIds', 'Save-TmdbIds', 'Tmdb-Img', 'Tmdb-Year', 'Get-ImdbOf', 'Get-TmdbRef', 'Pick-Trailers',
        'Tmdb-Episodes', 'Get-TmdbInfo', 'Get-TmdbSeason', 'Get-TmdbSearch', 'Get-TmdbPerson', 'Get-TmdbAfter', 'Load-TmdbCache', 'Save-TmdbCache', 'Raw-Query', 'Answer-Slow',
        'Xml-Field', 'Http-Quick', 'Port-Open', 'Read-Ssdp', 'Find-CastDevices', 'Read-Body', 'Cast-Varint', 'Cast-Field', 'Cast-Open', 'Cast-Close',
        'Cast-Say', 'Cast-ReadBytes', 'Cast-Hear', 'Cast-Wait', 'Cast-Player', 'Cast-Ip', 'Cast-Load', 'Cast-Remote', 'Cast-Play', 'Cast-Score', 'Cast-Title',
        'Roku-Ask', 'Roku-State', 'Is-Roku', 'Roku-Load', 'Roku-Remote',
        'Read-JsonFile', 'Atrium-Version', 'As-Version', 'New-Rsa', 'Sha256-Hex', 'Update-Message', 'Update-PathOk', 'Fetch-Latest', 'Check-Update', 'Install-Update')
    $code = '$ErrorActionPreference = ''Stop''; $tmdbCache = @{}; $tmdbIds = @{}; $torrentio = $null' + "`n"
    foreach ($n in $names) { $code += (Get-Command $n -CommandType Function).ScriptBlock.Ast.Extent.Text + "`n" }
    # between two questions, what was learnt is written down
    $code += 'Load-TmdbIds; Load-TmdbCache; $job = $null' + "`n"
    $code += 'while (-not $queue.IsCompleted) {' + "`n"
    $code += '    if ($queue.TryTake([ref]$job, 3000)) { Answer-Slow $job; $job = $null }' + "`n"
    $code += '    elseif ($global:tmdbCacheDirty) { $global:tmdbCacheDirty = $false; Save-TmdbCache }' + "`n"
    $code += '}' + "`n"
    $code += 'if ($global:tmdbCacheDirty) { Save-TmdbCache }'
    $script:slowQueue = New-Object 'System.Collections.Concurrent.BlockingCollection[object]'
    $rs = [runspacefactory]::CreateRunspace()
    $rs.Open()
    foreach ($v in @('Dir', 'utf8', 'log', 'tmdbBase', 'tmdbIdsFile', 'tmdbCacheFile', 'streamCache', 'castSpaceLink', 'castSpaceBox', 'castSpaceMedia', 'castPlayer')) { $rs.SessionStateProxy.SetVariable($v, (Get-Variable -Name $v -ValueOnly)) }
    $rs.SessionStateProxy.SetVariable('queue', $script:slowQueue)
    $ps = [powershell]::Create()
    $ps.Runspace = $rs
    [void]$ps.AddScript($code)
    [void]$ps.BeginInvoke()
    $script:slow = $ps
}
try { Start-Slow } catch { $slow = $null; $slowQueue = $null; Write-Log ('worker: ' + $_.Exception.Message) }

Write-Log "started on port $Port"
Keep-History
try { Make-Icon } catch { Write-Log ('icon: ' + $_.Exception.Message) }
try { Make-Shortcut } catch { Write-Log ('shortcut: ' + $_.Exception.Message) }

# The downloads folder was called "Jey" before. It is renamed once; if that cannot be done
# right now (a download is running into it), it stays in use until the next start.
function Rename-OldFolder {
    $old = Join-Path (Split-Path -Parent $Save) 'Jey'
    if ($old -eq $Save -or -not (Test-Path -LiteralPath $old) -or (Test-Path -LiteralPath $Save)) { return }
    try { [IO.Directory]::Move($old, $Save); Write-Log ('downloads folder renamed: ' + $Save) }
    catch { $script:Save = $old; Write-Log ('downloads folder: ' + $_.Exception.Message) }
}
try { Rename-OldFolder } catch {}
Load-Downloads

$pending = $null
while ($listener.IsListening) {
    $ctx = $null
    try {
        if (-not $pending) { $pending = $listener.BeginGetContext($null, $null) }
        # Nothing asked for: use the pause to look at the player and at the downloads.
        if (-not $pending.AsyncWaitHandle.WaitOne(700)) { Watch-Player; Watch-Downloads; continue }
        $done = $pending
        $pending = $null
        $ctx = $listener.EndGetContext($done)
        $req = $ctx.Request
        $path = $req.Url.AbsolutePath
        $q = $req.QueryString

        # Only this PC, and only our own page, may use the server.
        if ($req.Headers['Host'] -ne "localhost:$Port") { Send $ctx 403 'text/plain' 'no'; continue }

        if ($path -eq '/' -or $path -eq '/index.html') {
            $html = Read-Text 'home.html'
            if (-not $html) { Send $ctx 404 'text/plain' 'home.html is missing'; continue }
            $servedHash = Hash-File (Join-Path $Dir 'home.html')
            Send $ctx 200 'text/html; charset=utf-8' ($html.Replace('__HOME_TOKEN__', $token))
            continue
        }
        if ($path -eq '/good') {
            # the last page that worked, for when the present one does not start
            $kept = Join-Path $goodDir 'home.html'
            if (-not (Test-Path -LiteralPath $kept)) { Send $ctx 404 'text/plain' 'There is no copy of a page that worked yet.'; continue }
            Send $ctx 200 'text/html; charset=utf-8' ([IO.File]::ReadAllText($kept, $utf8).Replace('__HOME_TOKEN__', $token))
            continue
        }
        if ($path -eq '/icon.png') {
            $png = Join-Path $Dir 'atrium.png'
            if (Test-Path -LiteralPath $png) { Send-Bytes $ctx 200 'image/png' ([IO.File]::ReadAllBytes($png)) }
            else { Send $ctx 404 'text/plain' 'no icon' }
            continue
        }
        if ($path -eq '/api/show') {
            # Home.vbs asks this before opening a window: if Atrium is already open it is
            # brought to the front instead. A web page cannot send this header.
            if ($req.Headers['X-Home-Launcher'] -ne '1') { Send $ctx 403 'text/plain' 'no'; continue }
            $shown = '0'
            if (Show-Home) { $shown = '1' }
            Send $ctx 200 'text/plain' $shown
            continue
        }
        if (($path -eq '/api/tmdb/after' -or $path -eq '/api/cast/devices' -or $path -eq '/api/cast/title' -or $path -eq '/api/cast/remote') -and $req.Headers['X-Home-Player'] -eq '1') {
            # asked by the player's episode list, which has no token; a web page cannot send this header
            $job = @{ ctx = $ctx; path = $path }
            $ctx = $null
            if ($slow -and $slowQueue -and $slow.InvocationStateInfo.State -eq 'Running') { $slowQueue.Add($job) } else { Answer-Slow $job }
            continue
        }
        if ($path -eq '/api/player/focus' -and $req.Headers['X-Home-Player'] -eq '1') {
            # asked by the player when it loses the keyboard; a web page cannot send this header
            Send $ctx 200 'application/json' (Player-Focus)
            continue
        }
        if ($path -eq '/api/player/ended' -and $req.HttpMethod -eq 'POST' -and $req.Headers['X-Home-Player'] -eq '1') {
            # the player says a video played to its end and nothing follows
            $endedAt = Get-Date
            Send $ctx 200 'application/json' '{"ok":true}'
            continue
        }
        if ($path -notlike '/api/*') { Send $ctx 404 'text/plain' 'not found'; continue }
        if ($req.Headers['X-Home'] -ne $token) { Send $ctx 403 'text/plain' 'no'; continue }

        $out = $null
        if ($path -eq '/api/library') { $out = Get-Library }
        elseif ($path -eq '/api/resume') { $out = Read-Text 'resume.json'; if (-not $out) { $out = '{}' } }
        elseif ($path -eq '/api/play') {
            if ($req.HttpMethod -ne 'POST') { $out = '{"ok":false,"error":"post only"}' }
            else {
                $names = Body-Names (Read-Body $req)
                Note-Playing ([string]$q['type']) ([string]$q['id']) ([string]$names[0]) ([string]$names[1])
                $out = Start-Player $q['type'] $q['id'] ([int]$q['n']) ([string]$q['t'])
            }
        }
        elseif ($path -eq '/api/library/put') {
            if ($req.HttpMethod -ne 'POST') { $out = '{"error":"post only"}' }
            else { $out = Put-Library (Read-Body $req) }
        }
        elseif ($path -eq '/api/downloads') { $out = Get-Downloads }
        elseif ($path -eq '/api/download' -or $path -eq '/api/download/remove' -or $path -eq '/api/playfile') {
            if ($req.HttpMethod -ne 'POST') { $out = '{"ok":false,"error":"post only"}' }
            elseif ($path -eq '/api/download') { $out = Start-Download (Read-Body $req) }
            elseif ($path -eq '/api/playfile') { $out = Play-Download ([string]$q['key']) ([string]$q['t']) }
            else { $out = Remove-Download ([string]$q['key']) }
        }
        elseif ($path -eq '/api/streams' -or $path -eq '/api/cast/devices' -or $path -eq '/api/cast/remote' -or $path -eq '/api/cast/play' -or $path -eq '/api/cast/title' -or $path -eq '/api/tmdb' -or $path -eq '/api/tmdb/season' -or $path -eq '/api/tmdb/search' -or $path -eq '/api/tmdb/person' -or $path -eq '/api/update/check' -or $path -eq '/api/update/install') {
            $job = @{ ctx = $ctx; path = $path }
            $ctx = $null
            if ($slow -and $slowQueue -and $slow.InvocationStateInfo.State -eq 'Running') { $slowQueue.Add($job) } else { Answer-Slow $job }
            continue
        }
        elseif ($path -eq '/api/ok') { $out = Keep-Good }
        elseif ($path -eq '/api/trace') {
            # what the page noted about its trailers (kept in memory only), to look into one that did not play
            if ($req.HttpMethod -eq 'POST') { [void]$traceLog.Add((Get-Date -Format 'HH:mm:ss') + ' ' + (Clip (Read-Body $req) 300)); while ($traceLog.Count -gt 120) { $traceLog.RemoveAt(0) }; $out = '{"ok":true}' }
            else { $out = ConvertTo-Json -InputObject @{ lines = $traceLog.ToArray() } -Compress }
        }
        elseif ($path -eq '/api/player/stop') { $out = Stop-Player ([string]$req.QueryString['pid']) }
        elseif ($path -eq '/api/player/ended') {
            # asked by the page when it comes back in front; told once
            $out = '{"ended":false}'
            if ($endedAt -and ((Get-Date) - $endedAt).TotalSeconds -lt 60) { $out = '{"ended":true}' }
            $endedAt = $null
        }
        elseif ($path -eq '/api/sha') { $out = Get-Sha ([string]$q['f']) }
        elseif ($path -eq '/api/about') { $out = Get-About }
        elseif ($path -eq '/api/device') {
            if ([string]$q['fresh'] -eq '1') { $deviceJson = Get-Device $true }
            $out = $deviceJson
        }
        elseif ($path -eq '/api/update/build') { if ($req.HttpMethod -ne 'POST') { $out = '{"ok":false,"error":"post only"}' } else { $out = Build-Update (Read-Body $req) } }
        elseif ($path -eq '/api/update/source') { if ($req.HttpMethod -ne 'POST') { $out = '{"ok":false,"error":"post only"}' } else { $out = Set-UpdateSource ([string]$q['url']) } }
        elseif ($path -eq '/api/intro') { if ($req.HttpMethod -ne 'POST') { $out = '{"ok":false}' } else { $out = Play-Intro } }
        elseif ($path -eq '/api/version') { $out = (ConvertTo-Json -InputObject @{ version = (Atrium-Version); copy = [bool](Read-JsonFile 'update.json') } -Compress) }
        elseif ($path -eq '/api/portable/zip') { if ($req.HttpMethod -ne 'POST') { $out = '{"ok":false,"error":"post only"}' } else { $out = Zip-Portable } }
        elseif ($path -eq '/api/portable') { if ($req.HttpMethod -ne 'POST') { $out = '{"ok":false,"error":"post only"}' } else { $out = Make-Portable ([string]$q['keys'] -eq 'carry') } }
        elseif ($path -eq '/api/quit') { Send $ctx 200 'application/json' '{"ok":true}'; $listener.Stop(); break }
        elseif ($path -eq '/api/restart') {
            # After an update of this script: start the new one, then step aside.
            Send $ctx 200 'application/json' '{"ok":true}'
            $listener.Stop()
            $listener.Close()
            Start-Process -FilePath 'powershell.exe' -WindowStyle Hidden -ArgumentList @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-WindowStyle', 'Hidden', '-File', ('"' + $self + '"'), '-Wait')
            break
        }
        if (-not $out) { Send $ctx 404 'application/json' '{"error":"not found"}'; continue }
        Send $ctx 200 'application/json; charset=utf-8' $out
    } catch {
        Write-Log ('error: ' + $_.Exception.Message)
        try { if ($ctx) { Send $ctx 500 'application/json' '{"error":"server error"}' } } catch {}
        Start-Sleep -Milliseconds 100
    }
}
try { if ($slowQueue) { $slowQueue.CompleteAdding() } } catch {}
