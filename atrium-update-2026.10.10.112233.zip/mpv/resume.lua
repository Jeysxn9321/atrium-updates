-- resume.lua
-- Remembers where you stopped each video and jumps back there next time, silently.
-- Videos are recognised by what they are (series + episode, or film title), not by
-- file name, so picking a different stream of the same episode still resumes.
--
-- Hotkey: Alt+Shift+R shows how many videos have a saved position.

local utils = require 'mp.utils'

local store_path = mp.command_native({ "expand-path", "~~exe_dir/mpv/resume.json" })
local MIN_POS = 60          -- seconds: don't save a position in the first minute
local DONE_FRACTION = 0.95  -- past this point the video counts as finished
local SETTLE = 15           -- seconds after opening before positions are saved
local SAME_LENGTH = 3       -- seconds: two copies of one episode differ by less than this
local RECENT = 30 * 60      -- seconds: how long a "same length" match is trusted

local saved = {}
local key, name, episode = nil, nil, nil
local loaded_at = 0

local JUNK = { "2160p", "1440p", "1080p", "720p", "480p", "bluray", "blu ray", "bdrip", "brrip",
    "bdremux", "remux", "web dl", "webdl", "webrip", "hdtv", "dvdrip", "x264", "x265",
    "h264", "h265", "hevc", "uhd", "10bit" }

local function trim(s)
    s = s:gsub("%s+", " ")
    s = s:gsub("^[%s%-:,]+", "")
    s = s:gsub("[%s%-:,]+$", "")
    return s
end

-- Position of the first year (1900-2099) or release detail in the text, if any.
local function details_start(s)
    local cut = nil
    for _, pat in ipairs({ "%f[%d]19%d%d%f[%D]", "%f[%d]20%d%d%f[%D]" }) do
        local p = s:find(pat, 3)
        if p and (not cut or p < cut) then cut = p end
    end
    local year = cut
    for _, word in ipairs(JUNK) do
        local p = s:find(" " .. word, 1, true)
        if p and p > 1 and (not cut or p < cut) then cut = p end
    end
    return cut, year
end

-- Turns a title or file name into: key, name, episode number (nil for films).
local function identify(title)
    local s = (title or ""):lower()
    for _, ext in ipairs({ "mkv", "mp4", "avi", "m4v", "webm", "mov", "ts" }) do
        s = s:gsub("%." .. ext .. "$", "")
    end
    s = s:gsub("%((%d%d%d%d)%)", " %1 ")
    s = s:gsub("%b[]", " ")
    s = s:gsub("%b()", " ")
    s = s:gsub("[%._]", " ")
    s = " " .. trim(s) .. " "
    local cut, year = details_start(s)
    local head = cut and s:sub(1, cut - 1) or s

    local a, season, ep
    a, _, season, ep = s:find("%f[%a]s(%d+)%s*e(%d+)")
    if not a then a, _, season, ep = s:find("%f[%d](%d%d?)x(%d%d%d?)%f[%D]") end
    if not a then a, _, ep = s:find("%f[%a]episode%s*(%d+)") end
    if not a then a, _, ep = s:find("%f[%a]ep%s*(%d+)") end
    if not a then a, _, ep = s:find("%f[%a]e(%d+)%f[%D]") end
    if not a then a, _, ep = s:find("%s%-%s+(%d%d?%d?)%f[%D]") end
    if not a then
        a, _, ep = s:find("%s%-%s+(%d%d%d%d)%f[%D]")
        if a and (ep:sub(1, 2) == "19" or ep:sub(1, 2) == "20") then a, ep = nil, nil end
    end
    if not a then a, _, ep = head:find("%s(%d%d%d?)%s", 3) end

    if a then
        local n = trim(s:sub(1, a - 1))
        local c = details_start(" " .. n .. " ")
        if c and c > 2 then n = trim(n:sub(1, c - 2)) end
        local id = "e" .. tonumber(ep)
        if season then id = "s" .. tonumber(season) .. id end
        return n .. "|" .. id, n, tonumber(ep)
    end

    -- A film: keep the title and year, drop the release details after them.
    local n = trim(head)
    if year and year == cut then return n .. " " .. s:sub(year, year + 3), n, nil end
    return n, n, nil
end

local function load_store()
    saved = {}
    local f = io.open(store_path, "r")
    if not f then return end
    local data = utils.parse_json(f:read("*a") or "")
    f:close()
    if type(data) ~= "table" then return end
    for k, v in pairs(data) do
        if type(v) == "table" and tonumber(v.pos) then
            saved[k] = v
        elseif tonumber(v) then
            -- Older format: file title -> seconds.
            local nk, nn, ne = identify(k)
            local old = saved[nk]
            if not old or (not old.at and tonumber(v) > old.pos) then
                saved[nk] = { pos = tonumber(v), name = nn, ep = ne }
            end
        end
    end
end

local function save_store()
    local f = io.open(store_path, "w")
    if not f then return end
    f:write(utils.format_json(saved))
    f:close()
end

local function current_title()
    local title = mp.get_property("media-title")
    if title and title ~= "" then return title end
    return mp.get_property("filename")
end

local function starts_with(long, short)
    return short ~= "" and long:sub(1, #short) == short
end

-- Finds the saved position for this video: same key first, then another copy of
-- the same episode (same series name, or same length and saved a moment ago).
local function find_saved()
    if saved[key] then return key end
    local dur = mp.get_property_number("duration")
    local now = os.time()
    local best, best_at = nil, -1
    for k, v in pairs(saved) do
        if v.ep == episode then
            local same_name = episode and v.name
                and (starts_with(v.name, name) or starts_with(name, v.name))
            local same_length = dur and v.dur and math.abs(v.dur - dur) <= SAME_LENGTH
                and v.at and now - v.at <= RECENT
            if (same_name or same_length) and (v.at or 0) > best_at then
                best, best_at = k, v.at or 0
            end
        end
    end
    return best
end

local function remember()
    if not key then return end
    if mp.get_time() - loaded_at < SETTLE then return end
    local pos = mp.get_property_number("time-pos")
    local dur = mp.get_property_number("duration")
    if not pos or not dur or dur <= 0 then return end
    if pos < MIN_POS or pos / dur > DONE_FRACTION then
        if saved[key] then
            saved[key] = nil
            save_store()
        end
        return
    end
    saved[key] = { pos = math.floor(pos), dur = math.floor(dur), at = os.time(),
        name = name, ep = episode }
    save_store()
end

mp.register_event("file-loaded", function()
    load_store()
    key, name, episode = identify(current_title())
    loaded_at = mp.get_time()
    local found = find_saved()
    if not found then return end
    local entry = saved[found]
    if found ~= key then
        saved[key] = entry
        saved[found] = nil
        save_store()
    end
    local pos = tonumber(entry.pos)
    if pos and pos >= MIN_POS then
        mp.commandv("seek", tostring(math.max(pos - 5, 0)), "absolute")
    end
end)

mp.add_periodic_timer(10, remember)
mp.add_hook("on_unload", 50, function()
    loaded_at = 0
    remember()
    key = nil
end)

mp.add_key_binding("Alt+R", "resume-status", function()
    local n = 0
    for _ in pairs(saved) do n = n + 1 end
    mp.osd_message(string.format("Resume: on (%d saved)", n), 2.5)
end)

load_store()
