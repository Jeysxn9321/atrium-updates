' Home.vbs - opens Atrium, the home screen. If it is already open, brings it to the front.
Set sh = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
here = fso.GetParentFolderName(WScript.ScriptFullName)

' Ask the home server (if it is running) whether a Atrium window is open; it then shows it.
On Error Resume Next
Set http = CreateObject("WinHttp.WinHttpRequest.5.1")
http.SetTimeouts 400, 400, 2500, 2500
http.Open "GET", "http://localhost:18731/api/show", False
http.SetRequestHeader "X-Home-Launcher", "1"
http.Send
If Err.Number = 0 Then
    If http.Status = 200 And http.ResponseText = "1" Then WScript.Quit
End If
Err.Clear
On Error GoTo 0

sh.Run "powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File """ & here & "\home-server.ps1""", 0, False
WScript.Sleep 1500
' Atrium opens as a window of its own in Brave, Edge or Chrome, whichever is there first;
' with none of them, as a page in the usual browser.
pf = sh.ExpandEnvironmentStrings("%ProgramFiles%")
pf86 = sh.ExpandEnvironmentStrings("%ProgramFiles(x86)%")
loc = sh.ExpandEnvironmentStrings("%LocalAppData%")
places = Array(pf & "\BraveSoftware\Brave-Browser\Application\brave.exe", _
    pf86 & "\BraveSoftware\Brave-Browser\Application\brave.exe", _
    loc & "\BraveSoftware\Brave-Browser\Application\brave.exe", _
    pf86 & "\Microsoft\Edge\Application\msedge.exe", _
    pf & "\Microsoft\Edge\Application\msedge.exe", _
    pf & "\Google\Chrome\Application\chrome.exe", _
    pf86 & "\Google\Chrome\Application\chrome.exe", _
    loc & "\Google\Chrome\Application\chrome.exe")
found = ""
For Each place In places
    If found = "" Then
        If fso.FileExists(place) Then found = place
    End If
Next
' It runs in a browser profile of its own (in AppData\Local\Atrium\browser): closing Atrium can then
' never close your other tabs and windows, and it always starts with sound allowed.
If found <> "" Then
    prof = loc & "\Atrium\browser"
    sh.Run """" & found & """ --app=http://localhost:18731/ --user-data-dir=""" & prof & """ --no-first-run --no-default-browser-check --start-maximized --autoplay-policy=no-user-gesture-required", 1, False
Else
    sh.Run "http://localhost:18731/", 1, False
End If
