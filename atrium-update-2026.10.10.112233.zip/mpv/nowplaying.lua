-- nowplaying.lua
-- 1. Shows the real name of what is playing at the top left, in Atrium's own lettering
--    ("BREAKING BAD", and under it "S1:E2 - Cat's in the Bag..."), instead of the name of the
--    file. It comes and goes with the mouse, like the buttons. (The player's own title line is
--    switched off in mpv.conf: uosc-top_bar_title=no.)
-- 2. When the video has been paused for a few seconds, dims the picture and shows what you are
--    watching: the title, the episode and what it is about. Moving the mouse, or playing
--    again, puts it away.
--
-- 4. Tells Atrium when a video has played to its end, so that it goes back to its main page,
--    and closes the player at that point.
-- 3. Puts a cast button at the top right, next to the window buttons: it sends what is playing
--    to your television (in a version the television can play) and pauses here. Pressed again,
--    it brings the video back to this screen at the point the television had reached.
--
-- Atrium says what it starts (now-playing.json, written by the home server next to this
-- script); the episode's name and its summary are then asked from the catalogue. For a video
-- opened another way, the name is worked out from the file name as well as can be.

local utils = require 'mp.utils'

local WAIT = 5              -- seconds of pause, without the mouse moving, before the screen shows
local FRESH = 600           -- seconds a note from Atrium is taken to be about the video that opens
local DIM = "70"            -- how dark the picture gets (00 = black, FF = untouched)
local CINEMETA = "https://v3-cinemeta.strem.io/meta/"
local KITSU = "https://anime-kitsu.strem.fun/meta/"
local DOT = " \194\183 "

local now = nil             -- { name, type, id, season, episode, ep_name, about, year, sub }
local first = true          -- the first video of this player: the one Atrium started
local from_atrium = false   -- whether Atrium started this player
local default_title = mp.get_property("title")
local metas = {}            -- catalogue answers, by id
local loaded = 0            -- counts the videos, so a late answer about the last one is dropped

-- ===== what is playing =====

local function trim(s)
    return (tostring(s or ""):gsub("%s+", " "):gsub("^%s+", ""):gsub("%s+$", ""))
end

local JUNK = { "2160p", "1440p", "1080p", "720p", "480p", "bluray", "blu ray", "bdrip", "brrip", "bdremux",
    "remux", "web dl", "webdl", "webrip", "hdtv", "dvdrip", "x264", "x265", "h264", "h265", "hevc", "uhd", "10bit",
    "complete", "multi", "dual audio" }

-- Season and episode numbers out of a file name: nil, nil when it has none.
local function numbers(text)
    local s = " " .. tostring(text or ""):lower():gsub("[%._]", " ") .. " "
    local season, ep = s:match("%f[%a]s(%d+)%s*e(%d+)")
    if not ep then season, ep = s:match("%f[%d](%d%d?)x(%d%d%d?)%f[%D]") end
    if not ep then ep = s:match("%f[%a]episode%s*(%d+)") end
    if not ep then ep = s:match("%f[%a]ep?%s*(%d+)%f[%D]") end
    if not ep then ep = s:match("%s%-%s+(%d%d?%d?%d?)%f[%D]") end
    return tonumber(season), tonumber(ep)
end

-- A presentable name out of a file name, for a video Atrium did not start.
local function tidy(text)
    local s = tostring(text or "")
    s = s:gsub("%.%w%w%w?%w?$", ""):gsub("%b[]", " "):gsub("[%._]", " ")
    local low = " " .. s:lower() .. " "
    local cut = #low
    for _, pat in ipairs({ "%f[%a]s%d+%s*e%d+", "%f[%d]%d%d?x%d%d%d?%f[%D]", "%f[%d]19%d%d%f[%D]", "%f[%d]20%d%d%f[%D]", "%s%-%s+%d+%f[%D]" }) do
        local p = low:find(pat, 3)
        if p and p < cut then cut = p end
    end
    for _, word in ipairs(JUNK) do
        local p = low:find(" " .. word, 1, true)
        if p and p > 2 and p < cut then cut = p end
    end
    local name = trim(s:sub(1, math.max(1, cut - 2)):gsub("[%(%-:,%s]+$", ""))
    if name == "" then name = trim(s) end
    return name
end

local function read_note()
    local ok, path = pcall(mp.command_native, { "expand-path", "~~exe_dir/mpv/now-playing.json" })
    if not ok or type(path) ~= "string" then return nil end
    local f = io.open(path, "r")
    if not f then return nil end
    local data = utils.parse_json(f:read("*a") or "")
    f:close()
    if type(data) ~= "table" or type(data.id) ~= "string" or type(data.name) ~= "string" or data.name == "" then return nil end
    if os.time() - (tonumber(data.at) or 0) > FRESH then return nil end
    return data
end

-- "tt0903747:1:2" -> tt0903747, 1, 2;  "kitsu:43248:5" -> kitsu:43248, nil, 5;  "tt0468569" -> tt0468569
local function split_id(id)
    local root, a, b = id:match("^(tt%d+):(%d+):(%d+)$")
    if root then return root, tonumber(a), tonumber(b) end
    root, a = id:match("^(kitsu:%d+):(%d+)$")
    if root then return root, nil, tonumber(a) end
    return id, nil, nil
end

local function episode_tag(n)
    if not n.episode then return nil end
    if n.season then return "S" .. n.season .. ":E" .. n.episode end
    return "E" .. n.episode
end

local function set_title()
    if not now then
        if default_title then mp.set_property("title", default_title) end
        return
    end
    local parts = { now.name }
    local tag = episode_tag(now)
    if tag then parts[#parts + 1] = tag end
    if now.ep_name and now.ep_name ~= "" then parts[#parts + 1] = now.ep_name end
    -- "$>" : the rest is taken as it is, whatever signs the name contains
    mp.set_property("title", "$>" .. table.concat(parts, DOT))
end

local render    -- below

-- The episode's name and the summary, from the catalogue.
local function apply_meta(meta)
    if not now or type(meta) ~= "table" then return end
    if type(meta.name) == "string" and meta.name ~= "" and not now.guessed then now.name = meta.name end
    local year = meta.releaseInfo or meta.year
    if type(year) == "string" or type(year) == "number" then now.year = tostring(year) end
    if type(meta.runtime) == "string" then now.runtime = meta.runtime end
    local about = type(meta.description) == "string" and meta.description or ""
    if now.episode and type(meta.videos) == "table" then
        for _, v in ipairs(meta.videos) do
            if type(v) == "table" then
                local same = v.id == now.video_id
                    or (tonumber(v.episode or v.number) == now.episode and (now.season == nil or tonumber(v.season) == now.season))
                if same then
                    local name = type(v.name) == "string" and v.name or (type(v.title) == "string" and v.title or "")
                    if name ~= "" and not name:lower():match("^episode %d+$") then now.ep_name = name end
                    local text = type(v.overview) == "string" and v.overview or (type(v.description) == "string" and v.description or "")
                    if trim(text) ~= "" then about = text end
                    break
                end
            end
        end
    end
    now.about = trim(about)
    if type(meta.background) == "string" and meta.background:match("^https://") then
        now.art_url = meta.background:gsub("/background/medium/", "/background/large/")
    end
    if type(meta.logo) == "string" and meta.logo:match("^https://") then now.logo_url = meta.logo end
    set_title()
    render()
end

local function ask_catalogue()
    if not now or not now.root then return end
    local root = now.root
    if metas[root] then
        apply_meta(metas[root])
        return
    end
    local url
    if root:match("^tt%d+$") then
        url = CINEMETA .. (now.type == "movie" and "movie" or "series") .. "/" .. root .. ".json"
    elseif root:match("^kitsu:%d+$") then
        url = KITSU .. (now.type == "movie" and "movie" or (now.type == "anime" and "anime" or "series")) .. "/" .. root .. ".json"
    else
        return
    end
    local gen = loaded
    mp.command_native_async({
        name = "subprocess", playback_only = false, capture_stdout = true, capture_stderr = true,
        args = { "curl", "-s", "-L", "-m", "20", url },
    }, function(ok, res)
        local data = ok and res and res.status == 0 and utils.parse_json(res.stdout or "") or nil
        if type(data) ~= "table" or type(data.meta) ~= "table" then return end
        metas[root] = data.meta
        if gen == loaded and now and now.root == root then apply_meta(data.meta) end
    end)
end

local function on_loaded()
    loaded = loaded + 1
    local file = mp.get_property("media-title") or mp.get_property("filename") or ""
    local note = first and read_note() or nil
    first = false
    if note then
        from_atrium = true
        local root, season, episode = split_id(note.id)
        now = { name = trim(note.name), type = type(note.type) == "string" and note.type or "", root = root,
            video_id = note.id, season = season, episode = episode, sub = type(note.sub) == "string" and note.sub or "" }
    elseif now and now.root and now.episode then
        -- another episode opened from inside the player: same series, the numbers from the file
        local season, episode = numbers(file)
        now = { name = now.name, type = now.type, root = now.root, season = season or now.season, episode = episode, sub = "" }
        if now.root:match("^kitsu") then now.season = nil end
        if episode then
            now.video_id = now.root .. ":" .. (now.season and (now.season .. ":") or "") .. episode
        end
    else
        local season, episode = numbers(file)
        now = { name = tidy(file), type = episode and "series" or "movie", season = season, episode = episode, sub = "", guessed = true }
    end
    set_title()
    ask_catalogue()
end

local casting = nil         -- { ip, name } while the television plays it

-- ===== the paused screen =====

local overlay = mp.create_osd_overlay("ass-events")
overlay.z = -5              -- under the player's own buttons
local shown = false
local level = 0             -- 0..1, for the fade
local fade = nil
local quiet_since = mp.get_time()
local at_x, at_y = nil, nil -- where the mouse was when it last counted as moved
local NUDGE = 8             -- a mouse that only trembles on the desk (less than this) is not a move
local shown_at, shown_pos = 0, nil
local drawn = ""

-- Why the paused screen went away, kept in a small file (paused-screen.log, the last 40 times)
-- so that a screen that leaves on its own can be explained.
local notes = {}
local function note(why, plain)
    notes[#notes + 1] = os.date("%Y-%m-%d %H:%M:%S") .. (plain and "  " or ("  up for " .. math.floor(mp.get_time() - shown_at) .. " s  ")) .. tostring(why)
    while #notes > 40 do table.remove(notes, 1) end
    local ok, path = pcall(mp.command_native, { "expand-path", "~~exe_dir/mpv/paused-screen.log" })
    local f = ok and io.open(path, "w") or nil
    if not f then return end
    f:write(table.concat(notes, "\n") .. "\n")
    f:close()
end

local function esc(s)
    return (tostring(s):gsub("\\", "\\\239\187\191"):gsub("{", "\\{"):gsub("}", "\\}"):gsub("\n", " "))
end

-- Cuts a text into lines of about per_line letters, at most max_lines of them.
local function wrap(text, per_line, max_lines)
    local lines, line = {}, ""
    for word in tostring(text):gmatch("%S+") do
        if line ~= "" and #line + 1 + #word > per_line then
            lines[#lines + 1] = line
            line = word
            if #lines == max_lines then break end
        else
            line = line == "" and word or (line .. " " .. word)
        end
    end
    if #lines < max_lines and line ~= "" then
        lines[#lines + 1] = line
    elseif #lines == max_lines and line ~= "" then
        lines[max_lines] = lines[max_lines]:gsub("[%s%p]+$", "") .. "..."
    end
    return lines
end

-- ----- the cover art -----
-- The title's own picture fills the screen to the right of the text, fading into black on its
-- left; its logo stands in for the name when it has one. Both are fetched and cut to size by a
-- second, silent mpv (as the episode list does for its pictures), once per title and window size.
local ART_ID, LOGO_ID = 60, 61
local mpv_exe = mp.command_native({ "expand-path", "~~exe_dir/mpv.exe" })
local art_dir = os.getenv("TEMP") or mp.command_native({ "expand-path", "~~exe_dir/mpv" })
local art = { id = ART_ID, path = art_dir .. "/atrium-paused-art.bgra", key = nil, ready = false, busy = false, on = false, levels = 1 }
local logo = { id = LOGO_ID, path = art_dir .. "/atrium-paused-logo.bgra", key = nil, ready = false, busy = false, on = false, levels = 1 }

local function file_size(path)
    local f = io.open(path, "rb")
    if not f then return 0 end
    local size = f:seek("end") or 0
    f:close()
    return size
end

local function take_down(slot)
    if slot.on then
        mp.commandv("overlay-remove", tostring(slot.id))
        slot.on = false
    end
end

-- Where things go on the paused screen, for the window as it is now.
local function layout()
    local d = mp.get_property_native("osd-dimensions")
    if type(d) ~= "table" or not d.w or d.w <= 0 or d.h <= 0 then return nil end
    local L = { w = math.floor(d.w), h = math.floor(d.h) }
    local ml, mr = math.max(0, d.ml or 0), math.max(0, d.mr or 0)
    L.vw = math.max(L.w * 0.3, L.w - ml - mr)          -- the picture's own width
    L.tw = math.min(L.vw, L.h * 16 / 9)                -- the text keeps to the width it would have on a 16:9 picture
    L.s = L.h / 1080
    L.x = math.floor(ml + L.vw * 0.055)
    L.art_x = math.floor(L.x + L.tw * 0.40)            -- the art starts where the text ends
    L.art_w = L.w - L.art_x
    L.ramp = math.max(40, math.floor(math.min(L.art_w * 0.35, L.tw * 0.24)))
    L.logo_w = math.floor(L.tw * 0.30)
    L.logo_h = math.floor(L.h * 0.20)
    return L
end

-- A picture cannot be made more or less see-through once it is on the screen, so each one is
-- made as LEVELS copies, one under the other in the same file, from faint to full: the screen
-- comes in and goes out by showing them in turn.
local LEVELS = 5
local function in_levels(graph)
    local parts, names = {}, {}
    local split = {}
    for i = 1, LEVELS do split[i] = "[l" .. i .. "]" end
    parts[1] = graph .. ",split=" .. LEVELS .. table.concat(split)
    for i = 1, LEVELS - 1 do
        local f = string.format("%.2f", i / LEVELS)
        parts[#parts + 1] = "[l" .. i .. "]colorchannelmixer=rr=" .. f .. ":gg=" .. f .. ":bb=" .. f .. ":aa=" .. f .. "[m" .. i .. "]"
        names[i] = "[m" .. i .. "]"
    end
    names[LEVELS] = "[l" .. LEVELS .. "]"
    return table.concat(parts, ";") .. ";" .. table.concat(names) .. "vstack=inputs=" .. LEVELS .. ",format=bgra"
end

-- The ways the request can be written for the second player, the best first; the one that
-- works is remembered. The last one is the plain single picture (which then cannot fade).
local ways = {
    function(graph) local g = in_levels(graph) return "--vf=lavfi=%" .. #g .. "%" .. g, LEVELS end,
    function(graph) return "--vf=lavfi=[" .. in_levels(graph) .. "]", LEVELS end,
    function(graph) return "--vf=lavfi=[" .. graph .. ",format=bgra]", 1 end,
}
local way_from = 1

-- Has a picture made, unless it is there already. slot: art or logo. graph: without its last
-- step (the format), which is added here.
local function want(slot, key, url, w, h, graph, on_fail)
    if slot.key == key or slot.busy then return end
    take_down(slot)
    slot.key, slot.ready, slot.busy = key, false, true
    local function try(n)
        local arg, levels = ways[n](graph)
        mp.command_native_async({
            name = "subprocess", playback_only = false, capture_stdout = true, capture_stderr = true,
            args = { mpv_exe, url, "--no-config", "--msg-level=all=no", "--load-scripts=no", "--ytdl=no",
                "--aid=no", "--sid=no", "--frames=1", arg,
                "--ovc=rawvideo", "--of=image2", "--ofopts=update=1", "--o=" .. slot.path },
        }, function()
            if slot.key ~= key then
                slot.busy = false
                return
            end
            if file_size(slot.path) == w * h * 4 * levels then
                if n ~= way_from or not slot.told then note("picture made, way " .. n .. " (" .. levels .. (levels == 1 and " copy)" or " copies)"), true) end
                way_from, slot.told = n, true
                slot.busy, slot.ready, slot.levels = false, true, levels
                render()
            elseif n < #ways then
                os.remove(slot.path)
                try(n + 1)
            else
                slot.busy = false
                if on_fail then on_fail() end
                render()
            end
        end)
    end
    os.remove(slot.path)
    try(way_from)
end

local function want_pictures(L)
    if not now or not L then return end
    if now.art_url then
        local k = "clip(X/" .. L.ramp .. "\\,0\\,1)"
        local graph = "scale=" .. L.art_w .. ":" .. L.h .. ":force_original_aspect_ratio=increase,crop=" .. L.art_w .. ":" .. L.h
            .. ":(iw-ow)/2:(ih-oh)/4,format=gbrap,geq=r='r(X\\,Y)*" .. k .. "':g='g(X\\,Y)*" .. k .. "':b='b(X\\,Y)*" .. k
            .. "':a='255*" .. k .. "'"
        local url = now.art_url
        want(art, url .. "|" .. L.art_w .. "x" .. L.h .. "|" .. L.ramp, url, L.art_w, L.h, graph, function()
            -- the large picture is not always there: the usual size is asked next
            if now and now.art_url == url and url:find("/background/large/", 1, true) then
                now.art_url = url:gsub("/background/large/", "/background/medium/")
                art.key = nil
            end
        end)
    end
    if now.logo_url then
        local graph = "scale=" .. L.logo_w .. ":" .. L.logo_h .. ":force_original_aspect_ratio=decrease,format=gbrap,pad=" .. L.logo_w .. ":" .. L.logo_h
            .. ":0:oh-ih:color=black@0,geq=r='r(X\\,Y)*alpha(X\\,Y)/255':g='g(X\\,Y)*alpha(X\\,Y)/255':b='b(X\\,Y)*alpha(X\\,Y)/255':a='alpha(X\\,Y)'"
        want(logo, now.logo_url .. "|" .. L.logo_w .. "x" .. L.logo_h, now.logo_url, L.logo_w, L.logo_h, graph)
    end
end

render = function()
    if level <= 0 or not now then
        take_down(art)
        take_down(logo)
        if drawn ~= "" then
            drawn = ""
            overlay:remove()
        end
        return
    end
    local L = layout()
    if not L then return end
    local w, h, s, x = L.w, L.h, L.s, L.x
    local has_art = now.art_url ~= nil and art.ready and art.key == now.art_url .. "|" .. L.art_w .. "x" .. h .. "|" .. L.ramp
    local has_logo = now.logo_url ~= nil and logo.ready and logo.key == now.logo_url .. "|" .. L.logo_w .. "x" .. L.logo_h
    -- the screen eases in and out: everything fades, and the words rise a little into place
    local e = level * level * (3 - 2 * level)
    local rise = math.floor((1 - e) * 16 * s)
    local text_a = string.format("%02X", math.floor(255 * (1 - e)))
    -- with the art, the screen behind it is black; without, the picture is only dimmed
    local dim_a = string.format("%02X", math.floor(255 - (255 - (has_art and 0 or tonumber(DIM, 16))) * e))
    local shade_a = string.format("%02X", math.floor(255 - (255 - 144) * e))

    local out = {}
    out[#out + 1] = string.format("{\\an7\\pos(0,0)\\bord0\\shad0\\1c&H000000&\\1a&H%s&\\p1}m 0 0 l %d 0 %d %d 0 %d{\\p0}", dim_a, w, w, h, h)
    local function text(px, py, an, size, color, bold, str)
        out[#out + 1] = string.format("{\\an%d\\pos(%d,%d)\\fnSegoe UI\\fs%d\\b%d\\bord0\\shad%.1f\\4c&H000000&\\4a&H%s&\\1c&H%s&\\1a&H%s&\\q2}%s",
            an, math.floor(px), math.floor(py), math.floor(size), bold and 1 or 0, 1.5 * s, shade_a, color, text_a, esc(str))
    end

    -- the block is built first, to be centred on the height of the screen
    local rows = {}
    rows[#rows + 1] = { size = 25 * s, gap = 16 * s, color = "B8B8B8", str = "You're watching" }
    if has_logo then
        rows[#rows + 1] = { logo = true, size = L.logo_h / 1.12, gap = 24 * s }
    else
        local per_title = math.max(12, math.floor(L.tw * 0.36 / (64 * s * 0.56)))
        for _, l in ipairs(wrap(now.name, per_title, 2)) do
            rows[#rows + 1] = { size = 64 * s, gap = 6 * s, color = "FFFFFF", bold = true, str = l }
        end
        rows[#rows].gap = 18 * s
    end
    local tag = episode_tag(now)
    if tag then
        local line = tag
        if now.ep_name and now.ep_name ~= "" then line = line .. DOT .. now.ep_name end
        rows[#rows + 1] = { size = 31 * s, gap = 16 * s, color = "FFFFFF", bold = true, str = line }
    else
        local bits = {}
        if now.year then bits[#bits + 1] = now.year end
        if now.runtime then bits[#bits + 1] = now.runtime end
        if #bits > 0 then rows[#rows + 1] = { size = 27 * s, gap = 16 * s, color = "D0D0D0", str = table.concat(bits, DOT) } end
    end
    if now.about and now.about ~= "" then
        local per_line = math.max(24, math.floor(L.tw * 0.35 / (25 * s * 0.5)))
        for _, l in ipairs(wrap(now.about, per_line, 6)) do
            rows[#rows + 1] = { size = 25 * s, gap = 9 * s, color = "D8D8D8", str = l }
        end
    end
    local total = 0
    for _, r in ipairs(rows) do total = total + r.size * 1.12 + r.gap end
    local y = math.max(h * 0.14, (h - total) / 2) + rise
    local logo_y = nil
    for _, r in ipairs(rows) do
        if r.logo then logo_y = math.floor(y) else text(x, y, 7, r.size, r.color, r.bold, r.str) end
        y = y + r.size * 1.12 + r.gap
    end
    text(x, h * 0.9, 1, 25 * s, "A0A0A0", false, casting and ("Playing on " .. casting.name) or "Paused")

    local data = table.concat(out, "\n")
    local key = w .. "x" .. h .. data
    if key ~= drawn then
        drawn = key
        overlay.res_x, overlay.res_y = w, h
        overlay.data = data
        overlay:update()
    end

    -- the pictures follow the fade, one copy after the other (a picture made as a single copy
    -- only goes up once the screen has finished coming in)
    local function copy_for(slot)
        local n = slot.levels or 1
        if n <= 1 then return level >= 1 and 1 or 0 end
        return math.min(n, math.ceil(e * n - 0.001))
    end
    local step = has_art and copy_for(art) or 0
    if step >= 1 then
        if art.on ~= step then
            mp.commandv("overlay-add", tostring(art.id), tostring(L.art_x), "0", art.path, tostring((step - 1) * L.art_w * h * 4),
                "bgra", tostring(L.art_w), tostring(h), tostring(L.art_w * 4))
            art.on = step
        end
    else
        take_down(art)
    end
    step = (has_logo and logo_y) and copy_for(logo) or 0
    if step >= 1 then
        local at = x .. "," .. logo_y .. "|" .. step
        if logo.on ~= at then
            mp.commandv("overlay-add", tostring(logo.id), tostring(x), tostring(logo_y), logo.path, tostring((step - 1) * L.logo_w * L.logo_h * 4),
                "bgra", tostring(L.logo_w), tostring(L.logo_h), tostring(L.logo_w * 4))
            logo.on = at
        end
    else
        take_down(logo)
    end
end

-- at_once: no way out animation (the video ended or changed).
local function set_shown(on, at_once)
    if on == shown and not (at_once and level > 0 and not on) then return end
    shown = on
    if on then shown_at, shown_pos = mp.get_time(), mp.get_property_number("time-pos") end
    if fade then
        fade:kill()
        fade = nil
    end
    if not on and (at_once or level <= 0) then
        level = 0
        render()
        return
    end
    -- in over about a third of a second, out a little quicker
    fade = mp.add_periodic_timer(0.025, function()
        if shown then level = math.min(1, level + 0.075) else level = math.max(0, level - 0.11) end
        render()
        if (level >= 1 or level <= 0) and fade then
            fade:kill()
            fade = nil
        end
    end)
end

local function stir(why)
    quiet_since = mp.get_time()
    if shown then
        note(why or "?")
        set_shown(false)
    end
end

-- Once up, the screen stays until the mouse really moves or a key does something (play, a jump,
-- the volume, subtitles, full screen...). A stream that refills on its own does not take it away.
local function check()
    if now and mp.get_property_bool("pause") == true then want_pictures(layout()) end
    if shown then
        local pos = mp.get_property_number("time-pos")
        local why = nil
        if not now then why = "nothing playing"
        elseif mp.get_property_bool("pause") ~= true then why = "playing again"
        elseif mp.get_property_bool("idle-active") == true then why = "player idle"
        elseif mp.get_property_native("user-data/uosc/menu/type") ~= nil then why = "a menu opened"
        elseif mp.get_property_native("user-data/player/pip") == true then why = "picture in picture"
        elseif pos and shown_pos and math.abs(pos - shown_pos) > 1 then why = "jumped in the video" end
        if why then stir(why) end
        return
    end
    local wanted = now ~= nil
        and mp.get_property_bool("pause") == true
        and mp.get_property_bool("idle-active") ~= true
        and mp.get_property_bool("eof-reached") ~= true
        and mp.get_property_bool("seeking") ~= true
        and mp.get_property_number("duration") ~= nil
        and mp.get_property_native("user-data/uosc/menu/type") == nil
        and mp.get_property_native("user-data/player/pip") ~= true      -- the small window stays bare
        and mp.get_time() - quiet_since >= WAIT
    set_shown(wanted)
end

mp.observe_property("pause", "bool", function() stir("pause changed") end)
mp.observe_property("seeking", "bool", function(_, v)
    if not v then return end
    if not shown then quiet_since = mp.get_time() return end
    -- a jump made by hand moves the position; the stream reconnecting does not
    local pos = mp.get_property_number("time-pos")
    if pos and shown_pos and math.abs(pos - shown_pos) > 1 then stir("jumped in the video") end
end)
for _, name in ipairs({ "volume", "mute", "fullscreen", "sid", "aid", "sub-visibility", "speed" }) do
    local first = true
    mp.observe_property(name, "native", function()
        if first then first = false return end
        stir(name .. " changed")
    end)
end
mp.observe_property("mouse-pos", "native", function(_, m)
    if type(m) ~= "table" or not m.x or not m.y then return end
    if not at_x or math.abs(m.x - at_x) + math.abs(m.y - at_y) >= NUDGE then
        local why = at_x and ("mouse moved " .. math.floor(math.abs(m.x - at_x) + math.abs(m.y - at_y)) .. " px") or "mouse seen"
        at_x, at_y = m.x, m.y
        stir(why)
    end
end)
mp.observe_property("osd-dimensions", "native", function() if shown then render() end end)
mp.add_periodic_timer(0.5, check)

-- ===== the cast button =====

local HOME = "http://localhost:18731"
local cast_overlay = mp.create_osd_overlay("ass-events")
local cast_drawn = ""
local cast_box = nil        -- where the button is: { x0, y0, x1, y1 }
local cast_over = false
local cast_bound = false
local cast_busy = false
local last_move = -100
local last_cast_xy = ""

-- Asks the home server; done(answer) gets a table, or nil when Atrium is not open.
local function ask_home(path, body, done)
    local args = { "curl", "-s", "-m", "70", "-H", "X-Home-Player: 1" }
    if body then
        args[#args + 1] = "-X"
        args[#args + 1] = "POST"
        args[#args + 1] = "-H"
        args[#args + 1] = "Content-Type: application/json"
        args[#args + 1] = "-d"
        args[#args + 1] = body
    end
    args[#args + 1] = HOME .. path
    mp.command_native_async({ name = "subprocess", playback_only = false, capture_stdout = true, capture_stderr = true, args = args },
        function(ok, res)
            local data = ok and res and res.status == 0 and utils.parse_json(res.stdout or "") or nil
            done(type(data) == "table" and data or nil)
        end)
end

local function cast_send(ip, name)
    if not now or not now.video_id then return end
    cast_busy = true
    mp.osd_message("Sending it to " .. name .. "...", 60)
    local pos = math.floor(mp.get_property_number("time-pos") or 0)
    local tag = episode_tag(now)
    local sub = tag and (tag .. ((now.ep_name and now.ep_name ~= "") and (DOT .. now.ep_name) or "")) or (now.year or "")
    local kind = (now.type == "movie" or now.type == "anime") and now.type or "series"
    local body = utils.format_json({ name = now.name, sub = sub, image = "" })
    ask_home("/api/cast/title?type=" .. kind .. "&id=" .. now.video_id .. "&ip=" .. ip .. "&t=" .. pos, body, function(r)
        cast_busy = false
        if not r then
            mp.osd_message("Atrium is not open: it is what talks to the television", 6)
        elseif r.ok then
            casting = { ip = ip, name = name }
            mp.set_property_bool("pause", true)
            mp.osd_message("Playing on " .. name .. (type(r.q) == "string" and r.q ~= "" and ("  (" .. r.q .. ")") or ""), 6)
        else
            mp.osd_message("Could not play it on " .. name .. ": " .. tostring(r.error or "unknown"), 8)
        end
    end)
end

-- Back to this screen, at the point the television had reached.
local function cast_back()
    local tv = casting
    if not tv then return end
    cast_busy = true
    mp.osd_message("Bringing it back from " .. tv.name .. "...", 30)
    ask_home("/api/cast/remote?ip=" .. tv.ip .. "&do=status", nil, function(st)
        local pos = type(st) == "table" and st.ok and st.state ~= "idle" and tonumber(st.pos) or nil
        ask_home("/api/cast/remote?ip=" .. tv.ip .. "&do=stop", "{}", function()
            cast_busy = false
            casting = nil
            if pos and pos > 5 then mp.commandv("seek", tostring(pos), "absolute") end
            mp.set_property_bool("pause", false)
            mp.osd_message("", 0.1)
        end)
    end)
end

local function cast_press()
    if cast_busy then return end
    if casting then
        cast_back()
        return
    end
    if not now or not now.video_id then
        mp.osd_message("Casting works for what was started from Atrium", 5)
        return
    end
    cast_busy = true
    mp.osd_message("Looking for your television...", 30)
    ask_home("/api/cast/devices", nil, function(r)
        cast_busy = false
        if not r then
            mp.osd_message("Atrium is not open: it is what talks to the television", 6)
            return
        end
        local tvs = {}
        for _, d in ipairs(type(r.devices) == "table" and r.devices or {}) do
            if type(d) == "table" and d.tv and type(d.ip) == "string" then tvs[#tvs + 1] = d end
        end
        if #tvs == 0 then
            mp.osd_message("No television with Chromecast was found on your network", 6)
        elseif #tvs == 1 then
            cast_send(tvs[1].ip, tostring(tvs[1].name or tvs[1].ip))
        else
            mp.osd_message("", 0.1)
            local items = {}
            for _, d in ipairs(tvs) do
                items[#items + 1] = { title = tostring(d.name or d.ip), icon = "cast",
                    value = { "script-message-to", mp.get_script_name(), "cast-to", d.ip, tostring(d.name or d.ip) } }
            end
            mp.commandv("script-message-to", "uosc", "open-menu", utils.format_json({ type = "cast", title = "Play on", items = items }))
        end
    end)
end
mp.register_script_message("cast-to", function(ip, name) cast_send(ip, name or ip) end)

local function cast_bind(on)
    if on == cast_bound then return end
    cast_bound = on
    if on then
        mp.add_forced_key_binding("MBTN_LEFT", "cast-click", cast_press)
        mp.add_forced_key_binding("MBTN_LEFT_DBL", "cast-dblclick", function() end)
    else
        mp.remove_key_binding("cast-click")
        mp.remove_key_binding("cast-dblclick")
    end
end

-- The button shows with the mouse, like the rest of the controls, and stays while the
-- television is playing.
local function render_cast()
    local w, h = mp.get_osd_size()
    local m = mp.get_property_native("mouse-pos")
    local awake = type(m) == "table" and m.hover ~= false and mp.get_time() - last_move < 2.5
    local show = w and h and w > 0 and h > 0 and now ~= nil and mp.get_property_number("duration") ~= nil
        and (awake or casting ~= nil)
        and mp.get_property_native("user-data/uosc/menu/type") == nil
        and mp.get_property_native("user-data/player/pip") ~= true      -- the small window stays bare
    if not show then
        cast_over = false
        cast_bind(false)
        if cast_drawn ~= "" then
            cast_drawn = ""
            cast_overlay:remove()
        end
        return
    end
    local s = h / 1080
    local out = {}
    -- the name, top left; not over the paused screen, which says it already
    if awake and level <= 0 then
        -- sharp letters: a hair of dark outline and a short shadow, nothing blurred
        local shade = string.format("\\blur0\\bord%.1f\\3c&H000000&\\3a&H70&\\shad%.1f\\4c&H000000&\\4a&H60&", 0.7 * s, 1.3 * s)
        out[#out + 1] = string.format("{\\an7\\pos(%d,%d)\\fnBebas Neue\\fs%d\\fsp%.1f\\b0%s\\1c&HFFFFFF&\\q2}%s",
            math.floor(30 * s), math.floor(15 * s), math.floor(50 * s), 1.2 * s, shade, esc(now.name:upper()))
        local tag = episode_tag(now)
        if tag then
            local line = tag
            if now.ep_name and now.ep_name ~= "" then line = line .. DOT .. now.ep_name end
            out[#out + 1] = string.format("{\\an7\\pos(%d,%d)\\fnSegoe UI Semibold\\fs%d\\b0%s\\1c&HE6E6E6&\\q2}%s",
                math.floor(31 * s), math.floor(66 * s), math.floor(25 * s), shade, esc(line))
        end
    end
    local cx, cy, r = w - 196 * s, 29 * s, 22 * s
    cast_box = { cx - r, cy - r, cx + r, cy + r }
    cast_over = type(m) == "table" and m.x >= cast_box[1] and m.x <= cast_box[3] and m.y >= cast_box[2] and m.y <= cast_box[4]
    cast_bind(cast_over)
    local color = casting and "140AE5" or "FFFFFF"        -- red while the television plays
    out[#out + 1] = string.format(
        "{\\an5\\pos(%d,%d)\\fnMaterialIconsRound-Regular\\fs%d\\b0\\blur0\\shad0\\bord%.1f\\1c&H%s&\\3c&H000000&\\3a&HA0&\\1a&H%s&}%s",
        math.floor(cx), math.floor(cy), math.floor(30 * s), 1.2 * s, color, (cast_over or casting) and "00" or "30", "cast")
    local data = table.concat(out, "\n")
    local key = w .. "x" .. h .. data
    if key ~= cast_drawn then
        cast_drawn = key
        cast_overlay.res_x, cast_overlay.res_y = w, h
        cast_overlay.data = data
        cast_overlay:update()
    end
end
mp.observe_property("mouse-pos", "native", function(_, m)
    if type(m) == "table" then
        local xy = tostring(m.x) .. "," .. tostring(m.y)
        if xy ~= last_cast_xy then
            last_cast_xy = xy
            last_move = mp.get_time()
        end
    end
    render_cast()
end)
mp.add_periodic_timer(0.25, render_cast)

mp.register_event("file-loaded", on_loaded)
mp.register_event("end-file", function(e)
    if shown then note("the video ended or changed") end
    set_shown(false, true)
    casting = nil
    -- played to its end, and nothing follows: Atrium is told, so that it shows its main page
    -- when it comes back (the request outlives the player, which closes at this point)
    if from_atrium and type(e) == "table" and e.reason == "eof" then
        local pos, count = mp.get_property_number("playlist-pos"), mp.get_property_number("playlist-count")
        if not pos or not count or pos < 0 or pos >= count - 1 then
            mp.command_native_async({ name = "subprocess", playback_only = false, detach = true,
                args = { "curl", "-s", "-m", "5", "-X", "POST", "-H", "X-Home-Player: 1", "-d", "{}", HOME .. "/api/player/ended" } },
                function() end)
            -- the player would otherwise sit on its empty "drop files here" screen: close it,
            -- unless something else has started in the meantime
            mp.add_timeout(1, function()
                if mp.get_property_bool("idle-active") then mp.commandv("quit") end
            end)
        end
    end
end)
