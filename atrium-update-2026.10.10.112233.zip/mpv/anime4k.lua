-- anime4k.lua
-- Anime4K upscaler for animation at 1080p or lower (high-quality "Mode A").
--
-- Switches on by itself when a video has Japanese audio and is 1080p or lower.
-- Every other video starts with it off.
--
-- Hotkeys (for the current video):
--   Ctrl+1   turn Anime4K on / off
--   Ctrl+0   turn it off

local AUTO = true         -- set to false to never switch on automatically
local AUTO_LANGS = { ja = true, jpn = true }
local DIR = "~~exe_dir/anime4k/"
local MODE_A = {
    "Anime4K_Clamp_Highlights.glsl",
    "Anime4K_Restore_CNN_VL.glsl",
    "Anime4K_Upscale_CNN_x2_VL.glsl",
    "Anime4K_AutoDownscalePre_x2.glsl",
    "Anime4K_AutoDownscalePre_x4.glsl",
    "Anime4K_Upscale_CNN_x2_M.glsl",
}
local MAX_HEIGHT = 1200   -- above this the video is already sharp enough (1440p / 4K)

local active = false

local function turn_off(quiet)
    mp.set_property_native("glsl-shaders", {})
    active = false
    if not quiet then mp.osd_message("Anime4K: off", 2) end
end

local function turn_on(quiet)
    local list = {}
    for i, name in ipairs(MODE_A) do list[i] = DIR .. name end
    mp.set_property_native("glsl-shaders", list)
    active = true
    if not quiet then mp.osd_message("Anime4K: on", 2) end
end

mp.add_key_binding("Ctrl+1", "anime4k-toggle", function()
    if active then
        turn_off(false)
        return
    end
    local h = mp.get_property_number("video-params/h") or 0
    if h > MAX_HEIGHT then
        mp.osd_message(string.format("Anime4K: not needed, this video is already %dp", h), 3)
        return
    end
    turn_on(false)
end)
mp.add_key_binding("Ctrl+0", "anime4k-off", function() turn_off(false) end)

mp.register_event("file-loaded", function()
    local japanese, height = false, nil
    for _, t in ipairs(mp.get_property_native("track-list") or {}) do
        if t.selected and t.type == "audio" then
            local lang = ((t.lang or ""):lower():match("^[a-z]+")) or ""
            japanese = AUTO_LANGS[lang] == true
        elseif t.selected and t.type == "video" then
            height = t["demux-h"]
        end
    end
    if AUTO and japanese and height and height <= MAX_HEIGHT then
        turn_on(true)
    elseif active then
        turn_off(true)
    end
end)
