-- skip.lua
-- Skips intros, openings, endings, credits and previews in series,
-- on files that have named chapter markers.
--
-- Only on videos shorter than 75 minutes, so film title sequences are never skipped.
-- Each marked chapter is skipped once: seek back into it and it plays normally.
-- Credits in the very last chapter are left alone (nothing to skip to).
--
-- Hotkey: Alt+Shift+S turns skipping on / off.

local utils = require 'mp.utils'

local MAX_DURATION = 75 * 60
local WORDS = { "intro", "opening", "ending", "credits", "preview", "recap",
                "op", "ed", "ncop", "nced" }

local state_path = mp.command_native({ "expand-path", "~~exe_dir/mpv/skip.json" })
local enabled = true
local skipped = {}

local function load_state()
    local f = io.open(state_path, "r")
    if not f then return end
    local data = utils.parse_json(f:read("*a") or "")
    f:close()
    if type(data) == "table" and type(data.enabled) == "boolean" then
        enabled = data.enabled
    end
end

local function save_state()
    local f = io.open(state_path, "w")
    if not f then return end
    f:write(utils.format_json({ enabled = enabled }))
    f:close()
end

local function is_skippable(title)
    if not title or title == "" then return false end
    local clean = title:lower():gsub("[^%a%d]", " ")
    local t = " " .. clean .. " "
    for _, w in ipairs(WORDS) do
        if t:find(" " .. w .. " ", 1, true) or t:find(" " .. w .. "%d+ ") then
            return true
        end
    end
    return false
end

local function check(_, chapter)
    if not enabled or not chapter or chapter < 0 then return end
    local dur = mp.get_property_number("duration")
    if not dur or dur > MAX_DURATION then return end
    local list = mp.get_property_native("chapter-list") or {}
    local cur = list[chapter + 1]
    local nxt = list[chapter + 2]
    if not cur or not nxt or skipped[chapter] then return end
    if not is_skippable(cur.title) then return end
    skipped[chapter] = true
    mp.set_property_number("chapter", chapter + 1)
    mp.osd_message("Skipped: " .. cur.title, 3)
end

mp.observe_property("chapter", "number", check)
mp.register_event("file-loaded", function() skipped = {} end)

mp.add_key_binding("Alt+S", "skip-toggle", function()
    enabled = not enabled
    save_state()
    mp.osd_message("Skip intros and credits: " .. (enabled and "on" or "off"), 2.5)
end)

load_state()
