-- pip.lua
-- Picture in picture: the video in a small window that stays above the other windows, in the
-- bottom right corner of the screen, so that something else can be done at the same time.
-- The button next to "full screen" (or Alt+P) puts it there; the same button (or Alt+P, or a
-- double-click on the small picture) brings it back the way it was.
--
-- The small window is kept as bare as possible, with rounded corners: a cross at the top left
-- (closes the player), the picture-in-picture button at the top right (back to the full
-- screen), the back 10 s / pause / forward 10 s buttons in the middle and the seek bar with its
-- times. The other buttons, the title and the paused screen stay away until it is large again.
-- The small window can be dragged anywhere with the mouse; a click still pauses.
-- Clicking another window while a video plays in full screen makes it small by itself.

local SIZE = 0.30            -- height of the small window, as a share of the screen's height
local WIDEST = 0.42          -- and never wider than this share of the screen's width
local MARGIN_X = 0.012       -- distance from the right edge, as a share of the screen's width
local MARGIN_Y = 0.055       -- distance from the bottom edge (clear of the taskbar)

local before = nil           -- how the window was before: { fullscreen, ontop, geometry, corners }; nil = not small
local busy = false
local HIDDEN = "controls,volume,top_bar,window_border,speed"   -- the player's own parts that stay away

-- ===== the two buttons of the small window =====
local buttons = mp.create_osd_overlay("ass-events")
local drawn = ""
local last_move, last_xy = -100, ""
local over = nil             -- "close" or "back": the button under the mouse
local bound = false

local function press()
    if over == "close" then
        mp.commandv("quit")
    elseif over == "back" then
        mp.commandv("script-message-to", mp.get_script_name(), "pip")
    end
end

local function bind(on)
    if on == bound then return end
    bound = on
    if on then
        mp.add_forced_key_binding("MBTN_LEFT", "pip-click", press)
        mp.add_forced_key_binding("MBTN_LEFT_DBL", "pip-dblclick", function() end)
    else
        mp.remove_key_binding("pip-click")
        mp.remove_key_binding("pip-dblclick")
    end
end

-- They show with the mouse, like the rest, and go away after a moment.
local function render()
    local w, h = mp.get_osd_size()
    local m = mp.get_property_native("mouse-pos")
    local awake = type(m) == "table" and m.hover ~= false and mp.get_time() - last_move < 2.5
    if not before or not awake or not w or not h or w <= 0 or h <= 0 then
        over = nil
        bind(false)
        if drawn ~= "" then
            drawn = ""
            buttons:remove()
        end
        return
    end
    local size = math.max(24, math.floor(h * 0.085))
    local pad = math.floor(size * 0.85)
    local r = size * 0.75
    local spots = { close = { pad, pad, "close" }, back = { w - pad, pad, "picture_in_picture_alt" } }
    over = nil
    for name, b in pairs(spots) do
        if math.abs(m.x - b[1]) <= r and math.abs(m.y - b[2]) <= r then over = name end
    end
    bind(over ~= nil)
    local out = {}
    for _, name in ipairs({ "close", "back" }) do
        local b = spots[name]
        out[#out + 1] = string.format(
            "{\\an5\\pos(%d,%d)\\fnMaterialIconsRound-Regular\\fs%d\\b0\\blur0\\shad0\\bord%.1f\\1c&HFFFFFF&\\3c&H000000&\\3a&HA0&\\1a&H%s&}%s",
            b[1], b[2], size, math.max(1, size / 26), over == name and "00" or "30", b[3])
    end
    local data = table.concat(out, "\n")
    local key = w .. "x" .. h .. data
    if key ~= drawn then
        drawn = key
        buttons.res_x, buttons.res_y = w, h
        buttons.data = data
        buttons:update()
    end
end
mp.observe_property("mouse-pos", "native", function(_, m)
    if type(m) == "table" then
        local xy = tostring(m.x) .. "," .. tostring(m.y)
        if xy ~= last_xy then
            last_xy = xy
            last_move = mp.get_time()
        end
    end
    if before or drawn ~= "" then render() end
end)
mp.add_periodic_timer(0.25, function() if before or drawn ~= "" then render() end end)

-- Tells the other scripts (the title, the cast button and the paused screen keep away) and puts
-- the player's own buttons away or back.
local function bare(on)
    mp.set_property_native("user-data/player/pip", on)
    mp.commandv("script-message-to", "uosc", "disable-elements", mp.get_script_name(), on and HIDDEN or "")
end

local function screen()
    local w, h = mp.get_property_number("display-width"), mp.get_property_number("display-height")
    if not w or not h or w < 320 or h < 200 then return 1920, 1080 end
    return w, h
end

-- The shape of the picture as it is shown (after any cropping), 16:9 when it is not known.
local function shape()
    local p = mp.get_property_native("video-out-params") or mp.get_property_native("video-params")
    local a = type(p) == "table" and (tonumber(p.aspect) or (tonumber(p.dw) and tonumber(p.dh) and p.dh > 0 and p.dw / p.dh)) or nil
    if not a or a < 0.5 or a > 4 then return 16 / 9 end
    return a
end

local function size_now()
    local d = mp.get_property_native("osd-dimensions")
    if type(d) ~= "table" or not d.w or d.w <= 0 then return nil end
    return d.w, d.h
end

local function place(w, h)
    local sw, sh = screen()
    local mx, my = math.floor(sw * MARGIN_X), math.floor(sh * MARGIN_Y)
    mp.set_property("geometry", math.floor(w) .. "x" .. math.floor(h) .. "-" .. mx .. "-" .. my)
end

local function small()
    if before or busy then return end
    busy = true
    before = {
        fullscreen = mp.get_property_bool("fullscreen") == true,
        ontop = mp.get_property_bool("ontop") == true,
        geometry = mp.get_property("geometry") or "",
        corners = mp.get_property("window-corners"),
    }
    bare(true)
    mp.set_property("window-corners", "round")
    local sw, sh = screen()
    local h = math.floor(sh * SIZE)
    local w = math.floor(h * shape())
    if w > sw * WIDEST then
        w = math.floor(sw * WIDEST)
        h = math.floor(w / shape())
    end
    mp.set_property_bool("fullscreen", false)
    -- once the window has left the full screen, it is given its size and its corner
    mp.add_timeout(0.15, function()
        if not before then
            busy = false
            return
        end
        mp.set_property_bool("ontop", true)
        place(w, h)
        -- on a screen with scaling the window can come out larger or smaller than asked: the
        -- size it really got is looked at, and the request corrected once
        mp.add_timeout(0.35, function()
            busy = false
            if not before then return end
            local got = size_now()
            if got and got > 0 and math.abs(got - w) > 8 then
                local f = w / got
                if f > 0.3 and f < 3 then place(w * f, h * f) end
            end
        end)
    end)
end

local function large()
    if not before then return end
    local b = before
    before = nil
    bare(false)
    render()
    if b.corners then mp.set_property("window-corners", b.corners) end
    mp.set_property_bool("ontop", b.ontop)
    mp.set_property("geometry", b.geometry)
    mp.set_property_bool("fullscreen", b.fullscreen)
end

local function toggle()
    if before then large() else small() end
end

-- Going to the full screen by another way (a double-click, the full screen button, f) ends it too.
mp.observe_property("fullscreen", "bool", function(_, on)
    if on and before and not busy then
        local b = before
        before = nil
        bare(false)
        render()
        if b.corners then mp.set_property("window-corners", b.corners) end
        mp.set_property_bool("ontop", b.ontop)
        mp.set_property("geometry", b.geometry)
    end
end)

-- Windows can drop the rounded corners when the small window changes size: they are asked for
-- again a moment after every change of size.
local again = nil
mp.observe_property("osd-dimensions", "native", function()
    if not before then return end
    if again then again:kill() end
    again = mp.add_timeout(0.4, function()
        again = nil
        if not before then return end
        mp.set_property("window-corners", "roundsmall")
        mp.add_timeout(0.05, function()
            if before then mp.set_property("window-corners", "round") end
        end)
    end)
end)

-- Clicking another window on the same screen while a video plays in full screen puts it in
-- picture in picture by itself; something done on the other screen leaves it as it is (Atrium's
-- home server says which screen was clicked; without it, it goes small either way). Not in the
-- first seconds of a video (the window is still settling then), and not while it is paused.
local loaded_at = -100
local away_timer = nil
mp.register_event("file-loaded", function() loaded_at = mp.get_time() end)
mp.observe_property("focused", "bool", function(_, on)
    if away_timer then away_timer:kill() away_timer = nil end
    if on ~= false or before or busy then return end
    away_timer = mp.add_timeout(0.6, function()
        away_timer = nil
        if before or busy or mp.get_property_bool("focused") ~= false then return end
        if mp.get_property_bool("fullscreen") ~= true or mp.get_property_bool("pause") ~= false then return end
        if mp.get_property_bool("idle-active") or not mp.get_property_number("duration") then return end
        if mp.get_property_native("current-tracks/video/image") ~= false then return end
        if mp.get_time() - loaded_at < 4 then return end
        mp.command_native_async({ name = "subprocess", playback_only = false, capture_stdout = true, capture_stderr = true,
            args = { "curl", "-s", "-m", "2", "-H", "X-Home-Player: 1", "http://localhost:18731/api/player/focus" } },
            function(ok, res)
                local r = ok and res and res.status == 0 and require("mp.utils").parse_json(res.stdout or "") or nil
                if type(r) == "table" and r.known and r.same == false then return end   -- the other screen
                if before or busy or mp.get_property_bool("focused") ~= false then return end
                if mp.get_property_bool("fullscreen") ~= true or mp.get_property_bool("pause") ~= false then return end
                small()
            end)
    end)
end)

-- Atrium opens the player on the screen Atrium is on (it is started with screen and fs-screen
-- set to that screen). Once it is there, both are let go: otherwise the window would be pulled
-- back to that screen whenever it is made full screen or maximised on the other one.
local released = false
mp.register_event("file-loaded", function()
    if released then return end
    released = true
    mp.add_timeout(1.5, function()
        if mp.get_property("fs-screen") ~= "current" then mp.set_property("fs-screen", "current") end
        if mp.get_property("screen") ~= "default" then mp.set_property("screen", "default") end
    end)
end)

-- The next video of a series stays small; the player closing needs nothing.
mp.add_key_binding("Alt+p", "toggle", toggle)
mp.register_script_message("pip", toggle)
