-- subs.lua
-- Audio and subtitles that just work, including on anime.
--
-- 1. Picks the audio track when a file has several:
--      anime (a Japanese track in a file made for it)  ->  Japanese
--      everything else  ->  English, or French when there is no English
-- 2. Picks the subtitles from the audio that plays:
--      English or French audio  ->  subtitles off
--      Japanese or any other language  ->  English subtitles (French ones if there are none)
-- 3. Keeps dialogue on the visible screen in one plain style, so the Ultrawide Fill
--    crop can never cut it off. Translations of on-screen signs stay where the
--    subtitle file puts them, on the picture.
-- 4. Sets the size and how low the dialogue sits.
-- 5. Warns when a file has no subtitles at all and its audio is not English or French,
--    so you know straight away to pick another stream.
-- 6. Notes what it picked for each video in picks.log, next to this script (the last 40 videos),
--    so a choice that looks wrong can be looked into afterwards.
--
-- This is only the starting choice for each video. Manual control is unchanged: the gear
-- menu changes audio and subtitles, v hides / shows, j cycles the subtitle tracks.

local SUB_SCALE = 1.4            -- subtitle size (1.0 = mpv's normal size)
local SUB_POS = 98               -- vertical position: 100 = lowest, smaller = higher up
local LANGUAGES = {
    { name = "en", codes = { en = true, eng = true }, words = { "english" } },
    { name = "fr", codes = { fr = true, fre = true, fra = true }, words = { "french", "fran" } },
    { name = "ja", codes = { ja = true, jp = true, jpn = true }, words = { "japan" } },
}
local PREFERRED = { en = 100, fr = 50 }

local function base_lang(lang)
    return ((lang or ""):lower():match("^[a-z]+")) or ""
end

-- "en", "fr", "ja", another language's code, or "" when the file does not say.
local function track_lang(t)
    local lang = base_lang(t.lang)
    for _, l in ipairs(LANGUAGES) do
        if l.codes[lang] then return l.name end
    end
    if lang ~= "" and lang ~= "und" then return lang end
    -- Some files only say it in the track's name.
    local title = (t.title or ""):lower()
    for _, l in ipairs(LANGUAGES) do
        for _, word in ipairs(l.words) do
            if title:find(word, 1, true) then return l.name end
        end
    end
    return ""
end

local function pick_audio(tracks)
    local audio = {}
    for _, t in ipairs(tracks) do
        if t.type == "audio" then audio[#audio + 1] = t end
    end
    if #audio == 0 then return nil end
    local function first(name)
        local spare = nil
        for _, t in ipairs(audio) do
            if track_lang(t) == name then
                local title = (t.title or ""):lower()
                -- A commentary or an audio description only when there is nothing else.
                if title:find("comment", 1, true) or title:find("descri", 1, true) then
                    spare = spare or t
                else
                    return t
                end
            end
        end
        return spare
    end
    -- Anime: a Japanese track, in a file that is not a film dubbed in a dozen languages
    -- (those list English first and Japanese somewhere down the list).
    local ja = first("ja")
    if ja and (#audio <= 3 or audio[1] == ja or ja.default) then return ja end
    local pick = first("en") or first("fr")
    if pick then return pick end
    for _, t in ipairs(audio) do
        if t.default then return t end
    end
    return audio[1]
end

local function pick_subtitle(tracks)
    local best, best_score = nil, nil
    for _, t in ipairs(tracks) do
        if t.type == "sub" then
            local score = PREFERRED[track_lang(t)] or 0
            local title = (t.title or ""):lower()
            -- "Signs & Songs" and forced tracks only translate on-screen text, not dialogue.
            if title:find("sign") or title:find("song") or t.forced then score = score - 40 end
            if t.default then score = score + 5 end
            if not best_score or score > best_score then
                best, best_score = t, score
            end
        end
    end
    return best
end

-- One line per video in picks.log: its name, the picture size, the audio tracks (a star on the
-- one that plays) and the subtitles.
local LOG_LINES = 40
local function note(tracks, audio, sub, shown)
    local ok, path = pcall(mp.command_native, { "expand-path", "~~exe_dir/mpv/picks.log" })
    if not ok or type(path) ~= "string" then return end
    local sounds, subs, picture = {}, 0, "?"
    for _, t in ipairs(tracks) do
        if t.type == "audio" then
            local lang = track_lang(t)
            sounds[#sounds + 1] = (audio and t.id == audio.id and "*" or "") .. (lang ~= "" and lang or "?")
        elseif t.type == "sub" then
            subs = subs + 1
        elseif t.type == "video" and t["demux-w"] and t["demux-h"] and (t.selected or picture == "?") then
            picture = t["demux-w"] .. "x" .. t["demux-h"]
        end
    end
    local title = (mp.get_property("media-title") or ""):gsub("[%c|]", " "):gsub("%?.*$", ""):sub(1, 110)
    local line = os.date("%Y-%m-%d %H:%M:%S") .. " | " .. title .. " | picture " .. picture
        .. " | audio " .. (#sounds > 0 and table.concat(sounds, ",") or "none")
        .. " | subtitles " .. (shown and sub and (track_lang(sub) ~= "" and track_lang(sub) or "?") or "off")
        .. " (" .. subs .. " in the file)"
    local lines = {}
    local f = io.open(path, "r")
    if f then
        for l in f:lines() do lines[#lines + 1] = l end
        f:close()
    end
    lines[#lines + 1] = line
    f = io.open(path, "w")
    if not f then return end
    for i = math.max(1, #lines - LOG_LINES + 1), #lines do f:write(lines[i], "\n") end
    f:close()
end

-- Sets the two tracks. Run once before the video starts and once when it has started, so
-- the choice holds whichever way the file was opened.
local function choose(started)
    local tracks = mp.get_property_native("track-list") or {}
    local audio = pick_audio(tracks)
    local lang = audio and track_lang(audio) or ""
    local understood = lang == "en" or lang == "fr"
    local sub = pick_subtitle(tracks)

    if audio and mp.get_property_number("aid") ~= audio.id then
        mp.set_property_number("aid", audio.id)
    end
    if sub and lang ~= "" and not understood then
        if mp.get_property_number("sid") ~= sub.id then mp.set_property_number("sid", sub.id) end
    elseif mp.get_property("sid") ~= "no" then
        mp.set_property("sid", "no")
    end
    if started and not sub and lang ~= "" and not understood then
        mp.osd_message("No subtitles in this file - pick another stream", 6)
    end
    if started then pcall(note, tracks, audio, sub, sub and lang ~= "" and not understood) end
end

mp.add_hook("on_preloaded", 50, function() choose(false) end)

mp.register_event("file-loaded", function()
    mp.set_property("sub-ass-override", "force")
    mp.set_property_number("sub-scale", SUB_SCALE)
    mp.set_property_number("sub-pos", SUB_POS)
    choose(true)
end)
