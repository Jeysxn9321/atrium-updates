-- cards.lua
-- Streaming-style buttons over the picture, bottom right:
--   "Skip intro" / "Skip recap" / "Skip credits" / "Skip preview"
--        while a chapter with that name is playing (only files that have named chapters)
--   "Next episode"
--        in the last seconds of an episode, or during the end credits, when the next
--        episode is lined up (see episodes.lua; autoplay must be on)
-- Click the button, or press Enter while it is shown.

local assdraw = require 'mp.assdraw'

local MAX_DURATION = 75 * 60   -- films are left alone
local COUNTDOWN = 15           -- seconds before the end at which "Next episode" appears
local KINDS = {
    { label = "Skip recap",   words = { "recap", "previously" } },
    { label = "Skip intro",   words = { "intro", "opening", "op", "ncop" } },
    { label = "Skip credits", words = { "ending", "credits", "ed", "nced", "outro" }, ending = true },
    { label = "Skip preview", words = { "preview" }, ending = true },
}

local overlay = mp.create_osd_overlay("ass-events")
local card = nil       -- what is shown: { text, action, solid, box = {x0, y0, x1, y1} }
local inside = false   -- mouse pointer is over the button
local drawn = ""
local bound_click, bound_enter = false, false

local function kind_of(title)
    if not title or title == "" then return nil end
    local t = " " .. title:lower():gsub("[^%a%d]", " ") .. " "
    for _, kind in ipairs(KINDS) do
        for _, w in ipairs(kind.words) do
            if t:find(" " .. w .. " ", 1, true) or t:find(" " .. w .. "%d+ ") then return kind end
        end
    end
    return nil
end

local function has_next()
    local pos = mp.get_property_number("playlist-pos")
    local count = mp.get_property_number("playlist-count")
    return pos ~= nil and count ~= nil and pos >= 0 and pos < count - 1
end

local function play_next()
    mp.commandv("playlist-next", "force")
end

-- Decides which button, if any, belongs on screen right now.
local function decide()
    local dur = mp.get_property_number("duration")
    local pos = mp.get_property_number("time-pos")
    if not dur or not pos or dur < 120 or dur > MAX_DURATION then return nil end
    local chapter = mp.get_property_number("chapter")
    local list = mp.get_property_native("chapter-list") or {}
    local nxt_ready = has_next()
    if chapter and chapter >= 0 then
        local cur, nxt = list[chapter + 1], list[chapter + 2]
        local kind = cur and kind_of(cur.title)
        if kind then
            if nxt and nxt.time and nxt.time < dur - 5 then
                -- End credits followed only by more credits / preview: offer the next episode instead.
                local rest_is_ending = kind.ending
                for i = chapter + 2, #list do
                    local k = kind_of(list[i].title)
                    if not (k and k.ending) then rest_is_ending = false end
                end
                if rest_is_ending and nxt_ready then
                    return { text = "Next episode", action = play_next, solid = true }
                end
                local target = chapter + 1
                return { text = kind.label, action = function()
                    mp.set_property_number("chapter", target)
                end }
            elseif kind.ending and nxt_ready then
                return { text = "Next episode", action = play_next, solid = true }
            end
        end
    end
    local left = dur - pos
    if nxt_ready and left <= COUNTDOWN and left >= 0 then
        return { text = string.format("Next episode in %d", math.max(1, math.ceil(left))),
            action = play_next, solid = true }
    end
    return nil
end

local function press()
    if card and card.action then card.action() end
end

local function bind(click, enter)
    if click ~= bound_click then
        bound_click = click
        if click then
            mp.add_forced_key_binding("MBTN_LEFT", "card-click", press)
        else
            mp.remove_key_binding("card-click")
        end
    end
    if enter ~= bound_enter then
        bound_enter = enter
        if enter then
            mp.add_forced_key_binding("ENTER", "card-enter", press)
            mp.add_forced_key_binding("KP_ENTER", "card-kp-enter", press)
        else
            mp.remove_key_binding("card-enter")
            mp.remove_key_binding("card-kp-enter")
        end
    end
end

local function render()
    local w, h = mp.get_osd_size()
    if not card or not w or not h or w == 0 or h == 0 then
        card = nil
        inside = false
        bind(false, false)
        if drawn ~= "" then
            drawn = ""
            overlay:remove()
        end
        return
    end
    local s = h / 1080
    local font = 26 * s
    local bw = #card.text * font * 0.54 + 56 * s
    local bh = font + 30 * s
    local x1 = w - 64 * s
    local y1 = h - 160 * s
    local x0, y0 = x1 - bw, y1 - bh
    card.box = { x0, y0, x1, y1 }

    local m = mp.get_property_native("mouse-pos")
    inside = m ~= nil and m.hover ~= false and m.x >= x0 and m.x <= x1 and m.y >= y0 and m.y <= y1
    bind(inside, true)

    local fill, alpha, text_color = "000000", "60", "FFFFFF"
    if card.solid then fill, alpha, text_color = inside and "D0D0D0" or "FFFFFF", "00", "000000" end
    if not card.solid and inside then fill, alpha, text_color = "FFFFFF", "00", "000000" end

    local a = assdraw.ass_new()
    a:new_event()
    a:pos(0, 0)
    a:append(string.format("{\\an7\\blur0\\shad0\\bord%.1f\\3c&HFFFFFF&\\3a&H20&\\1c&H%s&\\1a&H%s&}",
        2 * s, fill, alpha))
    a:draw_start()
    a:round_rect_cw(x0, y0, x1, y1, 6 * s)
    a:draw_stop()
    a:new_event()
    a:pos((x0 + x1) / 2, (y0 + y1) / 2)
    a:append(string.format("{\\an5\\blur0\\shad0\\bord0\\b1\\fs%d\\1c&H%s&}", math.floor(font), text_color))
    a:append(card.text)

    local data = w .. "x" .. h .. a.text
    if data ~= drawn then
        drawn = data
        overlay.res_x, overlay.res_y = w, h
        overlay.data = a.text
        overlay:update()
    end
end

local function update()
    card = decide()
    render()
end

mp.add_periodic_timer(0.25, update)
mp.observe_property("chapter", "number", update)
mp.observe_property("playlist-count", "number", update)
mp.observe_property("osd-dimensions", "native", update)
mp.observe_property("mouse-pos", "native", function() if card then render() end end)
mp.register_event("end-file", function() card = nil render() end)

-- Quality badge on the gear button: "4K" while a 4K video is playing.
local badge_set = false
mp.observe_property("video-dec-params", "native", function(_, p)
    local is_4k = type(p) == "table" and ((p.w or 0) >= 3200 or (p.h or 0) >= 1800)
    if is_4k then
        mp.set_property("user-data/player/quality", "4K")
        badge_set = true
    elseif badge_set then
        mp.commandv("del", "user-data/player/quality")
        badge_set = false
    end
end)

-- ===== Centre controls =====
-- Big back 10 s / play-pause / forward 10 s in the middle of the picture. They appear when
-- the mouse moves and go away after a moment. A click anywhere still pauses and resumes;
-- a click on a 10 s button seeks.
local centre = mp.create_osd_overlay("ass-events")
local centre_drawn = ""
local last_move = -100
local last_xy = ""
local hover_side = 0       -- -1 = back button under the mouse, 1 = forward, 0 = neither
local centre_bound = false

local function centre_press()
    if hover_side ~= 0 then
        mp.commandv("seek", tostring(hover_side * 10))
        last_move = mp.get_time()
    end
end

local function centre_bind(on)
    if on == centre_bound then return end
    centre_bound = on
    if on then
        mp.add_forced_key_binding("MBTN_LEFT", "centre-click", centre_press)
        mp.add_forced_key_binding("MBTN_LEFT_DBL", "centre-dblclick", centre_press)
    else
        mp.remove_key_binding("centre-click")
        mp.remove_key_binding("centre-dblclick")
    end
end

local function render_centre()
    local w, h = mp.get_osd_size()
    local m = mp.get_property_native("mouse-pos")
    local show = w and h and w > 0 and h > 0 and type(m) == "table" and m.hover ~= false
        and mp.get_time() - last_move < 2.5
        and mp.get_property_number("duration") ~= nil
        and mp.get_property_native("user-data/uosc/menu/type") == nil
    if not show then
        hover_side = 0
        centre_bind(false)
        if centre_drawn ~= "" then
            centre_drawn = ""
            centre:remove()
        end
        return
    end
    local s = h / 1080
    local cx, cy, off = w / 2, h / 2, 300 * s
    hover_side = 0
    for _, side in ipairs({ -1, 1 }) do
        local dx, dy = m.x - (cx + side * off), m.y - cy
        if dx * dx + dy * dy <= (60 * s) ^ 2 then hover_side = side end
    end
    centre_bind(hover_side ~= 0)

    local function icon(x, name, size, lit)
        return string.format(
            "{\\an5\\pos(%d,%d)\\fnMaterialIconsRound-Regular\\fs%d\\b0\\blur0\\shad0\\bord%.1f\\1c&HFFFFFF&\\3c&H000000&\\3a&HA0&\\1a&H%s&}%s",
            math.floor(x), math.floor(cy), math.floor(size), 1.2 * s, lit and "00" or "30", name)
    end
    local paused = mp.get_property_bool("pause")
    local data = table.concat({
        icon(cx - off, "replay_10", 76 * s, hover_side == -1),
        icon(cx, paused and "play_arrow" or "pause", 120 * s, true),
        icon(cx + off, "forward_10", 76 * s, hover_side == 1),
    }, "\n")
    local key = w .. "x" .. h .. data
    if key ~= centre_drawn then
        centre_drawn = key
        centre.res_x, centre.res_y = w, h
        centre.data = data
        centre:update()
    end
end

mp.observe_property("mouse-pos", "native", function(_, m)
    if type(m) == "table" then
        local xy = tostring(m.x) .. "," .. tostring(m.y)
        if xy ~= last_xy then
            last_xy = xy
            last_move = mp.get_time()
        end
    end
    render_centre()
end)
mp.observe_property("pause", "bool", render_centre)
mp.add_periodic_timer(0.25, render_centre)
