-- audio.lua
-- Dialogue boost: when a surround track (5.1 / 7.1) is folded down to two speakers,
--   the centre (voice) channel is mixed in louder than usual.
-- Night mode: evens out loud and quiet scenes.
--
-- Hotkeys:
--   Alt+Shift+V   dialogue boost on / off   (on by default)
--   Alt+Shift+N   night mode on / off       (off by default)

local utils = require 'mp.utils'

local DIALOGUE = "@uwf_dialogue:lavfi=[aformat=channel_layouts=5.1,pan=stereo|FL<FC+0.707*FL+0.5*BL|FR<FC+0.707*FR+0.5*BR]"
local NIGHT = "@uwf_night:lavfi=[dynaudnorm=f=250:g=31:p=0.9:m=8:r=0.5]"

local state_path = mp.command_native({ "expand-path", "~~exe_dir/mpv/audio.json" })
local state = { dialogue = true, night = false }

local function load_state()
    local f = io.open(state_path, "r")
    if not f then return end
    local data = utils.parse_json(f:read("*a") or "")
    f:close()
    if type(data) ~= "table" then return end
    if type(data.dialogue) == "boolean" then state.dialogue = data.dialogue end
    if type(data.night) == "boolean" then state.night = data.night end
end

local function save_state()
    local f = io.open(state_path, "w")
    if not f then return end
    f:write(utils.format_json(state))
    f:close()
end

local function is_surround()
    local n = mp.get_property_number("audio-params/channel-count") or 0
    return n > 2
end

local function apply()
    mp.command("no-osd af remove @uwf_night")
    mp.command("no-osd af remove @uwf_dialogue")
    if state.dialogue and is_surround() then
        mp.commandv("af", "add", DIALOGUE)
    end
    if state.night then
        mp.commandv("af", "add", NIGHT)
    end
end

mp.add_key_binding("Alt+V", "dialogue-boost", function()
    state.dialogue = not state.dialogue
    save_state() apply()
    local msg = "Dialogue boost: " .. (state.dialogue and "on" or "off")
    if state.dialogue and not is_surround() then msg = msg .. " (this audio is not surround)" end
    mp.osd_message(msg, 2.5)
end)

mp.add_key_binding("Alt+N", "night-mode", function()
    state.night = not state.night
    save_state() apply()
    mp.osd_message("Night mode: " .. (state.night and "on" or "off"), 2.5)
end)

mp.observe_property("audio-params/channel-count", "number", apply)

load_state()
