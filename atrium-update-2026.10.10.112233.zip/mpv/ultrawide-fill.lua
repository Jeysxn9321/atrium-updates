-- ultrawide-fill.lua
-- Ultrawide Fill for mpv: zoom / hybrid / stretch a video to fill a 32:9 screen.
--
-- Hotkeys (same as the browser extension where it has them):
--   Alt+Shift+U           turn Ultrawide Fill on / off
--   Alt+Shift+M           cycle mode: Off -> Zoom -> Partial zoom -> Hybrid -> Stretch
--   Alt+Shift+F           show the current status
--   Alt+Shift+D           detect black bars again
--   Alt+Shift+B           protect burned-in subtitles on / off
--   Alt+Shift+Up / Down   vertical nudge
--   Alt+Shift+Right / Left  extra zoom
--
-- Three modes are remembered separately: one for wide film formats, one for 16:9
-- (and narrower) anime, and one for every other 16:9 video such as TV series.
--
-- The screen shape is read live, so picture-by-picture mode is handled by itself:
-- on a 16:9 half nothing is cropped or stretched unless the video is narrower than
-- that half (4:3 video still gets its fill mode).

local utils = require 'mp.utils'

-- ===== Settings (same meaning as in the browser extension) =====
local cfg = {
    target_ratio     = 32 / 9,   -- Target screen ratio (Odyssey G9)
    default_mode     = "zoom",   -- wide films: off / zoom / partial / hybrid / stretch
    default_mode_narrow = "partial", -- 16:9 and narrower anime (video with a Japanese audio track)
    default_mode_tv  = "zoom",   -- every other 16:9 and narrower video (TV series)
    narrow_ratio     = 1.82,     -- pictures up to this shape count as "16:9 or narrower"
    partial_scale    = 4 / 3,    -- Partial zoom: enlarge by a third (crops a quarter of the height)
    autodetect       = true,     -- Auto-detect black bars
    extra_zoom       = 1.00,     -- Extra zoom (1.00 = 100%)
    protect_faces    = 0.60,     -- 0 = crop evenly, 1 = crop from the bottom only
    protect_subs     = false,    -- Protect burned-in subtitles (crop from the top only)
    vertical_nudge   = 0.0,      -- Vertical nudge (-0.5 .. 0.5)
    only_fullscreen  = true,     -- Only in fullscreen
    start_fullscreen = true,     -- Open videos in fullscreen
    sub_scale        = 1.0,      -- Subtitle size (1.0 = normal)
    sub_height       = 8,        -- Subtitle height, % up from the bottom
}
-- ===== End of settings =====

local MODES = { "off", "zoom", "partial", "hybrid", "stretch" }
local NAMES = { off = "Off", zoom = "Zoom", partial = "Partial zoom", hybrid = "Hybrid", stretch = "Stretch" }
local LABEL = "uwf_cropdetect"
local MAX_ATTEMPTS = 8

-- A detected picture area is only trusted when it matches a real film / TV shape.
-- A dark scene can make the picture look smaller than it is; those results are thrown away.
local STANDARD_RATIOS = { 1.33, 1.37, 1.66, 1.78, 1.85, 2.0, 2.2, 2.35, 2.39, 2.4, 2.55, 2.76 }

-- Normal playback decodes straight on the graphics card (smoothest, needed for 4K 60 fps).
-- Black bar detection reads the picture in software, so it switches to copy mode for a few seconds.
local HWDEC_PLAY = "auto-safe"
local HWDEC_DETECT = "auto-copy"

local state = { enabled = true, mode = cfg.default_mode, mode_narrow = cfg.default_mode_narrow,
    mode_tv = cfg.default_mode_tv, crop = nil }
local anime = false     -- true when the video that is playing has a Japanese audio track
local state_path = mp.command_native({ "expand-path", "~~exe_dir/mpv/ultrawide-fill.json" })
local detecting = false
local detect_timer = nil
local attempts = 0
local crops_path = mp.command_native({ "expand-path", "~~exe_dir/mpv/ultrawide-crops.json" })
local remembered = {}   -- series -> black bars found last time, applied at once on the next episode
local video_key = nil   -- the series that is playing (nil for films)
local recall = false    -- true until the remembered bars have been applied to this video

local function valid_mode(m)
    for _, name in ipairs(MODES) do
        if m == name then return true end
    end
    return false
end

local function load_state()
    local f = io.open(state_path, "r")
    if not f then return end
    local data = utils.parse_json(f:read("*a") or "")
    f:close()
    if type(data) ~= "table" then return end
    if type(data.enabled) == "boolean" then state.enabled = data.enabled end
    if valid_mode(data.mode) then state.mode = data.mode end
    if valid_mode(data.mode_narrow) then state.mode_narrow = data.mode_narrow end
    if valid_mode(data.mode_tv) then state.mode_tv = data.mode_tv end
end

local function save_state()
    local f = io.open(state_path, "w")
    if not f then return end
    f:write(utils.format_json({ enabled = state.enabled, mode = state.mode, mode_narrow = state.mode_narrow,
        mode_tv = state.mode_tv }))
    f:close()
end

local function load_crops()
    local f = io.open(crops_path, "r")
    if not f then return end
    local data = utils.parse_json(f:read("*a") or "")
    f:close()
    if type(data) == "table" then remembered = data end
end

local function save_crops()
    local f = io.open(crops_path, "w")
    if not f then return end
    f:write(utils.format_json(remembered))
    f:close()
end

-- Name of the series a video belongs to, taken from its title; nil when it is not an episode.
local function series_key()
    local t = (mp.get_property("media-title") or mp.get_property("filename") or ""):lower()
    t = t:gsub("%b[]", " ")
    t = t:gsub("%b()", " ")
    t = t:gsub("[%._]", " ")
    local a = t:find("%f[%a]s%d+%s*e%d+") or t:find("%s%-%s+%d+") or t:find("%f[%a]episode%s*%d+")
    if not a then return nil end
    t = t:sub(1, a - 1):gsub("%s+", " ")
    t = t:gsub("^%s+", "")
    t = t:gsub("[%s%-]+$", "")
    if t == "" then return nil end
    return t
end

-- Anime is told apart from other 16:9 video by its Japanese audio track (the sign
-- anime4k.lua goes by too). A dub with no Japanese track counts as ordinary TV.
local function has_japanese_audio()
    for _, t in ipairs(mp.get_property_native("track-list") or {}) do
        if t.type == "audio" then
            local lang = ((t.lang or ""):lower():match("^[a-z]+")) or ""
            if lang == "ja" or lang == "jpn" then return true end
        end
    end
    return false
end

local function standard_ratio(r)
    for _, s in ipairs(STANDARD_RATIOS) do
        if math.abs(r - s) / s <= 0.025 then return true end
    end
    return false
end

local function target_ratio()
    if mp.get_property_bool("fullscreen") then
        local w, h = mp.get_osd_size()
        if w and h and w > 0 and h > 0 then return w / h end
    end
    return cfg.target_ratio
end

-- Shape of the real picture (after black bars are removed), or nil with no video.
local function picture_ratio()
    local p = mp.get_property_native("video-dec-params")
    if not p or not p.w or not p.h or p.w == 0 or p.h == 0 then return nil end
    local w, h = p.w, p.h
    if state.crop then w, h = state.crop.w, state.crop.h end
    return w * ((p.par or 0) > 0 and p.par or 1) / h
end

local function is_narrow()
    local r = picture_ratio()
    return r ~= nil and r <= cfg.narrow_ratio
end

local function current_mode()
    if is_narrow() then return anime and state.mode_narrow or state.mode_tv end
    return state.mode
end

-- True when the screen is not wider than the picture (a 16:9 screen, or one half of
-- the monitor in picture-by-picture mode). There is nothing to fill then, and zooming
-- would cut the sides of the picture off, so the whole picture is shown instead.
local function nothing_to_fill()
    local r = picture_ratio()
    return r ~= nil and r >= target_ratio() * 0.98
end

local function reset_view()
    mp.set_property("video-crop", "")
    mp.set_property("video-aspect-override", "no")
    mp.set_property_number("panscan", 0)
    mp.set_property_number("video-zoom", 0)
    mp.set_property_number("video-align-y", 0)
    mp.set_property_number("video-pan-y", 0)
end

-- Same series and same picture size as last time: remove the same black bars at once.
local function recall_bars()
    local p = mp.get_property_native("video-dec-params")
    if not recall or not p or not p.w or not p.h or p.w == 0 then return end
    local m = video_key and remembered[video_key]
    if type(m) == "table" and m.vw == p.w and m.vh == p.h and not state.crop then
        state.crop = { w = m.w, h = m.h, x = m.x, y = m.y }
    end
    recall = false
end

local function apply()
    recall_bars()
    local p = mp.get_property_native("video-dec-params")
    local mode = current_mode()
    local active = state.enabled and mode ~= "off"
        and (not cfg.only_fullscreen or mp.get_property_bool("fullscreen"))
    if not active or not p or not p.w or not p.h or p.w == 0 or p.h == 0 then
        reset_view()
        return
    end

    -- 1. Remove the black bars found by auto-detect.
    local cw, ch = p.w, p.h
    if state.crop then
        cw, ch = state.crop.w, state.crop.h
        mp.set_property("video-crop",
            string.format("%dx%d+%d+%d", cw, ch, state.crop.x, state.crop.y))
    else
        mp.set_property("video-crop", "")
    end

    -- 2. Decide how wide the real picture should be shown.
    local picture = cw * ((p.par or 0) > 0 and p.par or 1) / ch
    local target = target_ratio()
    if picture >= target * 0.98 then
        -- Screen no wider than the picture (picture-by-picture half): show it whole.
        mp.set_property("video-aspect-override", "no")
        mp.set_property_number("panscan", 0)
        mp.set_property_number("video-zoom", 0)
        mp.set_property_number("video-align-y", 0)
        mp.set_property_number("video-pan-y", 0)
        return
    end
    local want = nil
    if mode == "hybrid" and picture < target then
        want = math.sqrt(picture * target)   -- half stretch, half crop
    elseif mode == "stretch" then
        want = target                        -- all stretch, no crop
    end
    if want then
        local full = want * (p.w / p.h) * (ch / cw)
        mp.set_property("video-aspect-override", string.format("%.5f", full))
    else
        mp.set_property("video-aspect-override", "no")
    end

    -- 3. Fill the screen and place the crop.
    -- panscan 0 = whole picture visible, 1 = screen completely filled.
    local pan = 1
    if mode == "partial" and picture < target then
        pan = math.min(1, picture * (cfg.partial_scale - 1) / (target - picture))
    end
    mp.set_property_number("panscan", pan)
    mp.set_property_number("video-zoom", math.log(math.max(cfg.extra_zoom, 0.1)) / math.log(2))
    local align = cfg.protect_subs and 1 or -cfg.protect_faces
    mp.set_property_number("video-align-y", align)
    mp.set_property_number("video-pan-y", cfg.vertical_nudge)
end

local start_detect

local function stop_detect_filter()
    if detecting then
        mp.command("no-osd vf remove @" .. LABEL)
        detecting = false
    end
    mp.set_property("hwdec", HWDEC_PLAY)
end

local function finish_detect()
    detect_timer = nil
    if not detecting then return end
    local md = mp.get_property_native("vf-metadata/" .. LABEL)
    stop_detect_filter()

    local p = mp.get_property_native("video-dec-params")
    local retry = true
    if md and p and p.w and p.h and p.w > 0 and p.h > 0 then
        local w = tonumber(md["lavfi.cropdetect.w"])
        local h = tonumber(md["lavfi.cropdetect.h"])
        local x = tonumber(md["lavfi.cropdetect.x"])
        local y = tonumber(md["lavfi.cropdetect.y"])
        if w and h and x and y and w > 0 and h > 0 then
            local cut_tb = (p.h - h) / p.h
            local cut_lr = (p.w - w) / p.w
            local centered = math.abs(y - (p.h - h - y)) <= p.h * 0.03
                and math.abs(x - (p.w - w - x)) <= p.w * 0.03
            if cut_tb < 0.02 and cut_lr < 0.02 then
                if video_key and remembered[video_key] then
                    remembered[video_key] = nil
                    save_crops()
                end
                state.crop = nil          -- no black bars in this video
                retry = false
            elseif centered and cut_tb <= 0.45 and cut_lr <= 0.45
                and standard_ratio(w * ((p.par or 0) > 0 and p.par or 1) / h) then
                if video_key then
                    remembered[video_key] = { w = w, h = h, x = x, y = y, vw = p.w, vh = p.h }
                    save_crops()
                end
                state.crop = { w = w, h = h, x = x, y = y }
                retry = false
            end
        end
    end
    apply()
    -- A dark scene gives no usable answer: try again a little later.
    if retry and attempts < MAX_ATTEMPTS then
        detect_timer = mp.add_timeout(20, start_detect)
    end
end

start_detect = function()
    if detect_timer then detect_timer:kill() detect_timer = nil end
    stop_detect_filter()
    if not cfg.autodetect then return end
    if not mp.get_property_native("video-dec-params") then
        -- The video has not started yet (slow stream): look again shortly.
        state.waits = (state.waits or 0) + 1
        if state.waits <= 90 then detect_timer = mp.add_timeout(2, start_detect) end
        return
    end
    state.waits = 0
    attempts = attempts + 1
    mp.set_property("hwdec", HWDEC_DETECT)
    -- Give the decoder a moment to switch before reading the picture.
    detect_timer = mp.add_timeout(1, function()
        detect_timer = nil
        local ok = mp.command(string.format(
            "no-osd vf pre @%s:cropdetect=limit=24/255:round=2:reset=0", LABEL))
        if not ok then
            mp.set_property("hwdec", HWDEC_PLAY)
            return
        end
        detecting = true
        detect_timer = mp.add_timeout(3, finish_detect)
    end)
end

local function show()
    local mode = current_mode()
    if state.enabled and mode ~= "off" and mp.get_property_bool("fullscreen") and nothing_to_fill() then
        mp.osd_message("Ultrawide Fill: whole picture shown (this screen is not wider than the video)", 3)
        return
    end
    local msg = "Ultrawide Fill: " .. (state.enabled and NAMES[mode] or "disabled")
    if is_narrow() then msg = msg .. (anime and " (16:9 anime)" or " (16:9 video)") end
    if state.enabled and mode ~= "off" then
        if state.crop then msg = msg .. " | black bars removed" end
        if cfg.protect_subs then msg = msg .. " | subtitles protected" end
        msg = msg .. string.format(" | zoom %d%%", math.floor(cfg.extra_zoom * 100 + 0.5))
        if cfg.only_fullscreen and not mp.get_property_bool("fullscreen") then
            msg = msg .. " | waiting for fullscreen"
        end
    end
    mp.osd_message(msg, 2.5)
end

mp.add_key_binding("Alt+U", "uwf-toggle", function()
    state.enabled = not state.enabled
    save_state() apply() show()
end)

mp.add_key_binding("Alt+M", "uwf-cycle", function()
    local cur = current_mode()
    local i = 1
    for n, m in ipairs(MODES) do
        if m == cur then i = n end
    end
    local nxt = MODES[i % #MODES + 1]
    if not is_narrow() then state.mode = nxt elseif anime then state.mode_narrow = nxt else state.mode_tv = nxt end
    state.enabled = true
    save_state() apply() show()
end)

mp.add_key_binding("Alt+F", "uwf-status", show)

mp.add_key_binding("Alt+D", "uwf-detect", function()
    attempts = 0
    start_detect()
    mp.osd_message("Ultrawide Fill: detecting black bars...", 3)
end)

mp.add_key_binding("Alt+B", "uwf-subs", function()
    cfg.protect_subs = not cfg.protect_subs
    apply() show()
end)

local function nudge(step)
    cfg.vertical_nudge = math.max(-0.5, math.min(0.5, cfg.vertical_nudge + step))
    apply()
    mp.osd_message(string.format("Vertical nudge: %d%%", math.floor(cfg.vertical_nudge * 100 + 0.5)), 1.5)
end
mp.add_key_binding("Alt+Shift+UP", "uwf-nudge-up", function() nudge(-0.01) end, { repeatable = true })
mp.add_key_binding("Alt+Shift+DOWN", "uwf-nudge-down", function() nudge(0.01) end, { repeatable = true })

local function zoom(step)
    cfg.extra_zoom = math.max(1.0, math.min(1.5, cfg.extra_zoom + step))
    apply()
    mp.osd_message(string.format("Extra zoom: %d%%", math.floor(cfg.extra_zoom * 100 + 0.5)), 1.5)
end
mp.add_key_binding("Alt+Shift+RIGHT", "uwf-zoom-in", function() zoom(0.01) end, { repeatable = true })
mp.add_key_binding("Alt+Shift+LEFT", "uwf-zoom-out", function() zoom(-0.01) end, { repeatable = true })

mp.register_event("file-loaded", function()
    state.crop = nil
    attempts = 0
    video_key = series_key()
    anime = has_japanese_audio()
    recall = true
    if cfg.start_fullscreen then mp.set_property_bool("fullscreen", true) end
    apply()
    if detect_timer then detect_timer:kill() end
    detect_timer = mp.add_timeout(1.5, start_detect)
end)

mp.observe_property("fullscreen", "bool", apply)
mp.observe_property("video-dec-params", "native", apply)
mp.observe_property("osd-dimensions", "native", apply)

-- Startup
load_state()
mp.set_property("hwdec", HWDEC_PLAY)
load_crops()
mp.set_property_number("sub-scale", cfg.sub_scale)
mp.set_property_number("sub-pos", 100 - cfg.sub_height)
