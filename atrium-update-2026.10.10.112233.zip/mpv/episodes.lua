-- episodes.lua
-- Previous / next episode and autoplay for videos opened from Stremio through TorBox.
--
-- Stremio hands the player one video at a time, so this script finds the neighbours itself:
--   1. If the download holds several episodes (a season pack), it asks TorBox which
--      files are in it and takes the one before / after.
--   2. Otherwise it works out which series and episode is playing, asks Torrentio for
--      the streams of the next episode (as Stremio does) and takes the sharpest one
--      that TorBox can play straight away (4K before 1080p before 720p); among equally
--      sharp ones, the same release group as the playing episode.
--   A season pack below 4K is left for a sharper release of the next episode, if there is one.
--
--   Control bar buttons: previous episode / next episode
--   Alt+PageUp / Alt+PageDown   previous / next episode
--   Alt+Shift+A                 autoplay the next episode at the end: on / off (remembered)
--
-- Episodes watched to the end are also ticked in Stremio, if "stremio-key.txt" exists
-- (see the "Watched ticks" section further down).
--
-- It only works for Torrentio streams played through TorBox. The TorBox key is read from
-- the address of the video that is playing; it is not stored anywhere by this script.

local utils = require 'mp.utils'

local AUTOPLAY = true   -- starting value; Alt+Shift+A changes it and the choice is remembered
local API = "https://api.torbox.app/v1/api/torrents/"
local TORRENTIO = "https://torrentio.strem.fun/"
local KITSU = "https://kitsu.io/api/edge/anime?page%5Blimit%5D=4&filter%5Btext%5D="
local CINEMETA = "https://v3-cinemeta.strem.io/catalog/series/top/search="
local VIDEO = { mkv = true, mp4 = true, avi = true, m4v = true, webm = true, mov = true, ts = true, wmv = true }
-- Files with these words are bonus material, not episodes.
local EXTRAS = { "ncop", "nced", "creditless", "sample", "trailer", "preview", "menu", "extra", "bonus", "interview" }

local state_path = mp.command_native({ "expand-path", "~~exe_dir/mpv/episodes.json" })
local autoplay = AUTOPLAY
local packs = {}        -- info hash -> list of video files in that download
local current = nil     -- what is playing: { key, hash, name, list, pos }
local queued = nil      -- address added to the playlist for autoplay
local fetching = false
local waiting = {}      -- things to do once the file list has arrived
local generation = 0
local known_series = {} -- series already recognised while the player stays open
local choices = {}      -- address we chose -> the other candidates, in case it will not play
local unplayable = {}   -- downloads that turned out not to play (kept while the player stays open)

local function load_state()
    local f = io.open(state_path, "r")
    if not f then return end
    local data = utils.parse_json(f:read("*a") or "")
    f:close()
    if type(data) == "table" and type(data.autoplay) == "boolean" then autoplay = data.autoplay end
end

local function save_state()
    local f = io.open(state_path, "w")
    if not f then return end
    f:write(utils.format_json({ autoplay = autoplay }))
    f:close()
end

local function url_decode(s)
    return (s:gsub("%%(%x%x)", function(h) return string.char(tonumber(h, 16)) end))
end

local function url_encode(s)
    return (s:gsub("[^%w%-_%.~!%*'%(%)]", function(c) return string.format("%%%02X", c:byte()) end))
end

-- Reads the TorBox key, the download and the file name out of a Torrentio address.
local function parse(url)
    local key, hash, entry, rest = (url or ""):match(
        "^https?://torrentio%.strem%.fun/resolve/torbox/([^/]+)/(%x+)/([^/]+)/(.*)$")
    if not key or #hash ~= 40 then return nil end
    local file = rest:match("^[^/]*/([^/?#]+)")
    return { key = key, hash = hash:lower(), name = url_decode(file or entry) }
end

local function build_url(info, file)
    local name = url_encode(file.name)
    return string.format("https://torrentio.strem.fun/resolve/torbox/%s/%s/%s/%d/%s",
        info.key, info.hash, name, file.id, name)
end

local function is_extra(path)
    for _, word in ipairs(EXTRAS) do
        if path:find("%f[%a]" .. word) then return true end
    end
    return false
end

-- Orders names the way a person would: "Episode 9" before "Episode 10".
local function natural_less(a, b)
    local ia, ib = 1, 1
    while ia <= #a and ib <= #b do
        local da, db = a:match("^%d+", ia), b:match("^%d+", ib)
        if da and db then
            local na, nb = tonumber(da), tonumber(db)
            if na ~= nb then return na < nb end
            ia, ib = ia + #da, ib + #db
        else
            local ca, cb = a:sub(ia, ia), b:sub(ib, ib)
            if ca ~= cb then return ca < cb end
            ia, ib = ia + 1, ib + 1
        end
    end
    return (#a - ia) < (#b - ib)
end

-- Looks through TorBox's answer for the download with this hash (or, when the question
-- was about one download only, for the first entry that lists files).
local function find_download(node, hash, any, depth)
    if type(node) ~= "table" or depth > 6 then return nil end
    if type(node.files) == "table" and #node.files > 0 then
        local h = type(node.hash) == "string" and node.hash:lower() or nil
        if h == hash or (any and h == nil) then return node end
    end
    for k, v in pairs(node) do
        if type(v) == "table" and k ~= "files" then
            local found = find_download(v, hash, any or (type(k) == "string" and k:lower() == hash), depth + 1)
            if found then return found end
        end
    end
    return nil
end

-- Turns TorBox's answer into the list of video files of one download.
local function read_pack(data, hash, any)
    local t = find_download(data, hash, any, 0)
    if not t then
        local why = "download not listed"
        if data.success == false then why = tostring(data.detail or data.error or "refused") end
        return nil, why:sub(1, 120)
    end
    local files = {}
    for i, f in ipairs(t.files) do
        if type(f) == "table" then
            local path = tostring(f.name or f.short_name or "")
            local name = tostring(f.short_name or path):match("[^/\\]+$") or ""
            local ext = (name:match("%.(%w+)$") or ""):lower()
            if VIDEO[ext] then
                files[#files + 1] = {
                    name = name,
                    path = path:lower(),
                    dir = (path:lower():match("^(.*)[/\\][^/\\]*$")) or "",
                    id = math.floor(tonumber(f.id) or (i - 1)),
                }
            end
        end
    end
    if #files == 0 then return nil, "no video files listed" end
    table.sort(files, function(a, b) return natural_less(a.path, b.path) end)
    return files
end

-- Finds the playing file in the download and keeps the episodes around it.
local function locate(info)
    local files = packs[info.hash]
    info.list, info.pos, info.before, info.after = nil, nil, nil, nil
    if not files then return end
    local wanted = info.name:lower()
    local me = nil
    for _, f in ipairs(files) do
        if f.name:lower() == wanted then me = f break end
    end
    if not me then
        mp.msg.warn("the playing file is not in TorBox's list for this download")
        return
    end
    local keep_extras = is_extra(me.path)
    local list = {}
    for _, f in ipairs(files) do
        if f == me or keep_extras or not is_extra(f.path) then list[#list + 1] = f end
    end
    -- Episodes in the same folder come first; other folders (other seasons) only at the ends.
    local same, pos = {}, nil
    for _, f in ipairs(list) do
        if f.dir == me.dir then
            same[#same + 1] = f
            if f == me then pos = #same end
        end
    end
    local all_pos = nil
    for i, f in ipairs(list) do if f == me then all_pos = i end end
    info.before = same[pos - 1] or (list[all_pos - 1])
    info.after = same[pos + 1] or (list[all_pos + 1])
    info.list, info.pos = same, pos
end

local function finish_fetch()
    fetching = false
    local todo = waiting
    waiting = {}
    for _, f in ipairs(todo) do f() end
end

-- Fetches an address and hands the decoded answer to done(data), or done(nil, why).
local function get_json(url, key, done)
    local args = { "curl", "-s", "-L", "-m", "25" }
    if key then
        args[#args + 1] = "-H"
        args[#args + 1] = "Authorization: Bearer " .. key
    end
    args[#args + 1] = url
    mp.command_native_async({
        name = "subprocess",
        playback_only = false,
        capture_stdout = true,
        capture_stderr = true,
        args = args,
    }, function(ok, res)
        if ok and res and res.status == 0 then
            local data = utils.parse_json(res.stdout or "")
            if type(data) == "table" then
                done(data)
            else
                done(nil, string.format("unreadable answer (%d bytes)", #(res.stdout or "")))
            end
        else
            done(nil, "no answer (curl status " .. tostring(res and res.status) .. ")")
        end
    end)
end

-- Three ways of asking TorBox for the files of a download, tried in this order.
local function sources(info)
    return {
        { label = "my downloads", any = false, auth = true,
          url = API .. "mylist?bypass_cache=true&limit=1000" },
        { label = "cached files", any = true, auth = true,
          url = API .. "checkcached?format=list&list_files=true&hash=" .. info.hash },
        { label = "torrent info", any = true, auth = false,
          url = API .. "torrentinfo?timeout=10&hash=" .. info.hash },
    }
end

local function ask(info, list, n)
    local src = list[n]
    if not src then
        finish_fetch()
        return
    end
    get_json(src.url, src.auth and info.key or nil, function(data, why)
        local files = nil
        if data then files, why = read_pack(data, info.hash, src.any) end
        if files then
            packs[info.hash] = files
            finish_fetch()
            return
        end
        mp.msg.warn("TorBox " .. src.label .. ": " .. tostring(why))
        ask(info, list, n + 1)
    end)
end

-- Makes sure the file list of the playing download is known, then calls done().
local function ensure(info, done)
    if packs[info.hash] then
        locate(info)
        done()
        return
    end
    waiting[#waiting + 1] = function()
        locate(info)
        done()
    end
    if fetching then return end
    fetching = true
    ask(info, sources(info), 1)
end

-- ===== Episodes that are not in the same download =====

local function trim(t)
    t = t:gsub("%s+", " ")
    t = t:gsub("^[%s%-:,]+", "")
    t = t:gsub("[%s%-:,]+$", "")
    return t
end

-- Reads series title, season, episode, release group and quality out of a file name.
local function describe(filename)
    local t = filename:lower()
    t = t:gsub("%.%w%w%w?%w?$", "")
    local tag = t:match("^%s*(%b[])") or t:match("%-(%w+)$")
    local res = t:match("(%d%d%d%d?p)")
    if not res and t:match("x(%d%d%d%d?)%f[%D]") then res = t:match("x(%d%d%d%d?)%f[%D]") .. "p" end
    t = t:gsub("%b[]", " ")
    t = t:gsub("%b()", " ")
    t = t:gsub("[%._]", " ")
    t = " " .. t .. " "
    local a, season, ep, _
    a, _, season, ep = t:find("%f[%a]s(%d+)%s*e(%d+)")
    if not a then a, _, ep = t:find("%f[%a]episode%s*(%d+)") end
    if not a then a, _, ep = t:find("%f[%a]ep%s*(%d+)") end
    if not a then a, _, ep = t:find("%s%-%s+(%d+)%f[%D]") end
    if not a then a, _, ep = t:find("%f[%a]e(%d+)%f[%D]") end
    if not a then return nil end
    local title = trim(t:sub(1, a - 1))
    title = trim((title:gsub("%s[12][09]%d%d$", "")))
    if title == "" then return nil end
    return { title = title, season = tonumber(season), ep = tonumber(ep), tag = tag, res = res }
end

local function video_id(series, season, ep)
    if series.kind == "kitsu" then return "kitsu:" .. series.id .. ":" .. ep end
    return series.id .. ":" .. season .. ":" .. ep
end

local function streams_url(info, vid)
    return TORRENTIO .. "torbox=" .. info.key .. "/stream/series/" .. vid:gsub(":", "%%3A") .. ".json"
end

local function stream_file(st)
    local hints = type(st.behaviorHints) == "table" and st.behaviorHints or {}
    if type(hints.filename) == "string" then return hints.filename end
    return url_decode(st.url:match("([^/]+)$") or "")
end

-- Size in GB and "dubbed" flag as Torrentio prints them in a stream's description.
-- "Dual audio" is not a dub: the original voices are still in the file.
local function stream_facts(st)
    local title = type(st.title) == "string" and st.title or ""
    local size = nil
    local n, unit = title:match("([%d%.]+)%s*([GM]B)")
    if n then
        size = tonumber(n)
        if size and unit == "MB" then size = size / 1024 end
    end
    local lower = title:lower()
    local dub = (lower:find("dubbed", 1, true) ~= nil or lower:find("english dub", 1, true) ~= nil)
        and lower:find("dual", 1, true) == nil
    return size, dub
end

-- Picture height a stream promises: 2160, 1080, 720 ... (0 when it does not say).
local function stream_res(st)
    local text = (st.name .. " " .. stream_file(st)):lower()
    if text:find("4k", 1, true) or text:find("2160p", 1, true) then return 2160 end
    return tonumber(text:match("(%d%d%d%d?)p")) or 0
end

local function has_word(text, word)
    return text:find("%f[%a]" .. word .. "%f[%A]") ~= nil
end

-- 0: English, several languages, or not said; 1: French only; 2: another language only.
local OTHER_LANGUAGES = { "ita", "italian", "ger", "german", "spa", "spanish", "latino", "castellano",
    "rus", "russian", "hindi", "pol", "tur", "por", "dublado" }
local function stream_language(st)
    local text = ((type(st.title) == "string" and st.title or "") .. " " .. stream_file(st)):lower()
    if has_word(text, "eng") or has_word(text, "english") or has_word(text, "multi") then return 0 end
    for _, word in ipairs(OTHER_LANGUAGES) do
        if has_word(text, word) then return 2 end
    end
    if has_word(text, "french") or has_word(text, "truefrench") or has_word(text, "vff")
        or has_word(text, "vfq") or has_word(text, "vf") or has_word(text, "vostfr") then return 1 end
    return 0
end

-- The sharpest picture this PC plays smoothly (2160 or 1080 lines). Atrium's home server works
-- it out from the graphics card and keeps it in device.json; without that file, no limit.
local device_max = 2160
do
    local f = io.open(mp.command_native({ "expand-path", "~~exe_dir/mpv/device.json" }), "r")
    if f then
        local d = utils.parse_json(f:read("*a") or "")
        f:close()
        if type(d) == "table" and tonumber(d.max) then device_max = tonumber(d.max) end
    end
end

-- Height of the picture that is playing, as a quality step; nil when it is not known yet.
local function playing_res()
    local w = mp.get_property_number("video-params/w")
    local h = mp.get_property_number("video-params/h")
    if not w or not h then return nil end
    if w >= 3200 or h >= 1800 then return 2160 end
    if w >= 1800 or h >= 1000 then return 1080 end
    if w >= 1200 or h >= 700 then return 720 end
    return 480
end

-- Lists the streams TorBox can play at once: the sharpest first, and among equally sharp
-- ones the closest to the playing release. English comes before French-only releases of the
-- same sharpness, and a release in another language only counts as a step less sharp.
local function rank(streams, want)
    local list = {}
    for i, st in ipairs(type(streams) == "table" and streams or {}) do
        if type(st) == "table" and type(st.url) == "string" and type(st.name) == "string"
            and st.name:find("[TB+]", 1, true) then
            local hash = (st.url:match("/resolve/torbox/[^/]+/(%x+)/") or ""):lower()
            local hints = type(st.behaviorHints) == "table" and st.behaviorHints or {}
            local file = stream_file(st):lower()
            local size, dub = stream_facts(st)
            local score = 0
            if want.group and hints.bingeGroup == want.group then score = score + 100 end
            if want.tag and (file:match("^%s*(%b[])") == want.tag or file:match("%-(%w+)%.%w+$") == want.tag) then
                score = score + 50
            end
            if want.size and size then
                score = score + 15 * math.max(0, 1 - math.abs(size - want.size) / want.size)
            end
            if dub then score = score - 40 end
            if not unplayable[hash] then
                local res = stream_res(st)
                -- sharper than this PC plays smoothly: only when there is nothing else
                if res > device_max then res = res * 0.4 end
                local language = stream_language(st)
                if language == 2 then res = res * 0.45 elseif language == 1 then res = res - 1 end
                list[#list + 1] = { url = st.url, name = stream_file(st), score = score, order = i, res = res }
            end
        end
    end
    table.sort(list, function(x, y)
        if x.res ~= y.res then return x.res > y.res end
        if x.score ~= y.score then return x.score > y.score end
        return x.order < y.order
    end)
    while #list > 5 do list[#list] = nil end
    return list
end

-- Works out which series is playing: looks the title up, then checks the guess by
-- finding the playing download among that episode's streams.
local function identify(info, done)
    if info.series ~= nil then
        done()
        return
    end
    local d = describe(info.name)
    if not d then
        info.series = false
        done()
        return
    end
    local memo = d.title .. "|" .. tostring(d.season)
    local want = { tag = d.tag, res = d.res }
    local seen = known_series[memo]
    if seen then
        want.group, want.size, want.dub = seen.group, seen.size, seen.dub
        info.series = { kind = seen.kind, id = seen.id, season = seen.season, ep = d.ep, want = want, name = seen.name, poster = seen.poster }
        done()
        return
    end
    local candidates = {}
    local function check(n)
        local c = candidates[n]
        if not c or n > 4 then
            -- Nothing confirmed: accept a series whose name is exactly the title, if any.
            for _, x in ipairs(candidates) do
                if type(x.name) == "string" and trim(x.name:lower():gsub("[%._:]", " ")) == d.title then
                    info.series = { kind = x.kind, id = x.id, season = x.season, ep = d.ep, want = want, name = x.name, poster = x.poster }
                    known_series[memo] = { kind = x.kind, id = x.id, season = x.season, name = x.name, poster = x.poster }
                    done()
                    return
                end
            end
            mp.msg.warn("could not match \"" .. d.title .. "\" to a series")
            info.series = false
            done()
            return
        end
        get_json(streams_url(info, video_id(c, c.season, d.ep)), nil, function(data, why)
            if not data then mp.msg.warn("Torrentio: " .. tostring(why)) end
            for _, st in ipairs(data and type(data.streams) == "table" and data.streams or {}) do
                if type(st) == "table" and type(st.url) == "string" and st.url:lower():find(info.hash, 1, true) then
                    local hints = type(st.behaviorHints) == "table" and st.behaviorHints or {}
                    want.group = hints.bingeGroup
                    want.size, want.dub = stream_facts(st)
                    info.series = { kind = c.kind, id = c.id, season = c.season, ep = d.ep, want = want, name = c.name, poster = c.poster }
                    known_series[memo] = { kind = c.kind, id = c.id, season = c.season, group = want.group,
                        size = want.size, dub = want.dub, name = c.name, poster = c.poster }
                    done()
                    return
                end
            end
            check(n + 1)
        end)
    end
    local function from_kitsu(after)
        get_json(KITSU .. url_encode(d.title), nil, function(data, why)
            if not data then mp.msg.warn("Kitsu: " .. tostring(why)) end
            for i, a in ipairs(data and type(data.data) == "table" and data.data or {}) do
                if i <= 2 and type(a) == "table" and a.id then
                    local attr = type(a.attributes) == "table" and a.attributes or {}
                    candidates[#candidates + 1] = { kind = "kitsu", id = tostring(a.id), name = attr.canonicalTitle, poster = type(attr.posterImage) == "table" and type(attr.posterImage.medium) == "string" and attr.posterImage.medium or nil }
                end
            end
            after()
        end)
    end
    local function from_cinemeta(after)
        get_json(CINEMETA .. url_encode(d.title) .. ".json", nil, function(data, why)
            if not data then mp.msg.warn("Cinemeta: " .. tostring(why)) end
            for i, m in ipairs(data and type(data.metas) == "table" and data.metas or {}) do
                if i <= 2 and type(m) == "table" and type(m.id) == "string" then
                    candidates[#candidates + 1] = { kind = "imdb", id = m.id, season = d.season or 1, name = m.name }
                end
            end
            after()
        end)
    end
    -- "S02E05" names are usually listed by season (Cinemeta); "Show - 05" names by anime entry (Kitsu).
    local first, second = from_kitsu, from_cinemeta
    if d.season then first, second = from_cinemeta, from_kitsu end
    first(function() second(function() check(1) end) end)
end

-- Finds streams for the episode before / after; calls done(list) with the best first, or done(nil).
local function online_neighbour(info, step, done)
    local sr = info.series
    if not sr then
        done(nil)
        return
    end
    local slot = step > 0 and "after" or "before"
    if sr[slot] ~= nil then
        done(sr[slot] or nil)
        return
    end
    local ep = sr.ep + step
    if ep < 1 then
        sr[slot] = false
        done(nil)
        return
    end
    local function try(vid, otherwise)
        get_json(streams_url(info, vid), nil, function(data, why)
            if not data then mp.msg.warn("Torrentio: " .. tostring(why)) end
            local list = data and rank(data.streams, sr.want) or {}
            if #list > 0 then
                sr[slot] = list
                done(list)
            elseif otherwise then
                otherwise()
            else
                sr[slot] = false
                done(nil)
            end
        end)
    end
    if sr.kind == "kitsu" then
        try(video_id(sr, nil, ep))
    elseif step > 0 then
        try(video_id(sr, sr.season, ep), function() try(video_id(sr, sr.season + 1, 1)) end)
    else
        try(video_id(sr, sr.season, ep))
    end
end

-- Finds the episode before / after by whichever way works; done(url, name) or done(nil, why).
-- In a season pack the neighbour is right there. It is used unless the pack is below 4K and
-- a sharper release of that episode is ready.
local function neighbour(info, step, done)
    ensure(info, function()
        local file = info.before
        if step > 0 then file = info.after end
        local now = file and info == current and playing_res() or nil
        local function from_pack()
            done(build_url(info, file), file.name)
        end
        if file and (not now or now >= 2160) then
            from_pack()
            return
        end
        identify(info, function()
            if not info.series then
                if file then from_pack() else done(nil, "series") end
                return
            end
            online_neighbour(info, step, function(list)
                if file and not (list and list[1].res > now) then
                    from_pack()
                elseif list then
                    done(list[1].url, list[1].name, list)
                else
                    done(nil, "none")
                end
            end)
        end)
    end)
end

-- Remembers the other candidates of an address we are about to play.
local function remember_choice(url, list, auto)
    if not list then return end
    choices[url] = { list = list, index = 1, origin = mp.get_property("path"), auto = auto,
        subs = mp.get_property_number("sid") ~= nil }
end

local function unqueue()
    if not queued then return end
    local list = mp.get_property_native("playlist") or {}
    for i = #list, 1, -1 do
        if list[i].filename == queued and not list[i].current then
            mp.commandv("playlist-remove", tostring(i - 1))
        end
    end
    queued = nil
end

-- Puts the next episode after the playing one, so it starts by itself at the end.
local function queue_next(info, gen)
    unqueue()
    if not autoplay then return end
    neighbour(info, 1, function(url, _, list)
        if gen ~= generation or not autoplay or not url then return end
        unqueue()
        remember_choice(url, list, true)
        local list = mp.get_property_native("playlist") or {}
        for i, item in ipairs(list) do
            if item.current and list[i + 1] and list[i + 1].filename == url then
                queued = url
                return
            end
        end
        mp.commandv("loadfile", url, "append")
        queued = url
    end)
end

local function go(step)
    local info = current
    if not info then
        mp.osd_message("Previous / next episode only works for TorBox videos opened from Stremio", 4)
        return
    end
    local gen = generation
    neighbour(info, step, function(url, name, list)
        if gen ~= generation then return end
        if not url then
            if name == "series" then
                mp.osd_message("Could not work out which series this is - pick the episode in Stremio", 5)
            else
                mp.osd_message(step > 0
                    and "No next episode ready on TorBox - pick it in Stremio"
                    or "No previous episode ready on TorBox - pick it in Stremio", 5)
            end
            return
        end
        remember_choice(url, list, false)
        mp.commandv("loadfile", url, "replace")
    end)
end

-- "Previous" first goes back to the start of what is playing; pressed again within a few
-- seconds (or pressed in the first seconds of an episode), it goes to the episode before.
local AGAIN = 4              -- seconds in which a second press means "the episode before"
local last_back = -100
local function back()
    local pos = mp.get_property_number("time-pos")
    local t = mp.get_time()
    if t - last_back <= AGAIN or not pos or pos < 3 then
        last_back = -100
        go(-1)
        return
    end
    last_back = t
    mp.commandv("seek", "0", "absolute")
end

mp.add_key_binding(nil, "next", function() go(1) end)
mp.add_key_binding(nil, "prev", back)
mp.add_key_binding("Alt+PGDWN", "next-key", function() go(1) end)
mp.add_key_binding("Alt+PGUP", "prev-key", back)

mp.add_key_binding("Alt+A", "autoplay", function()
    autoplay = not autoplay
    save_state()
    if current then queue_next(current, generation) end
    mp.osd_message("Autoplay next episode: " .. (autoplay and "on" or "off"), 2.5)
end)

-- ===== Episode list =====
-- Control bar button "Episodes": lists the episodes of the series that is playing.
-- Pick one and it is looked up and played the same way as previous / next episode.

local META = "https://v3-cinemeta.strem.io/meta/series/"
local KITSU_ANIME = "https://kitsu.io/api/edge/anime/"

-- Episodes that came out after the catalogue was last brought up to date are asked from the
-- Atrium home server, which can ask TMDB. When Atrium is not open, or knows no more, the list
-- stays as the catalogue gave it. done() is always called.
local HOME_AFTER = "http://localhost:18731/api/tmdb/after"
local function add_recent(id, meta, done)
    local season, last, day = 0, 0, ""
    for _, v in ipairs(meta.videos) do
        local s = type(v) == "table" and tonumber(v.season)
        if s and tonumber(v.episode) and s > season then season = s end
    end
    for _, v in ipairs(meta.videos) do
        if type(v) == "table" and tonumber(v.season) == season and tonumber(v.episode) then
            if tonumber(v.episode) > last then last = tonumber(v.episode) end
            local d = type(v.released) == "string" and v.released:sub(1, 10) or ""
            if d > day then day = d end
        end
    end
    if season < 1 or type(id) ~= "string" or not id:match("^tt%d+$") then
        done()
        return
    end
    mp.command_native_async({
        name = "subprocess",
        playback_only = false,
        capture_stdout = true,
        capture_stderr = true,
        args = { "curl", "-s", "-m", "6", "-H", "X-Home-Player: 1",
            HOME_AFTER .. "?id=" .. id .. "&s=" .. season .. "&e=" .. last .. "&d=" .. day },
    }, function(ok, res)
        local data = ok and res and res.status == 0 and utils.parse_json(res.stdout or "") or nil
        if type(data) == "table" and type(data.videos) == "table" then
            for _, v in ipairs(data.videos) do
                if type(v) == "table" and tonumber(v.season) and tonumber(v.episode) then
                    meta.videos[#meta.videos + 1] = v
                end
            end
        end
        done()
    end)
end

local function open_menu(title, items)
    mp.osd_message(" ", 0.1)
    mp.commandv("script-message-to", "uosc", "open-menu",
        utils.format_json({ type = "episodes", title = title, items = items }))
end

-- Plays a chosen episode of the recognised series (season is nil for anime entries).
-- pack_file: the same episode in the season pack that is playing, if it is in there; it is
-- used unless a sharper release is ready.
local function pick_online(season, ep, pack_file)
    local info = current
    if not info or not ep then return end
    local gen = generation
    local now = playing_res()
    local function from_pack()
        mp.commandv("loadfile", build_url(info, pack_file), "replace")
    end
    identify(info, function()
        local sr = info.series
        if gen ~= generation then return end
        if not sr then
            if pack_file then from_pack() return end
            mp.osd_message("Could not work out which series this is - pick the episode in Stremio", 5)
            return
        end
        get_json(streams_url(info, video_id(sr, season or sr.season, ep)), nil, function(data, why)
            if gen ~= generation then return end
            if not data then mp.msg.warn("Torrentio: " .. tostring(why)) end
            local list = data and rank(data.streams, sr.want) or {}
            if pack_file and (#list == 0 or not now or list[1].res <= now) then from_pack() return end
            if #list == 0 then
                mp.osd_message("Episode " .. ep .. " is not ready on TorBox - pick it in Stremio", 5)
                return
            end
            remember_choice(list[1].url, list, false)
            mp.commandv("loadfile", list[1].url, "replace")
        end)
    end)
end

local function show_list()
    local info = current
    if not info then
        mp.osd_message("The episode list only works for TorBox videos opened from Stremio", 4)
        return
    end
    mp.osd_message("Loading the episode list...", 30)
    local gen = generation
    ensure(info, function()
        if gen ~= generation then return end
        -- A season pack: list the files of the download.
        if info.list and #info.list > 1 then
            local items = {}
            for i, f in ipairs(info.list) do
                items[#items + 1] = { title = f.name, active = i == info.pos,
                    value = { "script-message-to", "episodes", "pick-file", tostring(i) } }
            end
            open_menu("Episodes", items)
            return
        end
        identify(info, function()
            if gen ~= generation then return end
            local sr = info.series
            if not sr then
                mp.osd_message("Could not work out which series this is - pick the episode in Stremio", 5)
                return
            end
            if sr.kind == "kitsu" then
                get_json(KITSU_ANIME .. sr.id, nil, function(data)
                    if gen ~= generation then return end
                    local attr = data and type(data.data) == "table"
                        and type(data.data.attributes) == "table" and data.data.attributes or {}
                    local count = math.max(tonumber(attr.episodeCount) or (sr.ep + 24), sr.ep)
                    local items = {}
                    for n = 1, count do
                        items[#items + 1] = { title = "Episode " .. n, active = n == sr.ep,
                            value = { "script-message-to", "episodes", "pick", "-", tostring(n) } }
                    end
                    open_menu(type(sr.name) == "string" and sr.name or "Episodes", items)
                end)
                return
            end
            get_json(META .. sr.id .. ".json", nil, function(data, why)
                if gen ~= generation then return end
                local meta = data and type(data.meta) == "table" and data.meta or nil
                if not meta or type(meta.videos) ~= "table" then
                    mp.msg.warn("Cinemeta: " .. tostring(why or "no episode list"))
                    mp.osd_message("Could not load the episode list", 4)
                    return
                end
                add_recent(sr.id, meta, function()
                if gen ~= generation then return end
                local today = os.date("!%Y-%m-%dT%H:%M:%S")
                local seasons, order = {}, {}
                for _, v in ipairs(meta.videos) do
                    local s, e = type(v) == "table" and tonumber(v.season), type(v) == "table" and tonumber(v.episode)
                    local out = type(v) == "table" and type(v.released) == "string" and v.released <= today
                    if s and e and s >= 1 and out then
                        if not seasons[s] then
                            seasons[s] = {}
                            order[#order + 1] = s
                        end
                        local name = type(v.name) == "string" and v.name or (type(v.title) == "string" and v.title or "")
                        seasons[s][#seasons[s] + 1] = { n = e, title = e .. ". " .. name,
                            active = s == sr.season and e == sr.ep,
                            value = { "script-message-to", "episodes", "pick", tostring(s), tostring(e) } }
                    end
                end
                table.sort(order)
                local items = {}
                for _, s in ipairs(order) do
                    table.sort(seasons[s], function(a, b) return a.n < b.n end)
                    for _, item in ipairs(seasons[s]) do item.n = nil end
                    if s == sr.season then
                        for _, item in ipairs(seasons[s]) do items[#items + 1] = item end
                    end
                end
                for _, s in ipairs(order) do
                    if s ~= sr.season then
                        items[#items + 1] = { title = "Season " .. s, items = seasons[s] }
                    end
                end
                if #items == 0 then
                    mp.osd_message("Could not load the episode list", 4)
                    return
                end
                local name = type(meta.name) == "string" and meta.name or "Episodes"
                open_menu(name .. " - Season " .. tostring(sr.season), items)
                end)
            end)
        end)
    end)
end

mp.add_key_binding(nil, "list", show_list)
mp.register_script_message("pick", function(season, ep)
    pick_online(tonumber(season), tonumber(ep))
end)
mp.register_script_message("pick-file", function(n)
    local info = current
    local file = info and info.list and info.list[tonumber(n) or 0]
    if file then mp.commandv("loadfile", build_url(info, file), "replace") end
end)

-- ===== Settings menu (gear button) =====
-- A small menu above the gear: subtitles, audio track and picture quality.
-- "Quality" lists the other releases of the same episode that TorBox can play at once.

local LANGS = { eng = "English", en = "English", fre = "French", fra = "French", fr = "French",
    spa = "Spanish", es = "Spanish", ita = "Italian", it = "Italian", ger = "German", deu = "German",
    de = "German", jpn = "Japanese", ja = "Japanese", por = "Portuguese", pt = "Portuguese",
    kor = "Korean", ko = "Korean", ara = "Arabic", ar = "Arabic", rus = "Russian", ru = "Russian",
    chi = "Chinese", zho = "Chinese", zh = "Chinese", dut = "Dutch", nld = "Dutch", und = "Unknown" }

local function open_settings(items)
    mp.osd_message(" ", 0.1)
    mp.commandv("script-message-to", "uosc", "open-menu",
        utils.format_json({ type = "player-settings", search_style = "disabled", items = items }))
end

local function track_items(kind, prop)
    local items, current = {}, nil
    for _, t in ipairs(mp.get_property_native("track-list") or {}) do
        if t.type == kind then
            local lang = type(t.lang) == "string" and t.lang or ""
            local name = LANGS[lang:lower()] or (lang ~= "" and lang:upper()) or ("Track " .. tostring(t.id))
            local hint = type(t.title) == "string" and t.title or nil
            if kind == "audio" then
                local ch = tonumber(t["demux-channel-count"])
                local layout = ch and (ch >= 8 and "7.1" or ch >= 6 and "5.1" or ch == 2 and "Stereo" or ch == 1 and "Mono" or nil)
                if layout then hint = hint and (hint .. " - " .. layout) or layout end
            end
            if t.forced then hint = hint and (hint .. " - forced") or "forced" end
            if hint and #hint > 34 then hint = hint:sub(1, 32) .. ".." end
            if t.selected then current = name end
            items[#items + 1] = { title = name, hint = hint, active = t.selected == true,
                value = { "set", prop, tostring(t.id) } }
        end
    end
    if kind == "sub" then
        table.insert(items, 1, { title = "Off", active = current == nil, value = { "set", prop, "no" } })
    end
    return items, current
end

local function resolution_of(st)
    local text = (st.name .. " " .. stream_file(st)):lower()
    if text:find("4k", 1, true) or text:find("2160p", 1, true) then return 2160 end
    return tonumber(text:match("(%d%d%d%d?)p")) or 0
end

-- Finds the other releases of the playing episode; done(list) or done(nil).
local function qualities(info, done)
    if info.qualities ~= nil then
        done(info.qualities or nil)
        return
    end
    identify(info, function()
        local sr = info.series
        if not sr then
            info.qualities = false
            done(nil)
            return
        end
        get_json(streams_url(info, video_id(sr, sr.season, sr.ep)), nil, function(data, why)
            if not data then
                mp.msg.warn("Torrentio: " .. tostring(why))
                done(nil)
                return
            end
            local list, seen = {}, {}
            for i, st in ipairs(type(data.streams) == "table" and data.streams or {}) do
                if type(st) == "table" and type(st.url) == "string" and type(st.name) == "string"
                    and st.name:find("[TB+]", 1, true) then
                    local hash = (st.url:match("/resolve/torbox/[^/]+/(%x+)/") or ""):lower()
                    if hash ~= "" and not seen[hash] and not unplayable[hash] then
                        seen[hash] = true
                        local size, dub = stream_facts(st)
                        local res = resolution_of(st)
                        local label = res >= 2160 and "4K" or (res > 0 and (res .. "p") or "Other")
                        local file = stream_file(st)
                        local group = file:match("%-(%w+)%.%w+$") or file:match("^%s*%[([^%]]+)%]") or ""
                        local hint = (size and string.format("%.1f GB", size) or "")
                        if group ~= "" then hint = hint .. (hint ~= "" and " - " or "") .. group end
                        if dub then hint = hint .. " - dubbed" end
                        list[#list + 1] = { url = st.url, res = res, size = size or 0, order = i,
                            title = label, hint = hint, active = hash == info.hash }
                    end
                end
            end
            table.sort(list, function(a, b)
                if a.res ~= b.res then return a.res > b.res end
                if a.size ~= b.size then return a.size > b.size end
                return a.order < b.order
            end)
            while #list > 12 do list[#list] = nil end
            info.qualities = list
            done(list)
        end)
    end)
end

local function quality_items(list)
    local items = {}
    for i, q in ipairs(list) do
        items[#items + 1] = { title = q.title, hint = q.hint, active = q.active,
            value = { "script-message-to", "episodes", "pick-quality", tostring(i) } }
    end
    return items
end

local function show_settings()
    local info = current
    local subs, sub_now = track_items("sub", "sid")
    local audio, audio_now = track_items("audio", "aid")
    local items = {
        { title = "Subtitles", hint = sub_now or "Off", items = subs },
        { title = "Audio", hint = audio_now, items = audio },
    }
    if info then
        local now = nil
        if info.qualities then
            for _, q in ipairs(info.qualities) do if q.active then now = q.title end end
        end
        if info.qualities and #info.qualities > 0 then
            items[#items + 1] = { title = "Quality", hint = now, items = quality_items(info.qualities) }
        elseif info.qualities == nil then
            items[#items + 1] = { title = "Quality", hint = "...",
                value = { "script-message-to", "episodes", "quality" } }
            qualities(info, function() end)
        end
    end
    open_settings(items)
end

mp.add_key_binding(nil, "settings", show_settings)
mp.register_script_message("quality", function()
    local info = current
    if not info then return end
    mp.osd_message("Looking for other qualities...", 30)
    local gen = generation
    qualities(info, function(list)
        if gen ~= generation then return end
        if not list or #list == 0 then
            mp.osd_message("No other quality ready on TorBox - pick one in Stremio", 4)
            return
        end
        open_settings(quality_items(list))
    end)
end)
mp.register_script_message("pick-quality", function(n)
    local info = current
    local q = info and info.qualities and info.qualities[tonumber(n) or 0]
    if not q or q.active then return end
    mp.osd_message("Switching to " .. q.title .. "...", 4)
    mp.commandv("loadfile", q.url, "replace")
end)

-- ===== Settings menu: one level at a time =====
-- The gear menu stays above the gear: picking Subtitles, Audio or Quality swaps the list
-- in place (with a Back row) instead of opening a side menu. The "settings" button now
-- runs this; show_settings and the "quality" message just above are no longer used.

local function settings_open()
    return mp.get_property_native("user-data/uosc/menu/type") == "player-settings"
end

local function settings_show(items, fresh)
    mp.osd_message(" ", 0.1)
    local data = utils.format_json({ type = "player-settings", search_style = "disabled", items = items })
    if fresh or not settings_open() then
        mp.commandv("script-message-to", "uosc", "open-menu", data)
    else
        mp.commandv("script-message-to", "uosc", "update-menu", data)
    end
end

local function page_link(title, hint, page, icon)
    return { title = title, hint = (hint and (hint .. "  ") or "") .. "\226\128\186", icon = icon, keep_open = true,
        value = { "script-message-to", "episodes", "settings-page", page } }
end

local function with_back(items)
    table.insert(items, 1, { title = "Back", icon = "arrow_back", keep_open = true,
        value = { "script-message-to", "episodes", "settings-page", "root" } })
    return items
end

local function note_row(text)
    return { title = text, selectable = false, muted = true, value = "ignore" }
end

local function settings_root(fresh)
    local info = current
    local _, sub_now = track_items("sub", "sid")
    local _, audio_now = track_items("audio", "aid")
    local items = { page_link("Subtitles", sub_now or "Off", "sub", "subtitles"),
        page_link("Audio", audio_now, "audio", "graphic_eq") }
    if info and info.qualities ~= false then
        local now = nil
        for _, q in ipairs(info.qualities or {}) do if q.active then now = q.title end end
        if not now then
            local p = mp.get_property_native("video-dec-params") or {}
            local w, h = p.w or 0, p.h or 0
            now = (w >= 3200 or h >= 1800) and "4K" or (w >= 1800 and "1080p") or (w >= 1200 and "720p") or nil
        end
        table.insert(items, 1, page_link("Quality", now, "quality", "tune"))
        if info.qualities == nil then qualities(info, function() end) end
    end
    settings_show(items, fresh)
end

local function settings_page(page)
    if page == "sub" then
        settings_show(with_back((track_items("sub", "sid"))))
    elseif page == "audio" then
        settings_show(with_back((track_items("audio", "aid"))))
    elseif page == "quality" then
        local info = current
        if not info then return end
        local gen = generation
        if info.qualities == nil then settings_show(with_back({ note_row("Looking...") })) end
        qualities(info, function(list)
            if gen ~= generation or not settings_open() then return end
            if not list or #list == 0 then
                settings_show(with_back({ note_row("Nothing else ready on TorBox") }))
            else
                settings_show(with_back(quality_items(list)))
            end
        end)
    else
        settings_root(false)
    end
end

mp.add_key_binding(nil, "settings", function() settings_root(true) end)
mp.register_script_message("settings-page", settings_page)

-- ===== Episode panel =====
-- The "Episodes" button opens a panel above the control bar: one row per episode of the
-- season, and the selected episode opened up with its picture and summary (from Cinemeta,
-- the catalogue Stremio uses). Click a row to open it up, click it again to play it.
-- Mouse wheel scrolls, Esc or a click outside closes. Series that cannot be matched fall
-- back to the plain list above.
-- Other seasons: "Season 2" at the top is a drop-down list; a click on it lists the seasons,
-- and a click on one shows its episodes.

local assdraw = require 'mp.assdraw'
local panel = nil            -- { items, sel, top, hover, title, box, rows }
local panel_overlay = mp.create_osd_overlay("ass-events")
local panel_drawn = ""
local meta_cache = {}        -- series id -> Cinemeta answer
local thumbs = {}            -- picture key -> file path, "loading" or false
local thumb_queue, thumb_busy = {}, false
local thumb_shown = nil
local THUMB_ID = 50
local mpv_exe = mp.command_native({ "expand-path", "~~exe_dir/mpv.exe" })
local thumb_dir = os.getenv("TEMP") or mp.command_native({ "expand-path", "~~exe_dir/mpv" })
local PANEL_KEYS = { "MBTN_LEFT", "MBTN_LEFT_DBL", "WHEEL_UP", "WHEEL_DOWN", "ESC", "UP", "DOWN", "ENTER", "KP_ENTER" }
local render_panel

local function clean(t)
    t = tostring(t or ""):gsub("\\", "/"):gsub("[{}]", ""):gsub("%s+", " ")
    return t
end

-- Breaks a text into lines of about per_line letters; "..." when it does not fit.
local function wrap(text, per_line, max_lines)
    local lines, line, cut = {}, "", false
    for word in text:gmatch("%S+") do
        if line ~= "" and #line + #word + 1 > per_line then
            if #lines + 1 == max_lines then
                cut = true
                break
            end
            lines[#lines + 1] = line
            line = word
        else
            line = line == "" and word or (line .. " " .. word)
        end
    end
    if cut then line = line:sub(1, math.max(1, per_line - 3)) .. "..." end
    if line ~= "" then lines[#lines + 1] = line end
    return table.concat(lines, "\\N")
end

local function file_size(path)
    local f = io.open(path, "rb")
    if not f then return 0 end
    local size = f:seek("end") or 0
    f:close()
    return size
end

-- Pictures are fetched and resized one at a time by a second, silent mpv.
local function next_thumb()
    if thumb_busy then return end
    local job = table.remove(thumb_queue, 1)
    if not job then return end
    thumb_busy = true
    mp.command_native_async({
        name = "subprocess", playback_only = false, capture_stdout = true, capture_stderr = true,
        args = { mpv_exe, job.url, "--no-config", "--msg-level=all=no", "--load-scripts=no", "--ytdl=no",
            "--aid=no", "--sid=no", "--frames=1",
            "--vf=scale=" .. job.w .. ":" .. job.h .. ",format=bgra",
            "--ovc=rawvideo", "--of=image2", "--ofopts=update=1", "--o=" .. job.path },
    }, function()
        thumb_busy = false
        thumbs[job.key] = file_size(job.path) == job.w * job.h * 4 and job.path or false
        if panel then render_panel() end
        next_thumb()
    end)
end

local function picture(item, w, h)
    if not item.thumb then return nil end
    local key = item.key .. "-" .. w
    local have = thumbs[key]
    if have == nil then
        local path = thumb_dir .. "/mpv-episode-" .. key:gsub("[^%w%-]", "_") .. ".bgra"
        if file_size(path) == w * h * 4 then
            thumbs[key] = path
            return path
        end
        thumbs[key] = "loading"
        table.insert(thumb_queue, 1, { key = key, url = item.thumb, w = w, h = h, path = path })
        next_thumb()
        return nil
    end
    if have and have ~= "loading" then return have end
    return nil
end

local function hide_picture()
    if thumb_shown then
        mp.commandv("overlay-remove", tostring(THUMB_ID))
        thumb_shown = nil
    end
end

local closed_height = nil    -- how tall the panel was when it last closed (kept when changing season)
local quiet_until = 0        -- a double-click that chose a season does not also act on what comes up under it
local function panel_close()
    if not panel then return end
    closed_height = panel.box and (panel.box[4] - panel.box[2]) or nil
    panel = nil
    panel_drawn = ""
    panel_overlay:remove()
    hide_picture()
    for _, key in ipairs(PANEL_KEYS) do mp.remove_key_binding("panel-" .. key) end
end

local function panel_pick(i)
    if not panel or not panel.items[i] then return end
    if i ~= panel.sel then
        panel.sel = i
        render_panel()
        return
    end
    local action = panel.items[i].action
    panel_close()
    action()
end

local function row_under_mouse()
    local m = mp.get_property_native("mouse-pos")
    if not panel or not panel.box or type(m) ~= "table" then return nil, false end
    local b = panel.box
    if m.x < b[1] or m.x > b[3] or m.y < b[2] or m.y > b[4] then return nil, false end
    for _, r in ipairs(panel.rows or {}) do
        if m.y >= r.y0 and m.y < r.y1 then return r.i, true end
    end
    return nil, true
end

render_panel = function()
    if not panel then return end
    local w, h = mp.get_osd_size()
    if not w or not h or w == 0 or h == 0 then return end
    local s = h / 1080
    local function px(n) return math.floor(n * s + 0.5) end
    local pw, row, head, pad = px(580), px(54), px(62), px(22)
    local tw = px(224)
    local th = math.floor(tw * 9 / 16)
    local open = row + th + px(22)
    local x1 = w - px(40)
    if mp.get_property_native("user-data/player/panel-left") then x1 = px(40) + pw end
    local x0, y1 = x1 - pw, h - px(150)
    local room = math.floor(h * 0.74) - head - pad

    -- Which rows fit, keeping the opened one in view.
    local n = #panel.items
    panel.top = math.max(1, math.min(panel.top, n))
    if panel.sel < panel.top then panel.top = panel.sel end
    local last
    while true do
        local used = 0
        last = panel.top - 1
        for i = panel.top, n do
            local need = i == panel.sel and open or row
            if used + need > room then break end
            used, last = used + need, i
        end
        if panel.sel <= last or panel.top >= panel.sel then break end
        panel.top = panel.top + 1
    end
    local height = head + pad
    for i = panel.top, last do height = height + (i == panel.sel and open or row) end
    -- changing season, the panel does not shrink: its top (and the list of seasons) stays put
    local se = panel.seasons
    local drow = px(46)
    local floor_h = panel.min_h or 0
    if panel.drop and se then floor_h = math.max(floor_h, head + pad + math.min(#se.list, 10) * drow + px(20)) end
    if floor_h > height then height = math.min(floor_h, head + pad + room) end
    local y0 = y1 - height
    panel.box = { x0, y0, x1, y1 }
    panel.rows = {}

    local a = assdraw.ass_new()
    local function shape(ax, ay, bx, by, radius, color, alpha)
        a:new_event()
        a:pos(0, 0)
        a:append(string.format("{\\an7\\blur0\\bord0\\shad0\\1c&H%s&\\1a&H%s&}", color, alpha))
        a:draw_start()
        a:round_rect_cw(ax, ay, bx, by, radius)
        a:draw_stop()
    end
    local function text(x, y, an, size, color, alpha, bold, str)
        a:new_event()
        a:pos(x, y)
        a:append(string.format("{\\an%d\\blur0\\bord0\\shad0\\q2\\b%d\\fs%d\\1c&H%s&\\1a&H%s&}%s",
            an, bold and 1 or 0, size, color, alpha, str))
    end

    shape(x0, y0, x1, y1, px(14), "000000", "48")
    -- with more than one season, the title is a drop-down button: a soft box and a small arrow
    panel.head = nil
    if se then
        local wide = math.floor(#clean(panel.title) * px(27) * 0.56)
        local bx0, bx1, cy = x0 + pad - px(12), x0 + pad + wide + px(44), y0 + head / 2
        shape(bx0, cy - px(22), bx1, cy + px(22), px(8), "FFFFFF", (panel.drop or panel.head_hover) and "CC" or "E6")
        local cx = bx1 - px(22)
        a:new_event()
        a:pos(0, 0)
        a:append("{\\an7\\blur0\\bord0\\shad0\\1c&HFFFFFF&\\1a&H10&}")
        a:draw_start()
        if panel.drop then
            a:move_to(cx - px(7), cy + px(4))
            a:line_to(cx + px(7), cy + px(4))
            a:line_to(cx, cy - px(4))
        else
            a:move_to(cx - px(7), cy - px(4))
            a:line_to(cx + px(7), cy - px(4))
            a:line_to(cx, cy + px(4))
        end
        a:draw_stop()
        panel.head = { bx0, cy - px(22), bx1, cy + px(22) }
    end
    text(x0 + pad, y0 + head / 2, 4, px(27), "FFFFFF", "00", true, clean(panel.title))
    if n > last - panel.top + 1 then
        text(x1 - pad, y0 + head / 2, 6, px(18), "FFFFFF", "70", false, panel.top .. "-" .. last .. " / " .. n)
    end

    local picture_at = nil
    local y = y0 + head
    for i = panel.top, last do
        local item = panel.items[i]
        local tall = i == panel.sel and open or row
        panel.rows[#panel.rows + 1] = { i = i, y0 = y, y1 = y + tall }
        if i == panel.sel then
            shape(x0 + px(8), y, x1 - px(8), y + tall, px(8), "FFFFFF", "E4")
        elseif i == panel.hover then
            shape(x0 + px(8), y, x1 - px(8), y + tall, px(8), "FFFFFF", "F0")
        end
        if item.current then shape(x0 + px(8), y + px(14), x0 + px(12), y + row - px(14), px(2), "1409E5", "00") end
        local dim = (i == panel.sel or i == panel.hover or item.current) and "00" or "40"
        text(x0 + pad, y + row / 2, 4, px(23), "FFFFFF", "60", false, tostring(item.ep))
        local title = clean(item.title)
        local fits = math.floor((pw - pad * 2 - px(48)) / (px(23) * 0.5))
        if #title > fits then title = title:sub(1, fits - 3) .. "..." end
        text(x0 + pad + px(48), y + row / 2, 4, px(23), "FFFFFF", dim, item.current or i == panel.sel, title)
        if i == panel.sel then
            local py = y + row
            local file = picture(item, tw, th)
            if file and not panel.drop then       -- (a picture would lie over the list of seasons)
                picture_at = { x0 + pad, py, file }
            else
                shape(x0 + pad, py, x0 + pad + tw, py + th, px(6), "303030", "00")
            end
            local tx = x0 + pad + tw + px(18)
            local per_line = math.floor((x1 - pad - tx) / (px(18) * 0.5))
            local lines = math.max(1, math.floor(th / (px(18) * 1.3)))
            text(tx, py - px(2), 7, px(18), "FFFFFF", "40", false, wrap(clean(item.text), per_line, lines))
        end
        y = y + tall
    end

    -- the list of seasons, over the rows
    panel.drop_rows, panel.drop_box = nil, nil
    if panel.drop and se then
        local count = #se.list
        local fit = math.max(1, math.floor((y1 - pad - (y0 + head)) / drow))
        local show = math.min(count, fit)
        panel.drop_top = math.max(1, math.min(panel.drop_top or 1, count - show + 1))
        local dx0, dy0 = x0 + pad - px(12), y0 + head + px(2)
        local dx1, dy1 = dx0 + px(320), dy0 + show * drow + px(12)
        shape(x0 + px(4), y0 + head, x1 - px(4), y1 - px(4), px(10), "000000", "58")   -- the episodes step back
        shape(dx0 - px(1), dy0 - px(1), dx1 + px(1), dy1 + px(1), px(9), "5A5A5A", "00")
        shape(dx0, dy0, dx1, dy1, px(8), "1A1A1A", "00")
        panel.drop_box = { dx0, dy0, dx1, dy1 }
        panel.drop_rows = {}
        for k = 0, show - 1 do
            local idx = panel.drop_top + k
            local s = se.list[idx]
            local ry = dy0 + px(6) + k * drow
            panel.drop_rows[#panel.drop_rows + 1] = { i = idx, y0 = ry, y1 = ry + drow }
            if idx == panel.drop_hover then shape(dx0 + px(6), ry, dx1 - px(6), ry + drow, px(6), "FFFFFF", "DC") end
            if s == se.playing then shape(dx0 + px(8), ry + px(12), dx0 + px(12), ry + drow - px(12), px(2), "1409E5", "00") end
            local lit = s == se.at or idx == panel.drop_hover
            text(dx0 + px(24), ry + drow / 2, 4, px(22), "FFFFFF", lit and "00" or "30", s == se.at, "Season " .. s)
            local c = se.count[s] or 0
            text(dx1 - px(20), ry + drow / 2, 6, px(17), "FFFFFF", "70", false, c .. (c == 1 and " episode" or " episodes"))
        end
        if show < count then      -- a thin bar on the right says where in the list this is
            local track = show * drow
            local by0 = dy0 + px(6) + math.floor(track * (panel.drop_top - 1) / count)
            shape(dx1 - px(6), by0, dx1 - px(3), by0 + math.floor(track * show / count), px(2), "FFFFFF", "90")
        end
    end

    local key = w .. "x" .. h .. a.text
    if key ~= panel_drawn then
        panel_drawn = key
        panel_overlay.res_x, panel_overlay.res_y = w, h
        panel_overlay.data = a.text
        panel_overlay:update()
    end
    if picture_at then
        local now = picture_at[3] .. picture_at[1] .. "," .. picture_at[2]
        if now ~= thumb_shown then
            mp.commandv("overlay-add", tostring(THUMB_ID), tostring(picture_at[1]), tostring(picture_at[2]),
                picture_at[3], "0", "bgra", tostring(tw), tostring(th), tostring(tw * 4))
            thumb_shown = now
        end
    else
        hide_picture()
    end
end

-- extra (optional): min_h = do not come up smaller than this; seasons = { list = the seasons in
-- order, count = episodes in each, at = the one shown, playing = the one being watched,
-- pick = function(season) } for the drop-down list under the title.
local function panel_open(items, title, extra)
    extra = extra or {}
    local sel = 1
    for i, item in ipairs(items) do if item.current then sel = i end end
    panel = { items = items, sel = sel, top = 1, title = title, min_h = extra.min_h, seasons = extra.seasons }
    local function inside(b, m)
        return b and type(m) == "table" and m.x and m.x >= b[1] and m.x <= b[3] and m.y >= b[2] and m.y <= b[4]
    end
    local function drop_set(on)
        if not panel or not panel.seasons then return end
        panel.drop = on
        if on then
            local at = 1
            for i, s in ipairs(panel.seasons.list) do if s == panel.seasons.at then at = i end end
            panel.drop_hover = at
            panel.drop_top = math.max(1, at - 4)
        end
        render_panel()
    end
    local function drop_pick(i)
        local se = panel and panel.seasons
        local s = se and se.list[i]
        if not s then return end
        if s == se.at then
            drop_set(false)
            return
        end
        local go = se.pick
        quiet_until = mp.get_time() + 0.4
        panel_close()
        go(s)
    end
    local function move(step)
        if not panel then return end
        if panel.drop then
            local count = #panel.seasons.list
            panel.drop_hover = math.max(1, math.min(count, (panel.drop_hover or 1) + step))
            local shown = panel.drop_rows and #panel.drop_rows or 1
            if panel.drop_hover < (panel.drop_top or 1) then panel.drop_top = panel.drop_hover end
            if panel.drop_hover > (panel.drop_top or 1) + shown - 1 then panel.drop_top = panel.drop_hover - shown + 1 end
            render_panel()
            return
        end
        panel.sel = math.max(1, math.min(#panel.items, panel.sel + step))
        render_panel()
    end
    local function scroll(step)
        if not panel then return end
        if panel.drop then
            panel.drop_top = math.max(1, (panel.drop_top or 1) + step)
            render_panel()
            return
        end
        panel.top = math.max(1, math.min(#panel.items, panel.top + step))
        if panel.sel < panel.top then panel.sel = panel.top end
        render_panel()
    end
    local function click(double)
        if not panel then return end
        if double and mp.get_time() < quiet_until then return end
        local m = mp.get_property_native("mouse-pos")
        if panel.drop then
            if inside(panel.drop_box, m) then
                for _, r in ipairs(panel.drop_rows or {}) do
                    if m.y >= r.y0 and m.y < r.y1 then
                        drop_pick(r.i)
                        return
                    end
                end
            elseif not double then
                drop_set(false)          -- a click anywhere else only puts the list away
            end
            return
        end
        if inside(panel.head, m) then
            if not double then drop_set(true) end
            return
        end
        local i, within = row_under_mouse()
        if not within then
            panel_close()
        elseif i then
            panel_pick(i)
        end
    end
    local function enter()
        if not panel then return end
        if panel.drop then drop_pick(panel.drop_hover or 1) else panel_pick(panel.sel) end
    end
    local actions = {
        MBTN_LEFT = function() click(false) end, MBTN_LEFT_DBL = function() click(true) end,
        WHEEL_UP = function() scroll(-1) end, WHEEL_DOWN = function() scroll(1) end,
        ESC = function() if panel and panel.drop then drop_set(false) else panel_close() end end,
        UP = function() move(-1) end, DOWN = function() move(1) end,
        ENTER = enter, KP_ENTER = enter,
    }
    for _, key in ipairs(PANEL_KEYS) do
        mp.add_forced_key_binding(key, "panel-" .. key, actions[key], { repeatable = key == "UP" or key == "DOWN" })
    end
    mp.osd_message(" ", 0.1)
    render_panel()
end

local function show_panel()
    if panel then
        panel_close()
        return
    end
    local info = current
    if not info then
        mp.osd_message("The episode list only works for TorBox videos opened from Stremio", 4)
        return
    end
    mp.osd_message("Loading the episodes...", 30)
    local gen = generation
    ensure(info, function()
        if gen ~= generation then return end
        identify(info, function()
            if gen ~= generation then return end
            local sr = info.series
            if not sr or sr.kind ~= "imdb" then
                show_list()
                return
            end
            local function build(meta)
                -- In a season pack the files are already there: match them by episode number.
                local files = {}
                if info.list and #info.list > 1 then
                    for i, f in ipairs(info.list) do
                        local d = describe(f.name)
                        if d and d.ep and (d.season == nil or d.season == sr.season) then files[d.ep] = i end
                    end
                end
                local today = os.date("!%Y-%m-%dT%H:%M:%S")
                -- every season that has episodes out, so that the others can be reached from here
                local by, order, count = {}, {}, {}
                for _, v in ipairs(meta.videos) do
                    local s = type(v) == "table" and tonumber(v.season)
                    local e = s and tonumber(v.episode)
                    if s and e and s >= 1 and type(v.released) == "string" and v.released <= today then
                        if not by[s] then
                            by[s] = {}
                            order[#order + 1] = s
                        end
                        by[s][#by[s] + 1] = v
                    end
                end
                table.sort(order)
                for _, s in ipairs(order) do count[s] = #by[s] end
                if not by[sr.season] then
                    show_list()
                    return
                end
                local open_season
                open_season = function(season, keep)
                    local mine = season == sr.season
                    local items = {}
                    for _, v in ipairs(by[season]) do
                        local e = tonumber(v.episode)
                        local index = mine and files[e] or nil
                        items[#items + 1] = {
                            ep = e, key = sr.id .. "-" .. season .. "-" .. e, current = mine and e == sr.ep,
                            title = type(v.name) == "string" and v.name or ("Episode " .. e),
                            text = type(v.overview) == "string" and v.overview
                                or (type(v.description) == "string" and v.description or ""),
                            thumb = type(v.thumbnail) == "string" and v.thumbnail or nil,
                            action = function()
                                local file = index and current == info and info.list and info.list[index] or nil
                                if file and (playing_res() or 2160) >= 2160 then
                                    mp.commandv("loadfile", build_url(info, file), "replace")
                                else
                                    pick_online(season, e, file)
                                end
                            end,
                        }
                    end
                    table.sort(items, function(x, y) return x.ep < y.ep end)
                    panel_open(items, "Season " .. tostring(season), {
                        min_h = keep and closed_height or nil,
                        seasons = #order > 1 and { list = order, count = count, at = season, playing = sr.season,
                            pick = function(s) open_season(s, true) end } or nil,
                    })
                end
                open_season(sr.season)
            end
            if meta_cache[sr.id] then
                build(meta_cache[sr.id])
                return
            end
            get_json(META .. sr.id .. ".json", nil, function(data, why)
                if gen ~= generation then return end
                local meta = data and type(data.meta) == "table" and data.meta or nil
                if not meta or type(meta.videos) ~= "table" then
                    mp.msg.warn("Cinemeta: " .. tostring(why or "no episode list"))
                    show_list()
                    return
                end
                add_recent(sr.id, meta, function()
                    if gen ~= generation then return end
                    meta_cache[sr.id] = meta
                    build(meta)
                end)
            end)
        end)
    end)
end

mp.add_key_binding(nil, "list", show_panel)
mp.observe_property("mouse-pos", "native", function(_, m)
    if not panel then return end
    local function inside(b)
        return b and type(m) == "table" and m.x and m.x >= b[1] and m.x <= b[3] and m.y >= b[2] and m.y <= b[4]
    end
    if panel.drop then
        -- over the list of seasons, the rows behind it do not light up
        local over = panel.drop_hover
        if inside(panel.drop_box) then
            for _, r in ipairs(panel.drop_rows or {}) do
                if m.y >= r.y0 and m.y < r.y1 then over = r.i end
            end
        end
        if over ~= panel.drop_hover or panel.hover then
            panel.drop_hover, panel.hover = over, nil
            render_panel()
        end
        return
    end
    local i = row_under_mouse()
    local head = inside(panel.head) or nil
    if i ~= panel.hover or head ~= panel.head_hover then
        panel.hover, panel.head_hover = i, head
        render_panel()
    end
end)
mp.observe_property("osd-dimensions", "native", function() if panel then render_panel() end end)
mp.register_event("end-file", panel_close)

-- ===== Watched ticks in Stremio =====
-- When an episode is watched to the end, its tick is added to your Stremio account,
-- the way Stremio's own player does it. This only happens when you have put your
-- Stremio sign-in key in the file "stremio-key.txt" next to this script. Before every
-- change, the entry as it was is appended to "stremio-watched-backup.txt".

local STREMIO_API = "https://api.strem.io/api/"
local CINEMETA_META = "https://v3-cinemeta.strem.io/meta/series/"
local key_path = mp.command_native({ "expand-path", "~~exe_dir/mpv/stremio-key.txt" })
local backup_path = mp.command_native({ "expand-path", "~~exe_dir/mpv/stremio-watched-backup.txt" })
local B64 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"
local marked = {}       -- episodes already ticked while the player stays open
local last_pos, last_duration = nil, nil

local function stremio_key()
    local f = io.open(key_path, "r")
    if not f then return nil end
    local k = (f:read("*a") or ""):gsub("[^!-~]", ""):gsub("['\"]", "")
    f:close()
    if k == "" or k:find('["\\]') then return nil end
    return k
end

local function b64_decode(s)
    local out, acc, n = {}, 0, 0
    for i = 1, #s do
        local p = B64:find(s:sub(i, i), 1, true)
        if p then
            acc = acc * 64 + (p - 1)
            n = n + 6
            if n >= 8 then
                n = n - 8
                local d = 2 ^ n
                local byte = math.floor(acc / d)
                out[#out + 1] = byte
                acc = acc - byte * d
            end
        end
    end
    return out
end

local function b64_encode(bytes)
    local out = {}
    for i = 1, #bytes, 3 do
        local a, b, c = bytes[i], bytes[i + 1], bytes[i + 2]
        local v = a * 65536 + (b or 0) * 256 + (c or 0)
        local c1 = math.floor(v / 262144)
        local c2 = math.floor(v / 4096) % 64
        local c3 = math.floor(v / 64) % 64
        local c4 = v % 64
        out[#out + 1] = B64:sub(c1 + 1, c1 + 1) .. B64:sub(c2 + 1, c2 + 1)
            .. (b and B64:sub(c3 + 1, c3 + 1) or "=") .. (c and B64:sub(c4 + 1, c4 + 1) or "=")
    end
    return table.concat(out)
end

-- Unpacks zlib data (the format Stremio packs the ticks with). Returns the bytes, or nil.
local function inflate(data)
    if #data < 6 or data[1] % 16 ~= 8 then return nil end
    local pos, buf, cnt = 3, 0, 0
    local out = {}
    local failed = false
    local function bit()
        if cnt == 0 then
            buf = data[pos]
            if not buf then failed = true buf = 0 end
            pos = pos + 1
            cnt = 8
        end
        local b = buf % 2
        buf = (buf - b) / 2
        cnt = cnt - 1
        return b
    end
    local function bits(n)
        local v, m = 0, 1
        for _ = 1, n do
            v = v + bit() * m
            m = m * 2
        end
        return v
    end
    local function build(lengths, count)
        local h = { counts = {}, symbols = {} }
        for l = 0, 15 do h.counts[l] = 0 end
        for s = 0, count - 1 do h.counts[lengths[s] or 0] = h.counts[lengths[s] or 0] + 1 end
        local offs = { [1] = 0 }
        for l = 1, 14 do offs[l + 1] = offs[l] + h.counts[l] end
        for s = 0, count - 1 do
            local l = lengths[s] or 0
            if l ~= 0 then
                h.symbols[offs[l]] = s
                offs[l] = offs[l] + 1
            end
        end
        return h
    end
    local function decode(h)
        local code, first, index = 0, 0, 0
        for l = 1, 15 do
            code = code + bit()
            local count = h.counts[l]
            if code - count < first then return h.symbols[index + (code - first)] end
            index = index + count
            first = (first + count) * 2
            code = code * 2
        end
        failed = true
        return nil
    end
    local LBASE = { 3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 15, 17, 19, 23, 27, 31, 35, 43, 51, 59, 67, 83, 99, 115, 131, 163, 195, 227, 258 }
    local LEXT = { 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 0 }
    local DBASE = { 1, 2, 3, 4, 5, 7, 9, 13, 17, 25, 33, 49, 65, 97, 129, 193, 257, 385, 513, 769, 1025, 1537, 2049, 3073, 4097, 6145, 8193, 12289, 16385, 24577 }
    local DEXT = { 0, 0, 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12, 13, 13 }
    local function codes(lit, dist)
        while not failed do
            local sym = decode(lit)
            if not sym then return end
            if sym < 256 then
                out[#out + 1] = sym
            elseif sym == 256 then
                return
            else
                sym = sym - 257
                if sym >= 29 then failed = true return end
                local len = LBASE[sym + 1] + bits(LEXT[sym + 1])
                local ds = decode(dist)
                if not ds or ds >= 30 then failed = true return end
                local d = DBASE[ds + 1] + bits(DEXT[ds + 1])
                if d > #out then failed = true return end
                for _ = 1, len do out[#out + 1] = out[#out + 1 - d] end
            end
            if #out > 1000000 then failed = true end
        end
    end
    local ORDER = { 16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15 }
    repeat
        local final = bit()
        local kind = bits(2)
        if kind == 0 then
            buf, cnt = 0, 0
            local len = (data[pos] or 0) + (data[pos + 1] or 0) * 256
            pos = pos + 4
            for _ = 1, len do
                if not data[pos] then failed = true break end
                out[#out + 1] = data[pos]
                pos = pos + 1
            end
        elseif kind == 1 then
            local l = {}
            for s = 0, 143 do l[s] = 8 end
            for s = 144, 255 do l[s] = 9 end
            for s = 256, 279 do l[s] = 7 end
            for s = 280, 287 do l[s] = 8 end
            local d = {}
            for s = 0, 29 do d[s] = 5 end
            codes(build(l, 288), build(d, 30))
        elseif kind == 2 then
            local nlen, ndist, ncode = bits(5) + 257, bits(5) + 1, bits(4) + 4
            local cl = {}
            for i = 1, ncode do cl[ORDER[i]] = bits(3) end
            local lencode = build(cl, 19)
            local l, i = {}, 0
            while i < nlen + ndist and not failed do
                local sym = decode(lencode)
                if not sym then break end
                if sym < 16 then
                    l[i] = sym
                    i = i + 1
                else
                    local prev, rep = 0, 0
                    if sym == 16 then
                        if i == 0 then failed = true break end
                        prev = l[i - 1]
                        rep = 3 + bits(2)
                    elseif sym == 17 then
                        rep = 3 + bits(3)
                    else
                        rep = 11 + bits(7)
                    end
                    for _ = 1, rep do
                        l[i] = prev
                        i = i + 1
                    end
                end
            end
            local d = {}
            for s = 0, ndist - 1 do d[s] = l[nlen + s] or 0 end
            codes(build(l, nlen), build(d, ndist))
        else
            failed = true
        end
    until final == 1 or failed
    if failed then return nil end
    return out
end

-- Packs bytes as zlib data (stored, not compressed: the lists are tiny).
local function deflate(bytes)
    local n = #bytes
    local out = { 120, 1, 1, n % 256, math.floor(n / 256), 255 - n % 256, 255 - math.floor(n / 256) }
    local a, b = 1, 0
    for i = 1, n do
        out[#out + 1] = bytes[i]
        a = (a + bytes[i]) % 65521
        b = (b + a) % 65521
    end
    out[#out + 1] = math.floor(b / 256)
    out[#out + 1] = b % 256
    out[#out + 1] = math.floor(a / 256)
    out[#out + 1] = a % 256
    return out
end

-- Adds one episode to Stremio's packed list of ticks. index_of / id_of translate
-- between episode ids and their position in the series (1 = first).
-- Returns the new packed text, or nil and a reason; never removes a tick.
local function add_tick(old, index_of, id_of, target)
    local ticks = {}
    if old and old ~= "" then
        local anchor, len, packed = old:match("^(.*):(%d+):([^:]*)$")
        if not anchor then return nil, "the existing ticks are in an unknown format" end
        local bytes = inflate(b64_decode(packed))
        if not bytes then return nil, "the existing ticks could not be unpacked" end
        local any = false
        for _, v in ipairs(bytes) do if v ~= 0 then any = true end end
        if any then
            local a = index_of(anchor)
            if not a then return nil, "the existing ticks belong to an episode list this script cannot match" end
            local offset = tonumber(len) - a
            for j = 0, #bytes * 8 - 1 do
                if math.floor(bytes[math.floor(j / 8) + 1] / 2 ^ (j % 8)) % 2 == 1 then
                    local i = j - offset
                    if i < 0 then return nil, "the existing ticks do not line up with the episode list" end
                    ticks[i] = true
                end
            end
        end
    end
    local t = index_of(target)
    if not t then return nil, "this episode is not in the series' episode list" end
    ticks[t - 1] = true
    local last = 0
    for i in pairs(ticks) do if i > last then last = i end end
    local bytes = {}
    for k = 1, math.floor(last / 8) + 1 do bytes[k] = 0 end
    for i in pairs(ticks) do
        local k = math.floor(i / 8) + 1
        bytes[k] = bytes[k] + 2 ^ (i % 8)
    end
    local packed = b64_encode(deflate(bytes))
    -- Unpack what was just packed and compare, so a packing mistake can never be sent.
    local check = inflate(b64_decode(packed))
    if not check or #check ~= #bytes then return nil, "self-check failed" end
    for k = 1, #bytes do if check[k] ~= bytes[k] then return nil, "self-check failed" end end
    local anchor_id = id_of(last + 1)
    if not anchor_id then return nil, "self-check failed" end
    return anchor_id .. ":" .. (last + 1) .. ":" .. packed
end

-- Replaces the value of one simple field ("key": text / number / null) in JSON text.
local function set_field(text, field, literal)
    local s, e = text:find('"' .. field .. '"%s*:%s*')
    if not s then return nil end
    local i = e + 1
    local c = text:sub(i, i)
    local last = nil
    if c == '"' then
        local j = i + 1
        while j <= #text do
            local ch = text:sub(j, j)
            if ch == "\\" then j = j + 2 elseif ch == '"' then last = j break else j = j + 1 end
        end
    elseif c ~= "{" and c ~= "[" then
        local j = text:find("[,}%]]", i)
        last = j and j - 1
    end
    if not last then return nil end
    return text:sub(1, e) .. literal .. text:sub(last + 1)
end

local request_count = 0
local function post_json(path, body, done)
    -- The request goes through a short-lived file, removed as soon as curl has read it.
    request_count = request_count + 1
    local tmp = key_path .. "." .. request_count .. ".tmp"
    local f = io.open(tmp, "wb")
    if not f then done(nil) return end
    f:write(body)
    f:close()
    mp.command_native_async({
        name = "subprocess",
        playback_only = false,
        capture_stdout = true,
        capture_stderr = true,
        stdin_data = "",
        args = { "curl", "-s", "-m", "25", "-H", "Content-Type: application/json",
            "--data-binary", "@" .. tmp, STREMIO_API .. path },
    }, function(ok, res)
        os.remove(tmp) if ok and res and res.status == 0 then done(res.stdout or "") else done(nil) end
    end)
end

-- The series' episode list in Stremio's order, as two translation functions.
local function episode_list(sr, done)
    if sr.kind == "kitsu" then
        local prefix = "kitsu:" .. sr.id .. ":"
        done({
            index_of = function(id)
                if id:sub(1, #prefix) ~= prefix then return nil end
                local n = tonumber(id:sub(#prefix + 1))
                return n and n >= 1 and n == math.floor(n) and n or nil
            end,
            id_of = function(i) return prefix .. i end,
            name = sr.name, poster = sr.poster,
        })
        return
    end
    get_json(CINEMETA_META .. sr.id .. ".json", nil, function(data, why)
        local meta = data and type(data.meta) == "table" and data.meta or nil
        if not meta or type(meta.videos) ~= "table" then
            mp.msg.warn("Cinemeta: " .. tostring(why or "no episode list"))
            done(nil)
            return
        end
        local list = {}
        for n, v in ipairs(meta.videos) do
            if type(v) == "table" and type(v.id) == "string" then
                local se = tonumber(v.season) and tonumber(v.episode) and true or false
                list[#list + 1] = { id = v.id, n = n,
                    season = se and tonumber(v.season) or -1, episode = se and tonumber(v.episode) or -1,
                    released = type(v.released) == "string" and v.released or "" }
            end
        end
        table.sort(list, function(a, b)
            if a.season ~= b.season then return a.season < b.season end
            if a.episode ~= b.episode then return a.episode < b.episode end
            if a.released ~= b.released then return a.released < b.released end
            return a.n < b.n
        end)
        local where = {}
        for i, v in ipairs(list) do if not where[v.id] then where[v.id] = i end end
        done({
            index_of = function(id) return where[id] end,
            id_of = function(i) return list[i] and list[i].id end,
            name = type(meta.name) == "string" and meta.name or sr.name,
            poster = type(meta.poster) == "string" and meta.poster or nil,
        })
    end)
end

local function now_text()
    return os.date("!%Y-%m-%dT%H:%M:%S.000Z")
end

local function quoted(s)
    return utils.format_json(tostring(s))
end

-- Adds the tick for one finished episode to the Stremio account.
local function mark_watched(info, duration)
    local skey = stremio_key()
    if not skey then return end
    identify(info, function()
        local sr = info.series
        if not sr then return end
        local video = video_id(sr, sr.season, sr.ep)
        if marked[video] then return end
        local series_id = sr.kind == "kitsu" and ("kitsu:" .. sr.id) or sr.id
        episode_list(sr, function(eps)
            if not eps then return end
            local target = eps.index_of(video)
            local following = target and eps.id_of(target + 1) or nil
            if sr.kind == "kitsu" and not sr.after then following = nil end
            local get = '{"authKey":' .. quoted(skey) .. ',"collection":"libraryItem","ids":['
                .. quoted(series_id) .. '],"all":false}'
            post_json("datastoreGet", get, function(text)
                local data = text and utils.parse_json(text) or nil
                if type(data) ~= "table" or type(data.result) ~= "table" then
                    local why = type(data) == "table" and type(data.error) == "table" and data.error.message
                    mp.msg.warn("Stremio did not accept the request: " .. tostring(why or "no answer"))
                    if why then mp.osd_message("Stremio ticks: the sign-in key was refused (" .. tostring(why) .. ")", 6) end
                    return
                end
                local existing = data.result[1]
                local now = now_text()
                local item = nil
                if type(existing) == "table" and type(existing.state) == "table" then
                    local raw = text:match('^%s*{%s*"result"%s*:%s*%[%s*(.*%S)%s*%]%s*}%s*$')
                    if not raw or #data.result ~= 1 then
                        mp.msg.warn("Stremio's answer was not in the expected shape; nothing changed")
                        return
                    end
                    local old = type(existing.state.watched) == "string" and existing.state.watched or nil
                    local packed, why = add_tick(old, eps.index_of, eps.id_of, video)
                    if not packed then
                        mp.msg.warn("tick not added: " .. tostring(why))
                        return
                    end
                    local f = io.open(backup_path, "a")
                    if f then
                        f:write(now .. " " .. raw .. "\n")
                        f:close()
                    end
                    item = raw
                    if not item:find('"watched"%s*:') then
                        item = item:gsub('("state"%s*:%s*{)', '%1"watched":null,', 1)
                    end
                    item = set_field(item, "watched", quoted(packed))
                    item = item and set_field(item, "_mtime", quoted(now))
                    item = item and set_field(item, "lastWatched", quoted(now))
                    item = item and set_field(item, "timesWatched", tostring((tonumber(existing.state.timesWatched) or 0) + 1))
                    item = item and set_field(item, "video_id", quoted(following or video))
                    item = item and set_field(item, "timeOffset", following and "1" or "0")
                    if item and following then
                        item = set_field(item, "timeWatched", "0")
                        item = item and set_field(item, "flaggedWatched", "0")
                    end
                    if not item then
                        mp.msg.warn("Stremio's entry had an unexpected layout; nothing changed")
                        return
                    end
                elseif #data.result == 0 then
                    local packed, why = add_tick(nil, eps.index_of, eps.id_of, video)
                    if not packed then
                        mp.msg.warn("tick not added: " .. tostring(why))
                        return
                    end
                    item = '{"_id":' .. quoted(series_id) .. ',"name":' .. quoted(eps.name or sr.name or series_id)
                        .. ',"type":"series","poster":' .. (eps.poster and quoted(eps.poster) or "null")
                        .. ',"posterShape":"poster","removed":true,"temp":true,"_ctime":' .. quoted(now)
                        .. ',"_mtime":' .. quoted(now) .. ',"state":{"lastWatched":' .. quoted(now)
                        .. ',"timeWatched":0,"timeOffset":' .. (following and "1" or "0")
                        .. ',"overallTimeWatched":0,"timesWatched":1,"flaggedWatched":0,"duration":'
                        .. string.format("%d", math.floor((duration or 0) * 1000))
                        .. ',"video_id":' .. quoted(following or video) .. ',"watched":' .. quoted(packed)
                        .. ',"noNotif":false},"behaviorHints":{"defaultVideoId":null,"featuredVideoId":null,"hasScheduledVideos":false}}'
                else
                    mp.msg.warn("Stremio's answer was not in the expected shape; nothing changed")
                    return
                end
                local put = '{"authKey":' .. quoted(skey) .. ',"collection":"libraryItem","changes":[' .. item .. ']}'
                post_json("datastorePut", put, function(answer)
                    local res = answer and utils.parse_json(answer) or nil
                    if type(res) == "table" and res.result ~= nil and res.error == nil then
                        marked[video] = true
                        mp.msg.info("ticked in Stremio: " .. video)
                    else
                        mp.msg.warn("Stremio refused the change: " .. tostring(answer):sub(1, 200))
                    end
                end)
            end)
        end)
    end)
end

mp.observe_property("time-pos", "number", function(_, v) if v then last_pos = v end end)
mp.observe_property("duration", "number", function(_, v) if v then last_duration = v end end)

mp.add_hook("on_unload", 50, function()
    local info, pos, dur = current, last_pos, last_duration
    last_pos, last_duration = nil, nil
    if not info or not pos or not dur or dur < 120 or pos / dur < 0.9 then return end
    if not describe(info.name) then return end
    mark_watched(info, dur)
end)

-- A release we picked ourselves is checked when it opens: Torrentio answers with a short
-- error clip when TorBox cannot play it, and some releases carry no subtitles.
-- Returns true when it was rejected and something else is being opened instead.
local function reject_bad_choice(path)
    local choice = choices[path]
    if not choice then return false end
    local duration = mp.get_property_number("duration")
    local subs = 0
    for _, t in ipairs(mp.get_property_native("track-list") or {}) do
        if t.type == "sub" then subs = subs + 1 end
    end
    local why = nil
    if duration and duration < 120 then
        why = "would not play"
    elseif choice.subs and subs == 0 then
        why = "has no subtitles"
    end
    if not why then return false end
    local hash = (path:match("/resolve/torbox/[^/]+/(%x+)/") or ""):lower()
    unplayable[hash] = true
    local other = choice.list[choice.index + 1]
    if other then
        choices[other.url] = { list = choice.list, index = choice.index + 1, origin = choice.origin,
            auto = choice.auto, subs = choice.subs }
        mp.osd_message("That release " .. why .. " - trying another one...", 5)
        mp.commandv("loadfile", other.url, "replace")
    elseif choice.auto or not choice.origin then
        mp.commandv("stop")
        mp.osd_message("No playable release found for the next episode - pick it in Stremio", 8)
    else
        mp.osd_message("No playable release found - back to the episode you were on", 6)
        mp.commandv("loadfile", choice.origin, "replace")
    end
    return true
end

mp.register_event("file-loaded", function()
    generation = generation + 1
    local gen = generation
    queued = nil
    if reject_bad_choice(mp.get_property("path") or "") then
        current = nil
        return
    end
    current = parse(mp.get_property("path"))
    if not current then return end
    local info = current
    -- Films are left alone: only episodes get the next one lined up.
    if not describe(info.name) then return end
    -- Wait a moment so the video starts first, then look the episodes up quietly.
    mp.add_timeout(4, function()
        if gen ~= generation then return end
        queue_next(info, gen)
    end)
end)

load_state()
